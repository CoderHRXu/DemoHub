/**
 * 绑定
 */
(function() {
    var isSend = false; //是否发送过验证码
    var countdown = {}; //计时器
    var bound = {
        ajax: {
            /*检查是否绑定*/
            checkBinded: function(data, callback) {
                if (worf.tools.requestLimit()) return;
                worf.ajax({
                    data: data,
                    url: worf.API_URL + "/v1/userAuth/checkHasBinded.json",
                    success: function(json) {
                        if (json.status == 1) {
                            callback && callback(json.data||{});
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            },
            /*发送手机验证码*/
            sendCode: function(data, callback) {
                if (worf.tools.requestLimit()) return;
                worf.ajax({
                    data: data,
                    url: worf.API_URL + "/v1/userAuth/sendPhoneCode4Bind.json",
                    success: function(json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                            worf.resMode != "pro" && $("#txtCode").val("123456");
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            },
            /*绑定*/
            bind: function(data, callback) {
                if (worf.tools.requestLimit()) return;
                worf.ajax({
                    data: data,
                    animate: true,
                    url: worf.API_URL + "/v1/userAuth/bindWX.json",
                    success: function(json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.result_msg);
                        }
                    }
                });
            }
        },
        /*发送验证码*/
        sendCode: function() {
            var button = $("#btnGetCode");
            var phone = worf.tools.val("#txtPhone");
            if (!phone) {
              worf.prompt.tip("请输入手机号码");
              return false;
            } else if (!/^1[3|4|5|8|7][0-9]{9}$/.test(phone)) {
              worf.prompt.tip("手机号码格式不正确");
              return false;
            }
            bound.ajax.sendCode({ key: phone }, function() {
                isSend = true;
                countdown = worf.tools.countdown({
                    before: function() { button.off("click"); },
                    jump: function(time) { button.text(time + "秒后可重发"); },
                    after: function() {
                        button.text("获取验证码").click(bound.sendCode);
                    }
                });
            });
        },
        /**
         * 提交
         */
        submit: function() {
            var phone = worf.tools.val("#txtPhone");
            var code = worf.tools.val("#txtCode");
            if (!phone) {
              worf.prompt.tip("请输入手机号码");
              return false;
            } else if (!/^1[3|4|5|8|7][0-9]{9}$/.test(phone)) {
              worf.prompt.tip("手机号码格式不正确");
              return false;
            }
            if (!isSend) {
                worf.prompt.tip("您还未获取验证码");
                return;
            } else if (code == "") {
                worf.prompt.tip("请输入验证码");
                return;
            }
            var openid = worf.user.getOpenId();
            bound.ajax.bind({ phone: phone, phoneCode: code, openid: openid }, function() {
                $("#txtCode").val("");
                worf.prompt.tip("绑定成功", { time: 2000 }, function() {
                     window.location.replace("/view/wx/user-bound.html?r="+worf.tools.getTimestamp());
                });
                return;
            });
        },
        bindEvent: function() {
            $("#btnGetCode").click(this.sendCode);
            //清空文本事件
            $("#btnClear").click(function() {
                if ($(this).parent().hasClass("color-gray")) {
                    return;
                }
                $("#txtCardID").val("").trigger("input");
            });
            //文字输入效果
            $("#txtCardID").on("input change", function() {
                var me = $(this);
                if (me.val().length >= 8) {
                    $("#cardRow").removeClass("color-gray");
                    $("#btnBind").removeClass("disabled");
                } else {
                    $("#cardRow").addClass("color-gray");
                    $("#btnBind").addClass("disabled");
                }
                isSend = false;
                countdown.reset && countdown.reset();
            });

            //提交
            $("#btnBind").click(this.submit);
        },
        init: function() {
            this.bindEvent();
            $("#boundGroup").removeClass("hide");
        }
    };
    window.bound = bound;
})(Zepto);

/**
 * 解绑
 */
(function() {
    var isSend = false; //是否发送过验证码
    var countdown = {}; //计时器
    var unbound = {
        ajax: {
            /*检查是否绑定*/
            checkBinded: function(data, callback,fail) {
                if (worf.tools.requestLimit()) return;
                worf.ajax({
                    data: data,
                    url: worf.API_URL + "/v1/userAuth/checkHasBinded.json",
                    errorTip:function(json){
                        if(json.status ==1030){
                            //显示已绑定
                            fail && fail(json.data);
                        }else{
                            worf.prompt.tip(json.message);
                        }
                        return true;
                    },
                    success: function(json) {
                        if (json.status == 1) {
                            callback && callback(json.data||{});
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            },
            /*发送手机验证码*/
            sendCode: function(data, callback) {
                if (worf.tools.requestLimit()) return;
                worf.ajax({
                    data: data,
                    url: worf.API_URL + "/v1/userAuth/sendPhoneCode4UnBind.json",
                    success: function(json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                            worf.resMode != "pro" && $("#txtCode2").val("123456");
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            },
            /*解绑*/
            unbind: function(data, callback) {
                if (worf.tools.requestLimit()) return;
                worf.ajax({
                    data: data,
                    animate: true,
                    url: worf.API_URL + "/v1/userAuth/unBindWX.json",
                    success: function(json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            }
        },
        /*发送验证码*/
        sendCode: function() {
            var openid = worf.user.getOpenId();
            var button = $("#btnGetCode2");
            unbound.ajax.sendCode({ key: openid }, function() {
                isSend = true;
                countdown = worf.tools.countdown({
                    before: function() { button.off("click"); },
                    jump: function(time) { button.text(time + "秒后可重发"); },
                    after: function() {
                        button.text("获取验证码").click(unbound.sendCode);
                    }
                });
            });
        },
        /**
         * 提交
         */
        submit: function() {
            var code = worf.tools.val("#txtCode2");
            if (!isSend) {
                worf.prompt.tip("您还未获取验证码");
                return;
            } else if (code == "") {
                worf.prompt.tip("请输入验证码");
                return;
            }
            var openid = worf.user.getOpenId();
            unbound.ajax.unbind({openid:openid,phoneCode:code}, function() {
                $("#txtCode2").val("");
                worf.cookie.clear();
                worf.localStorage.clear();
                worf.prompt.tip("已成功解除绑定", { time: 2000 }, function() {
                    window.location.replace("/view/wx/user-bound.html?r="+worf.tools.getTimestamp());
                });
            });
        },
        hideDialog: function() {
            worf.animate.zoomOut("#unboundWrap");
            worf.animate.fadeOut("#unboundMask", function() {
                $("#unboundDialog").addClass("hide");
            });
        },
        showDialog: function() {
            if (!this.initedDialog) {
                this.initDialog();
            }
            $("#spPhone2").text($("#spPhone").text());
            $("#unboundDialog").removeClass("hide");
            worf.animate.fadeIn("#unboundMask");
            worf.animate.zoomIn("#unboundWrap");
        },
        /*初始化弹出框*/
        initDialog: function() {
            $("#btnGetCode2").click(this.sendCode);
            $("#btnSubmit2").click(this.submit);
            $("#btnUnboundClose").click(this.hideDialog);
            this.initedDialog = true;
        },
        bindEvent: function() {
            //提交
            $("#btnUnbind").click(function() {
                unbound.showDialog();
            });
        },
        init: function() {
            this.bindEvent();
            this.initDialog();
            $("#unboundGroup").removeClass("hide");
        }
    };
    window.unbound = unbound;
})(Zepto);

/**
 * 页面加载
 */
$(function() {
    //window.unbound.init();
    //读取已绑定的信息，决定显示绑定和非绑定
    var openid = worf.user.getOpenId();
    if (openid) {
        unbound.ajax.checkBinded({ id: openid }, function(data) {
            if (data.phoneMask) {
                $("#spPhone").text(data.phoneMask);
                unbound.init();
            } else {
                bound.init();
            }
        }, function(phone) {
            if(phone){
                $("#spPhone").text(phone);
                unbound.init();
            }else {
                bound.init();
            }
        });
    } else {
        bound.init();
    }
});
