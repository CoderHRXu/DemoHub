$(function () {
  init();
});

(function ($) {
  var isCertified = false;
  var defaultPhoto = "../../img/user/default-photo.png?v=201608";
  var ajax = {
    /*延长登录时间*/
    extendLogin: function (callback) {
      worf.ajax({
        url: worf.API_URL + "/v1/user/extendLogin.json",
        errorTip: function (json) {
          callback && callback(json);
        },
        success: function (json) {
          callback && callback(json);
        }
      });
    },
    /*用户信息*/
    getUserInfo: function (callback) {
      window.forbidAutoLogin = true;
      worf.ajax({
        animate: true,
        data: { key: worf.tools.getTimestamp() },
        url: worf.API_URL + "/v1/user/getUserHomePageInfo.json",
        overdue: function () {
          showLogin();
        },
        success: function (json) {
          if (json.status == 1) {
            callback && callback(json.data);
          } else {
            worf.prompt.tip(json.message);
          }
        }
      });
    }
  };

  /**
  * 绑定跳转
  */
  function bindRedirect() {
    var urls = ["/view/user/realName.html", "/view/user/card.html", "/view/user/product.html"];
    $("#divContent .me_tab").off().click(function () {
      var me = $(this),
          id = me.data("id"),
          url = urls[id];
      if (!worf.user.isLogin()) {
        worf.user.goLogin();
        return;
      }
        //实名认证
      else if ([1, 2].indexOf(id) > -1 && !isCertified) {
        worf.prompt.tip("请先进行实名认证", {}, function () {
          worf.nav.go("/view/user/realName.html");
        });
        return;
      } else if (id == 0 && isCertified) {
        worf.prompt.tip("已认证成功");
      } else {
        worf.nav.go(url);
      }
    });
    $("#divInvitation").off().click(function () {
      if (!worf.user.isLogin()) {
        worf.user.goLogin();
        return;
      }
      worf.nav.go("/view/user/invitation.html");
    });
    $("#imgPhoto").off().on("error", function () {
      this.src = defaultPhoto;
    });
  }

  /*
  * 显示为登录状态
  **/
  function showLogin() {
    $("#sp_scores").text("**").addClass("none");
    $("#sp_orderTicket").text("**").addClass("none");
    $("#sp_userName").text("登录/注册");
    $("#sp_userPhone").text("");
    $(".me_img_bg").attr("data-href", "/view/user/login.html");
    $(".me_info").attr("data-href", "/view/user/login.html");
    $("#divPoints").attr("data-href", "/view/user/login.html");
    $("#divTicket").attr("data-href", "/view/user/login.html");
    $("#imgPhoto").attr("src", (defaultPhoto)).removeClass("hide");
    $("[data-href]").off().click(function () {
      worf.nav.go($(this).data("href"));
    });
  }

  /**
    *  获取用户信息
    */
  function getUserInfo() {
    var token = worf.user.getToken();
    if (!token) {
      showLogin();
      return;
    }

    //加载图片
    //var storeImg = worf.localStorage.get("user-photo-final");
    //if (storeImg) $("#imgPhoto").attr("src", storeImg).removeClass("hide");

    ajax.getUserInfo(function (data) {
      isCertified = (data.cardState == 1);
      //更新缓存
      worf.localStorage.set("user-info", JSON.stringify(data));
      //头像
      data.iconPath = data.iconPath || defaultPhoto;
      $("#imgPhoto").attr("src", (data.iconPath)).removeClass("hide");
      //其他
      for (var key in data) {
        $("#sp_" + key).text(data[key]);
      };
      if (isCertified) {
        $("#sp_userName").append('<span class="rz" id="spCert">已认证</span>');
      } else {
        $("#sp_userName").append('<span class="rz unpass" id="spCert">未认证</span>');
      }
      $("#divPoints").off().click(function () { worf.nav.go("/view/user/points.html?num=" + (data.scores || 0)); });
      $("#divTicket").off().click(function () { worf.nav.go( "/view/user/ticket.html?num=" + (data.orderTicket || 0)); });
    });
    $(".me_img_bg").attr("data-href", "/view/user/setting.html");
    $(".me_info").attr("data-href", "/view/user/setting.html");
    $("[data-href]").off().click(function () {
      worf.nav.go($(this).data("href"));
    });
  }

  /**
   * 延长登录时间
   */
  function extendLogin() {
    var token = worf.user.getToken();
    if (!token) {
      return;
    }
    window.forbidAutoLogout = true;
    window.forbidAutoLogin = true;
    ajax.extendLogin(function (json) {
        var token = "";
        if (json && json.status == 1) {
            token = json.data;
        } 
        worf.user.refreshToken(token);
    });
  }

  /**
    *  初始化
    */
  window.loadData = function () {
    window.init();
  };


  /**
    *  初始化
    */
  window.init = function () {
    worf.history.clear();
    getUserInfo();
    bindRedirect();
  };
})(window.Zepto);