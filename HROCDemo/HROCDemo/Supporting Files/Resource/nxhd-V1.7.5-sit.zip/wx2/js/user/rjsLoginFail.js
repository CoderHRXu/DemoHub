var rongMsg = worf.tools.queryString("message");
$(".rjsloginbox").html(rongMsg);
var reqForm = worf.tools.queryString("from");
function goback(){
	if(reqForm=="wap"){
	    worf.nav.back("/index.html");
	}else if(reqForm=="app"){
  		 loginFail();
	}
}
function loginFail(){
	window.app.finish();
}