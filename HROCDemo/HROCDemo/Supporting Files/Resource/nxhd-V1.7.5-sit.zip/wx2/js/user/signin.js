$(function() {
    window.calendar.init();
    //getIntegral();
});

(function(win) {
    var currentYear,
        currentMonth,
        prevYear,
        prevMonth,
        nextYear,
        nextMonth,
        minDay,
        maxDay;

    if (!Date.prototype.Format) {
        Date.prototype.Format = function(fmt) {
            var o = {
                "M+": this.getMonth() + 1, //月份
                "d+": this.getDate(), //日
                "[Hh]+": this.getHours(), //小时
                "m+": this.getMinutes(), //分
                "s+": this.getSeconds(), //秒
                "q+": Math.floor((this.getMonth() + 3) / 3), //季度
                "S": this.getMilliseconds() //毫秒
            };
            if (/(y+)/.test(fmt))
                fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
            for (var k in o)
                if (new RegExp("(" + k + ")").test(fmt))
                    fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
            return fmt;
        };
    }

    var calUtil = {
        //当前日历显示的年份
        showYear: 2015,
        //当前日历显示的月份
        showMonth: 1,
        //当前日历显示的天数
        showDays: 1,
        eventName: "load",
        //初始化日历
        init: function() {
            calUtil.setMonthAndDay();
            calUtil.draw(calUtil.getData); //signList
            calUtil.bindEnvent();
        },
        draw: function(callback, signList) {
            //绑定日历
            var str = calUtil.drawCal(calUtil.showYear, calUtil.showMonth, signList || []);
            $("#calendar").html(str);
            //绑定日历表头
            var calendarName = calUtil.showYear + "年" + calUtil.showMonth + "月";
            var tag =calUtil.showYear+(calUtil.showMonth<10?("0"+calUtil.showMonth):calUtil.showMonth);
            $("#spYearMonth").data("tag",tag).html(calendarName);
            callback && callback();
        },
        //绑定事件
        bindEnvent: function() {
            //绑定上个月事件
            $(".prev,.next").click(function() {
                calUtil.eventName = $(this).data("action");
                var currentYearMonth=parseInt($("#spYearMonth").data("tag"),10);
                if(calUtil.eventName=="prev" && currentYearMonth<=201701){
                    return;
                }
                calUtil.init();
            });
        },
        getData: function() {
            var startDate = new Date(prevYear, (prevMonth-1<0)?12:(prevMonth-1), minDay).getTime();
            var endDate = new Date(nextYear, (nextMonth-1<0?12:nextMonth-1), maxDay).getTime();
            var timeStart = Math.ceil((startDate + 1000) / 1000);  // 开始时间
            var timeEnd = Math.floor((endDate - 1000) / 1000); // 结束时间
            calUtil.getSign({ start: timeStart, end: timeEnd });
        },
        //获取当前选择的年月
        setMonthAndDay: function() {
            switch (calUtil.eventName) {
                case "load":
                    var current = new Date();
                    calUtil.showYear = current.getFullYear();
                    calUtil.showMonth = current.getMonth() + 1;
                    break;
                case "prev":
                    var nowMonth = $(".date").html().split("年")[1].split("月")[0];
                    calUtil.showMonth = parseInt(nowMonth) - 1;
                    if (calUtil.showMonth == 0) {
                        calUtil.showMonth = 12;
                        calUtil.showYear -= 1;
                    }
                    break;
                case "next":
                    var nowMonth = $(".date").html().split("年")[1].split("月")[0];
                    calUtil.showMonth = parseInt(nowMonth) + 1;
                    if (calUtil.showMonth == 13) {
                        calUtil.showMonth = 1;
                        calUtil.showYear += 1;
                    }
                    break;
            }
        },
        getDaysInmonth: function(iMonth, iYear) {
            var dPrevDate = new Date(iYear, iMonth, 0);
            return dPrevDate.getDate();
        },
        bulidCal: function(iYear, iMonth) {
            currentYear = iYear;
            currentMonth = iMonth;
            minDay = 0;
            maxDay = 0;

            var aMonth = new Array();
            aMonth[0] = new Array(7);
            aMonth[1] = new Array(7);
            aMonth[2] = new Array(7);
            aMonth[3] = new Array(7);
            aMonth[4] = new Array(7);
            aMonth[5] = new Array(7);
            aMonth[6] = new Array(7);

            //本月
            var dCalDate = new Date(iYear, iMonth - 1, 1);
            var iDayOfFirst = dCalDate.getDay();
            var iDaysInMonth = calUtil.getDaysInmonth(iMonth, iYear);
            //上月;

            prevMonth = iMonth - 1 == 0 ? 12 : iMonth - 1; //上个月份值
            prevYear = prevMonth == 12 ? iYear - 1 : iYear;
            var prevMonthDayCount = calUtil.getDaysInmonth(prevMonth, iYear); //上个月一共多少天
            //下月;
            nextMonth = iMonth + 1 == 13 ? 1 : iMonth + 1; //下个月份值;
            nextYear = nextMonth == 1 ? iYear + 1 : iYear;

            var iVarDate = 1;
            var d, w;
            aMonth[0][0] = "日";
            aMonth[0][1] = "一";
            aMonth[0][2] = "二";
            aMonth[0][3] = "三";
            aMonth[0][4] = "四";
            aMonth[0][5] = "五";
            aMonth[0][6] = "六";

            var startY = iDayOfFirst == 0 ? 2 : 1;
            for (d = iDayOfFirst; d < 7; d++) {
                aMonth[startY][d] = iVarDate;
                iVarDate++;
            }
            for (w = startY + 1; w < 7; w++) {
                for (d = 0; d < 7; d++) {
                    if (iVarDate <= iDaysInMonth) {
                        aMonth[w][d] = iVarDate;
                        iVarDate++;
                    }
                }
            }
            //补齐月份前一周日期
            var total = iDayOfFirst == 0 ? 7 : iDayOfFirst;
            var temp = total - 1;
            for (var i = prevMonthDayCount; i > prevMonthDayCount - total; i--) {
                aMonth[1][temp] = i;
                minDay = i;
                temp--;
            }

            //补齐月份后一周日期
            temp = 1;
            for (var j = 5; j < 7; j++) {
                for (var i = 0; i < 7; i++) {
                    if (!aMonth[j][i]) {
                        aMonth[j][i] = temp;
                        maxDay = temp;
                        temp++;
                    }
                }
            }
            return aMonth;
        },
        ifHasSigned: function(signList, day) {
            var signed = false;
            $.each(signList, function(index, item) {
                if (item.signDay == day) {
                    signed = true;
                    return false;
                }
            });
            return signed;
        },
        drawCal: function(iYear, iMonth, signList) {
            var myMonth = calUtil.bulidCal(iYear, iMonth);
            var htmls = new Array();
            htmls.push("<div class='wrap-date'>");
            htmls.push("<span class='prev icon icon-next' data-action='prev'></span>");
            htmls.push("<span class='date' id='spYearMonth'></span>");
            htmls.push("<span class='next icon icon-next'  data-action='next'></span>");
            htmls.push("</div>");
            htmls.push("<div class='wrap-day' id='sign_cal'>");
            htmls.push("<table>");
            htmls.push("<thead>");
            htmls.push("<tr>");
            htmls.push("<th class='weekend'>" + myMonth[0][0] + "</th>");
            htmls.push("<th>" + myMonth[0][1] + "</th>");
            htmls.push("<th>" + myMonth[0][2] + "</th>");
            htmls.push("<th>" + myMonth[0][3] + "</th>");
            htmls.push("<th>" + myMonth[0][4] + "</th>");
            htmls.push("<th>" + myMonth[0][5] + "</th>");
            htmls.push("<th class='weekend'>" + myMonth[0][6] + "</th>");
            htmls.push("</tr>");
            htmls.push("<tbody>");
            var d, w;
            var minDate = new Date(prevYear, prevMonth - 1, minDay).getTime();
            var fixMonth = 1;
            if (prevMonth == 12 && minDay == 0) {
                minDate = new Date(currentYear, 1, 1).getTime();
                fixMonth = 0;
            }

            for (w = 1; w < 7; w++) {
                htmls.push("<tr>");
                for (d = 0; d < 7; d++) {
                    var currentDay = new Date(minDate + ((w - 1) * 7 + d) * 24 * 3600 * 1000);
                    var currentMonthClass = currentDay.getMonth() + fixMonth == currentMonth ? "" : "gray"; //当月样式
                    var id = currentDay.Format("MM_dd");
                    var text=(currentDay>new Date() || currentDay<new Date(2017,0,1))?"":"<span>未签</span>";
                    htmls.push("<td class='unsign " + currentMonthClass + "' id='" + id + "'>" +
                     "<label>" + (!isNaN(myMonth[w][d]) ? myMonth[w][d] : " ") + "</label>"+ text + "</td>");
                }
                htmls.push("</tr>");
            }
            htmls.push("</table>");
            htmls.push("</div>");
            htmls.push("</div>");
            return htmls.join('');
        },
        /*获取签到数据*/
        markSign: function(data) {
            $.each(data, function(index, item) {
                $("#" + item).removeClass("unsign").addClass("signed").find("span").text("已签");
            });
            //控制当前天的样式
            $("#" + new Date().Format("MM_dd")).addClass("today");
        },

        /*获取签到数据*/
        getSign: function(date) {
            worf.ajax({
                url: worf.API_URL + "/v1/user/signInHistory.json",
                data: {
                    "timeStart": date.start, // 开始时间
                    "timeEnd": date.end // 结束时间
                },
                success: function(json) {
                    if (json.data) {
                        var data = $.map(json.data, function(item) {
                            return item.signInTime.substr(5, 5).replace("-", "_");
                        });
                        calUtil.markSign(data);
                    }
                }
            });
        }
    };
    win.calendar = calUtil;

    win.goback = function() {
        if (worf.app.isReady && worf.app.toIndex) {
            worf.app.toIndex("/view/user/signin.html", true);
        }
    }
})(window);

/*获取总积分*/
function getIntegral() {
    worf.ajax({
        data: { key: worf.tools.getTimestamp() },
        url: worf.API_URL + "/v1/user/getUserHomePageInfo.json",
        success: function(json) {
            if (json.status == 1) {
                $("#spIntegral").text(json.data && json.data.scores || 0);
            } else {
                worf.prompt.fail(json.message || "获取积分失败");
            }
        }
    });
}

// 主动签到-for test
/*
 worf.ajax({
  url:worf.API_URL +"/v1/user/signIn.json",
  data:{ 
    "lng" : 116.31985, 
    "lat" : 39.959836, 
    "address" : "北京市海淀区中关村南大街27号"}
 })
*/
