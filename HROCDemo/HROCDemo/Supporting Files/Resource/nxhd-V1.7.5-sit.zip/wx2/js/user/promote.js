$(function() {
    init();
});

(function() {
    var codeFlag = false;
    var visitorId = worf.localStorage.get(worf.localStorage.keys.visitorCode) || worf.tools.getTimestamp();
    var defaultChannel = "2430B5"; //默认推广渠道
    var channel; //推广渠道

    var ajax = {
        /*发送手机验证码*/
        sendCode: function(data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/user/sendVerificationCode.json",
                animate: true,
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*注册*/
        register: function(data, callback, error) {
            worf.ajax({
                data: data,
                animate: true,
                url: worf.API_URL + "/v1/user/friendRegister.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                },
                errorTip: function() {
                    error && error();
                }
            });
        },
        setUserType: function(data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/user/setUserType.json",
                animate: true,
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        }
    };

    /**
     * 更换图片验证码
     */
    function showImgCode() {
        $("#txtPicCode").val("").parent().find(".icon-delete").addClass("hide");
        $("#imgCode").attr("src", worf.API_URL + "/v1/captcha/captcha?id=" + visitorId + "&r=" + worf.tools.getTimestamp());
    };

    /**
     * 获取短信验证码
     */
    window.getMsgCode = function() {
        var phone = worf.tools.val("#txtPhone");
        var picCode = worf.tools.val("#txtPicCode");
        if (!phone) {
            worf.prompt.tip("请输入手机号码");
            return false;
        } else if (!/^1[3|4|5|8|7][0-9]{9}$/.test(phone)) {
            worf.prompt.tip("请输入正确的手机号");
            return false;
        } else if (!picCode) {
            worf.prompt.tip("请输入图片验证码");
            return false;
        }
        ajax.sendCode({ phone: phone, captcha: picCode, clientId: visitorId }, function(data) {
            startTimer();
            codeFlag = true;
            if (data) worf.prompt.tip(data);
        });
    };

    /**
     * 倒计时
     */
    function startTimer() {
        var label = $("#btnCode");
        worf.tools.countdown({
            before: function() { label.off("click"); },
            jump: function(time) { label.text(time + "秒"); },
            after: function() {
                label.text("获取验证码").click(getMsgCode);
                showImgCode();
            }
        });
    }

    /**
     * 切换输入框状态
     */
    function toggleInput(el) {
        worf.tools.toggleInput(el, {
            getIcon: function(input) { return $(input).parent().find(".icon-delete") },
            getInput: function(icon) { return $(icon).parent().find("input") }
        });
    }
    /**
     * 加载数据
     */
    function getData() {
        //邀请码(保留2个小时)
        var invation = worf.tools.queryString("invation");
        $("#txtInvitation").val(invation || "");
        //if (invation) {
        //    worf.cookie.set("register-invation", invation, null, null, 2);
        //}
        //来源保留2个小时
        channel = worf.tools.queryString("channel") || defaultChannel;
        //if (channel != defaultChannel) {
        //    worf.cookie.set("register-channel", channel, null, null, 2);
        //}
    }

    /**
     * 验证
     */
    var token = "";

    function register(onlyCheck) {
        var phone = worf.tools.val("#txtPhone");
        var code = worf.tools.val("#txtCode");
        var picCode = worf.tools.val("#txtPicCode");
        var password = worf.tools.val("#txtPassword");
        var invitation = $("#txtInvitation").val();
        var userType = $("#roleBox li.checked").data("type");
        if (!phone) {
            worf.prompt.tip("请输入手机号码");
            return false;
        } else if (!/^1[3|4|5|8|7][0-9]{9}$/.test(phone)) {
            worf.prompt.tip("请输入正确的手机号");
            return false;
        } else if (!picCode) {
            worf.prompt.tip("请输入图片验证码");
            return false;
        } else if (!codeFlag) {
            worf.prompt.tip("请获取短信验证码");
            return false;
        } else if (code == "") {
            worf.prompt.tip("请输入短信验证码");
            return false;
        } else if (!/^[0-9]{6}$/.test(code)) {
            worf.prompt.tip("请输入正确的短信验证码");
            return false;
        } else if (!password) {
            worf.prompt.tip("请输入密码");
            return false;
        } else if (!/^[a-zA-Z0-9]{6,16}$/.test(password)) {
            worf.prompt.tip("密码格式不正确<br>6~16位数字字母组合");
            return false;
        }

        if (onlyCheck === true) {
            $("#roleBox").removeClass("hide");
            return;
        }

        var data = {
            phone: phone,
            code: code,
            captcha: picCode,
            invitationCode: invitation,
            password: password,
            channel: channel,
            clientId: visitorId,
            userType: userType,
            ip: ""
        };

        ajax.register(data, function(data) {
            window.openAPP();
        }, function() {
            $("#roleBox").addClass("hide");
        });
    }

    function initShare() {
        $("#shareImg").attr("src", worf.origin + "/img/user/promote_banner.jpg");
    }

    /**
     * 初始化
     */
    window.init = function() {
        getData();
        //加载图片验证码
        showImgCode();
        initShare();
        $("#btnPicCode").click(showImgCode);
        $("#roleBox li").click(function() {
            $(this).addClass("checked").siblings().removeClass("checked");
            $("#btnOpen").removeClass("btn100-gray");
        });
        $("#btnOpen").click(register);
        //文本框效果
        toggleInput("#form input");
        //按钮事件
        $("#btnCode").click(getMsgCode);
        $("#btnSubmit").click(function() {
            register(true);
        });
    };
})();