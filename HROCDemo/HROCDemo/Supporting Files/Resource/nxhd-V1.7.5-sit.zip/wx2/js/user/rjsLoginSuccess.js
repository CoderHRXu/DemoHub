var _token = worf.tools.queryString("_token");
$(document).ready(function(e) {
	var reqForm = worf.tools.queryString("from");
	var bindFlag = worf.tools.queryString("bindFlag");
	if(reqForm=="wap"){
	    worf.nav.back("/index.html");
	}else if(reqForm=="app" && bindFlag){
		goIos(_token);
		finishApp("idvar/accountidvar.html");
	}else if(reqForm=="app"){
		goIos(_token);
		goback();
		
	}
});
function goIosBack(){
	goIos(_token);
	window.app.goHome(_token);
}
function goback(){
	goIos(_token);
	window.app.goHome(_token);
}
function finishApp(url){
	window.app.finishApp(url);		
}
function goIos(_token){
	
}