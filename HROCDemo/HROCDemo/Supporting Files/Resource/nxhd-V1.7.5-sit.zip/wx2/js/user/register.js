(function() {
    var codeFlag = false; //标记是否已获取短信验证码
    var step = 1;
    var protocolFlag = false;
    var idvarFlag = false;
    var showyqFLag = false;
    var visitorId = worf.localStorage.get(worf.localStorage.keys.visitorCode) || worf.tools.getTimestamp();
    var invation = worf.tools.queryString("invation") || worf.cookie.get("register-invation"); //邀请码;
    var defaultChannel = "2430B5"; //默认推广渠道
    var channel = ""; //渠道

    var ajax = {
        /*发送手机验证码*/
        sendCode: function(data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/user/sendVerificationCode.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*下一步*/
        next: function(data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/user/registerNextStep.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*注册*/
        register: function(data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/user/registerV2.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
    };

    /**
     * 显示协议
     */
    window.showProtocol = function() {
        protocolFlag = true;
        $("#formStep2").addClass("hide");
        worf.animate.sliderLeft("#protocol");
        //改变当前显示的头部
        worf.nav.changeHeader(1);
        //设置添加标题
        worf.app.toogleTitle($(".app-title").eq(1));
    }

    /**
     * 隐藏协议
     */
    window.hideProtocol = function() {
        protocolFlag = false;
        $("#formStep2").removeClass("hide");
        worf.animate.sliderRight("#protocol");
        //改变当前显示的头部
        worf.nav.changeHeader(0);
        //设置添加标题
        worf.app.toogleTitle($(".app-title").eq(0));
    }

    window.goback = function() {
        if (protocolFlag) {
            hideProtocol();
        } else if (step == 2) {
            showStep1();
            return;
        } else {
            worf.nav.back();
        }
    }

    /**
     * 更换图片验证码
     */
    function showImgCode() {
        $("#txtPicCode").val("").parent().find(".icon-delete").addClass("hide");
        $("#imgCode").attr("src", worf.API_URL + "/v1/captcha/captcha?id=" + visitorId + "&r=" + worf.tools.getTimestamp());
    };

    /**
     * 获取短信验证码
     */
    window.getMsgCode = function() {
        var phone = worf.tools.val("#txtPhone");
        var picCode = worf.tools.val("#txtPicCode");
        if (!phone) {
            worf.prompt.tip("请输入手机号码");
            return false;
        } else if (!/^1[3|4|5|8|7][0-9]{9}$/.test(phone)) {
            worf.prompt.tip("手机号码格式不正确");
            return false;
        } else if (!picCode) {
            worf.prompt.tip("请输入图片验证码");
            return false;
        }
        ajax.sendCode({ phone: phone, captcha: picCode, clientId: visitorId }, function(data) {
            startTimer();
            codeFlag = true;
            if (data) worf.prompt.tip(data);
        });
    };

    /**
     * 倒计时
     */
    function startTimer() {
        var label = $("#btnCode");
        worf.tools.countdown({
            before: function() { label.off("click"); },
            jump: function(time) { label.text(time + "秒"); },
            after: function() {
                label.text("获取验证码").click(getMsgCode);
            }
        });
    }

    /**
     * 切换输入框状态
     */
    function toggleInput(el) {
        worf.tools.toggleInput(el, {
            getIcon: function(input) { return $(input).parent().find(".icon-delete") },
            getInput: function(icon) { return $(icon).parent().find("input") }
        });
    }

    /**
     * 切换邀请码
     */
    function toggleInvitation() {
        var icon = $(this).find(".icon");
        var form = $("#formInvitation");
        form.toggleClass("full");
        icon.toggleClass("icon-down").toggleClass("icon-up");
        if (icon.hasClass("icon-up")) {
            $("#txtInvitation").val("");
        }
    }


    /**
     * 显示步骤1
     */
    function showStep1() {
        step = 1;
        showImgCode();
        $("#formStep1").removeClass("hide");
        $("#formStep2").addClass("hide");
        $("#btnProtocol").addClass("hide");
        $("#divStep .cycle").removeClass("active").eq(0).addClass("active");
    }

    /**
     * 显示步骤2
     */
    function showStep2() {
        step = 2;
        $("#formStep1").addClass("hide");
        $("#formStep2").removeClass("hide");
        $("#btnProtocol").removeClass("hide");
        $("#divStep .cycle").removeClass("active").eq(1).addClass("active");
    }

    /**
     * form校验
     */
    function checkForm() {
        var phone = worf.tools.val("#txtPhone");
        var code = worf.tools.val("#txtCode");
        var picCode = worf.tools.val("#txtPicCode");
        var invitation = worf.tools.val("#txtInvitation").replace(/\s/ig, "");
        if (!phone) {
            worf.prompt.tip("请输入手机号码");
            return false;
        } else if (!/^1[3|4|5|8|7][0-9]{9}$/.test(phone)) {
            worf.prompt.tip("手机号码格式不正确");
            return false;
        } else if (step == 1 && !picCode) {
            worf.prompt.tip("请输入图片验证码");
            return false;
        } else if (!codeFlag) {
            worf.prompt.tip("请获取短信验证码");
            return false;
        } else if (code == "") {
            worf.prompt.tip("请输入短信验证码");
            return false;
        } else if (!/^[0-9]{6}$/.test(code)) {
            worf.prompt.tip("短信验证码格式不正确");
            return false;
        } else if (invitation && !/^1[3|4|5|8|7][0-9]{9}$/.test(invitation)) {
            worf.prompt.tip("邀请码格式不正确");
            return false;
        }
        return { phone: phone, code: code, captcha: picCode, invitationCode: invitation };
    }

    /**
     * 提交-下一步
     */
    function next() {
        var data = checkForm();
        if (!data) {
            return false;
        }
        data.clientId = visitorId;
        ajax.next(data, function(data) {
            showStep2();
        });
    }

    /**
     * 提交-第二步
     */
    function submit() {
        var data = checkForm();
        if (!data) {
            return false;
        }
        var password = worf.tools.val("#txtPassword");
        if (!password) {
            worf.prompt.tip("请输入密码");
            return false;
        } else if (!/^[a-zA-Z0-9]{6,16}$/.test(password)) {
            worf.prompt.tip("密码格式不正确");
            return false;
        }
        var channel = worf.tools.queryString("channel") || worf.cookie.get("register-channel") || defaultChannel;
        data = $.extend(data, { password: password, channel: channel, ip: "" });
        ajax.register(data,
            function(data) {
                worf.cookie.del("register-channel");
                worf.cookie.del("register-invation");
                worf.cookie.set("session_token_dd", data);
                if (!worf.device.wap) {
                    window.app && window.app.loginCall(data);
                } else {
                    worf.nav.back("/view/user/me.html");
                }

                //跳转到登录成功版-TODO 下个版本上线
                //if (!worf.device.wap) {
                //  window.app && window.app.loginCall(data);
                //}
                ////延迟一下以免app的接口没调用完成
                //setTimeout(function () {
                //  worf.nav.go("/view/user/registerSuccess.html");
                //}, 300);
            });
    }

    /*眨眼睛*/
    function changeEye() {
        var eye = $(this).find(".icon");
        var input = $(this).parent().find("input");
        var isClose = eye.is(".icon-eye-close");
        if (isClose) {
            eye.removeClass("icon-eye-close").addClass("icon-eye-open");
            input.attr("type", "text");
        } else {
            eye.removeClass("icon-eye-open").addClass("icon-eye-close");
            input.attr("type", "password");
        }
    }

    /**
     * 初始化
     */
    window.init = function() {
        //加载图片验证码
        showImgCode();
        $("#btnPicCode").click(showImgCode);
        //显示邀请码
        $("#btnInvitation").click(toggleInvitation);
        if (invation && invation != defaultChannel) {
            var num = worf.tools.phoneFormat(invation);
            $("#txtInvitation").val(num).attr("disabled", "disabled");
            toggleInvitation();
        }
        //文本框效果
        toggleInput("#txtPhone,#txtPicCode,#txtCode,#txtInvitation,#txtPassword");
        $("#iconEye").click(changeEye);
        //按钮事件
        $("#btnNext").click(next);
        $("#btnCode").click(getMsgCode);
        $("#btnRigester").click(submit);
    };

})();