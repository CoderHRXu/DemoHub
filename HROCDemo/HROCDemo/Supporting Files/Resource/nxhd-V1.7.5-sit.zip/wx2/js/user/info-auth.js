$(function() {
    var name = worf.tools.queryString("name");
    var cardNo = worf.tools.queryString("cardNo");

    var ajax = {
        //接受协议
        accept: function(data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/borrowerAudit/accepAgreement.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        }
    };

    var accept = function(me) {
        if($(this).hasClass("btn100-gray")){
            return;
        }
        var sign = worf.tools.queryString("sign");
        ajax.accept({ name: name, cardNo: cardNo,sign:sign }, function(data) {
            window.location.href = "https://www.juxinli.com/OrgSpa/#/auth/KYXDB001/apply";
        });
    };
    $("#checkGroup").click(function(){
        var $icon =$(this).find("b");
        if($icon.hasClass("ok-active")){
            $("#btnSubmit").addClass("btn100-gray");
            $icon.removeClass("ok-active");
        }else{
            $("#btnSubmit").removeClass("btn100-gray");
            $icon.addClass("ok-active");
        }
    });
    $("#spName").text(name||"");
    $("#spCard").text(cardNo||"");
    $("#btnSubmit").click(accept);
});

