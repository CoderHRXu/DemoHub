$(function() {
    init();
});

(function() {
    var isEdit = false; //是否编辑过
    /**
     * 选择项定义
     */
    var itemConfig = {
        sex: { "2": "男", 1: "女" }
        //担保   小贷   银行   理财  典当    P2P  其他
        //companyType: { 0: "担保", 1: "小贷", 2: "银行", 3: "理财", 4: "典当", 5: "P2P", 6: "其他" },
        //车辆贷款  房产质押贷款  小额贷款  银行抵押贷款  银行信用贷款  其他
        // companyCoreBusiness: { 0: "车辆贷款", 1: "房产质押贷款", 2: "小额贷款", 3: "银行抵押贷款", 4: "银行信用贷款", 5: "其他" }
    };
    var ajax = {
        /*读取定义*/
        getDefined: function(data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/common/getDefined.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*读取名片信息*/
        getCardInfo: function(data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/user/showBusinessCardInfo.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*保存名片信息*/
        saveCardInfo: function(data, callback) {
            if (worf.tools.requestLimit()) return;
            worf.ajax({
                animate: true,
                data: data,
                url: worf.API_URL + "/v1/user/editBusinessCardInfo.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        }
    };

    /**
     * 读取名片信息
     */
    function getUserInfo(jsonData) {
        var data = jsonData || JSON.parse(worf.localStorage.get("user-card-detail") || "{}");
        if (!data.userName) {
            ajax.getCardInfo({}, function(data) {
                getUserInfo(data);
            });
            return;
        }

        if (data) {
            data.userPhoneText = worf.tools.phoneEncrypt(data.userPhone);
            data.workYearText = (data.workYear || 0) + "年";
            data.companyTypeText = itemConfig.userCompanyType[data.companyType] || " ";
            var coreBusiness = [];
            (data.companyCoreBusiness || "").split(",").forEach(function(item) {
                coreBusiness.push(itemConfig.companyBussinessType[item] || " ");
            });
            data.companyCoreBusinessText = coreBusiness.join("/");
            data.projectCountText = (data.projectCount || 0) + "个";
            data.workCityText = data.provinceAndCityName;
            data.sexText = { 2: "男", 1: "女" }[data.sex];
        }
        for (var key in data) {
            if (!/Text$/ig.test(key)) {
                $("#sp_" + key).attr("data-value", data[key]).text(data[key + "Text"] || data[key]);
            }
        };
    }

    /**
     * 保存名片信息
     */
    function saveUserInfo() {
        var data = {};
        var isAll = true; //是否填写完整
        $("#form .form-value").each(function() {
            var me = $(this);
            var name = me.attr("id").replace("sp_", "");
            var required = me.data("required");
            var value = me.attr("data-value");
            if (required != false && (value == "" || value == undefined)) {
                isAll = false;
            }
            data[name] = value;
        });

        if (!isAll) {
            worf.prompt.confirm("您的信息没有填写完整<br/>是否保存？", function() {
                worf.prompt.closeMe();
                save();
            }, function() {
                worf.prompt.closeMe();
                return false;
            }, { cancelText: "继续填写", okText: "保存" });
            return;
        }

        function save() {
            data.company = data.companyName;
            data.workAge = data.workYear;
            data.finishBusinessCard = isAll ? 1 : 0;
            delete(data.workYear);
            delete(data.companyName);
            ajax.saveCardInfo(data, function(data) {
                worf.prompt.success("保存成功", function() {
                    worf.nav.back();
                });
            });
        }
        save();
    }

    /**
     * 底部弹出选择框
     */
    function slideUpBox() {
        var me = $(this),
            type = me.data("box"),
            config = itemConfig[type];
        worf.ui.slideUpBox({
            data: config,
            select: function(data) {
                me.find(".form-value").attr("data-value", data.value).text(data.text);
                isEdit = true;
            }
        });
    }

    /**
     * 显示编辑form
     */
    var editFlag = true;

    function openEidt() {
        var me = $(this);
        var name = me.find(".pull-left").text();
        var element = me.find(".form-value");
        var elementId = element.attr("id");
        var mode = me.data("mode");
        var inputMode = me.data("input");
        var regex = me.data("regex");
        var regexMessage = me.data("regexms");
        var placeholder = me.data("placeholder");
        var maxlength = me.data("maxlength");
        var inputGroup, getResult, check, rangeUnit, multiSelectData;
        if (elementId == "sp_workCity") {
            inputGroup = $("#cityTemplate").html();
            getResult = function(wrapper) {
                var value = [];
                var text = [];
                wrapper.find("#selectedCityWrapper .city-item").each(function() {
                    value.push($(this).text());
                    text.push($(this).text());
                });
                return { text: text, value: value };
            }
        } else if (elementId == "sp_workYear") {
            getResult = function(wrapper) {
                var text = worf.tools.val(wrapper.find("input")).replace("年", "");
                return { text: [text + "年"], value: [text] };
            }
        } else if (elementId == "sp_companyCoreBusiness") {
            //主营业务
            multiSelectData = $.map(itemConfig.companyBussinessType, function(index, item) {
                return { text: itemConfig.companyBussinessType[item], value: item };
            });
            check = function(data) {
                var text = data.text;
                var temp = text.split(",");
                if (!temp[0]) {
                    worf.prompt.tip("请选择主营业务");
                    return false;
                } else if (temp.length > 2) {
                    worf.prompt.tip("最多选择2个");
                    return false;
                }
                return true;
            };
        } else if (elementId == "sp_wechat") {
            check = function(data) {
                var text = data.text;
                if (text && !/^[a-zA-Z][0-9a-zA-Z\-_]{5,19}$/.test(text)) {
                    worf.prompt.tip("微信号格式不正确");
                    return false;
                }
                return true;
            }
        }

        worf.ui.editPage({
            mode: mode, //输入框的模式 input,textarea,range
            placeholder: placeholder, //提示信息
            maxlength: maxlength, //字数限制
            regex: regex, //检验正则
            regexMessage: regexMessage, //检验提示语
            text: element.text(), //当前文本
            inputMode: inputMode, //输入模式：比如 tel，number
            value: element.attr("data-value"), //当前值
            name: name,
            multiSelectData: multiSelectData, //多选项的数据
            getResult: getResult, //获取结果的方法
            check: check, //检查结果的方法
            inputGroup: inputGroup, //输入框的html
            success: function(data) {
                var text = data.text;
                var value = data.value;
                element.data("value", value).text(text);
                isEdit = true;
            },
            opening: function(options) {
                //改变当前显示的头部
                worf.nav.changeHeader(1);
                //设置添加标题
                worf.app.toogleTitle($("#editTitle").text(), { rightTitle: "保存" });
                if (elementId == "sp_workCity") {
                    window.cityPicker.init({
                        scrollWrapper: !worf.device.wap ? $("#editInput") : $(document.body),
                        selectCity: function(data) {
                            worf.ui.editPage.hide();
                            options.success({ value: data.text, text: data.text });
                        }
                    });
                }
            },
            closed: function() {
                editFlag = false;
                //改变当前显示的头部
                worf.nav.changeHeader(0);
                //设置添加标题
                worf.app.toogleTitle($(".app-title").eq(0), { rightTitle: "保存" });
            }
        });
    }

    /**
     * 获取定义
     */
    function getDefined(callback) {
        ajax.getDefined(["userCompanyType", "companyBussinessType"], function(data) {
            itemConfig = $.extend(itemConfig, data);
            callback && callback();
        });
    }

    /**
     * 初始化
     */
    window.init = function() {
        getDefined(function() {
            getUserInfo();
        });
        $("#btnSave").click(saveUserInfo);
        $("[data-box]").click(slideUpBox);
        $("[data-edit]").click(openEidt);
        window.goback = function() {
            //关闭弹出框
            var dialogShow = false;
            ["#scrollBoxWrapper", "#datePickerWrapper", "#bbBox"].forEach(function(item) {
                var element = $(item);
                if (element.length > 0 && !element.hasClass("hide")) {
                    element.addClass("hide");
                    dialogShow = true;
                }
            });
            if (dialogShow) {
                return;
            }
            //询问是否保存已编辑的数据
            if (isEdit) {
                worf.prompt.confirm("您编辑的内容还未保存，是否返回？", function() {
                    worf.nav.back();
                });
            } else {
                worf.nav.back();
            }
        }
    };
})();