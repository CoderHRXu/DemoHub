$(function () {
    init();
});

(function () {
    var defaultPhoto = "../../img/user/default-photo.png";
    var ajax = {
        /*用户信息*/
        getUserInfo: function(callback) {
            worf.ajax({
                url: worf.API_URL + "/v1/user/getUserHomePageInfo.json",
                success: function (json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*上传头像*/
        uploadAvatar: function (data, callback) {
            worf.ajax({
                data:data,
                url: worf.API_URL + "/v1/user/uploadAvatar.json",
                success: function (json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*退出*/
        loginOut: function (callback) {
            worf.ajax({
                url: worf.API_URL + "/v1/user/logout.json",
                success: function (json) {
                    callback && callback(json);
                }
            });
        }
    };

    /**
    *  退出
    */
    function loginOut() {
        ajax.loginOut(function () {
            worf.user.logout(JSON.stringify({ isGoHome: true }));
            if (worf.device.wap) {
                worf.nav.go("/index.html");
            }
        });
    }

    /**
    *  获取用户信息
    */
    function getUserInfo() {
        //加载图片
        //var storeImg = worf.localStorage.get("user-photo-final");
        //if (storeImg) $("#imgPhoto").attr("src", storeImg).show();
        
        ajax.getUserInfo(function (data) {
            if (data) {
                //更新缓存
                worf.localStorage.set("user-info",JSON.stringify(data));
                //电话
                var phone = data.userPhone || "";
                if (phone.length == 11) {
                    var oldPhone = phone;
                    phone = phone.substr(0, 3) + "****" + phone.substr(7, 4);
                    $("#spPhone").data("phone", oldPhone).text(phone);
                    $("#linkPhone").off().click(function() {
                        worf.nav.go("/view/user/setphone.html?phone=" + oldPhone);
                    });
                }
                //头像
                data.iconPath = data.iconPath || defaultPhoto;
                $("#imgPhoto").on("error", function() {
                    this.src = defaultPhoto; 
                }).attr("src", data.iconPath);
            }
        });
    }

    /**
    *  初始化上传
    */
    function initUpload() {
        worf.localStorage.del("user-photo");
        $('#selFile').localResizeIMG({
            quality: 1,
            success: function (result) {
                worf.localStorage.set("user-photo", result.base64);
                worf.localStorage.set("user-photo-backurl", "setting.html");
                window.location.href = "photo.html";
            }
        });

        //改写app的裁剪图片
        if (!worf.device.wap) {
            $("#selFile").off("click").click(function (e) {
                e.preventDefault();
                window.app && window.app.uploadcall(worf.user.getToken());
                return false;
            });

            //app的裁剪图片 - 回调
            window.uploadCallback = function (url) {
                $("#imgPhoto").attr("src", url).show();
            }
        }
    }

    function uploadAvatar(callback) {
        var hash = window.location.hash;
        if (hash.indexOf("clip-ok")>-1) {
            var avatar = worf.localStorage.get("user-photo-final");
            if (avatar) {
                $("#imgPhoto").attr("src", avatar).show();
                ajax.uploadAvatar({ avatar: avatar.substr(avatar.indexOf(',') + 1) }, function() {
                    window.location.hash = "";
                    callback && callback();
                });
            }
        } else {
            callback && callback();
        }
    }

    window.loadData = function() {
        getUserInfo();
    };

    window.init = function() {
        initUpload();
        uploadAvatar(getUserInfo);
        $("#btnLoginOut").click(loginOut);
        $("#linkPwd").click(function() {
            worf.nav.go("/view/user/setLoginPwd.html");
        });
    };
})();

