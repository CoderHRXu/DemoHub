var shareOptions = {
    "title": "你的好友邀你一起赚钱！ ",
    "msg": "苦等机会，不如主动出击！",
    "url": worf.origin + "/promote.html",
    "shareId": "invite-001"
}

var getData = function() {
    if (!worf.user.isLogin()) {
        return;
    }

    worf.ajax({
        url: worf.API_URL + "/v1/user/queryMyInvited.json",
        success: function(json) {
            if (json.status == 1) {
                $("#spTotal").text(json.data.count || "0");
                $("#pAward").text("￥" + (json.data.reward || "0"));
                if (!json.data.list) {
                    $("#rowEmpty").removeClass("hide");
                    return;
                }
                var html = [];
                $(json.data.list || []).each(function(index, item) {
                    html.push('<li class="row"><span>' + worf.tools.phoneEncrypt(item.phone) + '</span><span>' + item.registerDate + '</span><span>' + item.cardState + '</span></li>');
                });
                if (json.data.list.length > 0) {
                    $("#ulList li.row").remove();
                    $("#ulList").append(html.join(""));
                }

            } else {
                worf.prompt.tip(json.message);
            }
        }
    });
}

/**
 * 显示二维码
 */
function showQR() {
    var width = 0.68 * _FONT_SIZE;
    new QRCode(document.getElementById("qrCode"), {
        width: width,
        height: width,
        colorLight: "#FFFFFF",
        colorDark: "#333333",
        text: worf.origin + "/promote.html",
        correctLevel: QRCode.CorrectLevel.L
    });
}

/**
 * 获取用户手机号
 */
function getUserPhone() {
    worf.app.ready(function() {
        if (!worf.user.isLogin()) {
            wxShare.init(shareOptions);
            return;
        }

        worf.ajax({
            data: {
                key: worf.tools.getTimestamp()
            },
            url: worf.API_URL + "/v1/user/getUserHomePageInfo.json",
            success: function(json) {
                if (json.status == 1) {
                    shareOptions.url += "?invation=" + json.data.userPhone;
                    wxShare.init(shareOptions);
                } else {
                    worf.prompt.tip(json.message);
                }
            }
        });
    });
}

$(function() {
    getUserPhone();
    getData();
    showQR();
    //分享
    $("#shareWrap").click(function() {
        wxShare.startShare(shareOptions);
    });
    $("#btnClose").click(function() {
        worf.nav.back();
    });
    if (!worf.device.wap) {
        $("#btnClose").removeClass("hide");
    }

    $("#linkReward").click(function() {
        worf.nav.go(worf.origin + "/view/user/invitationRule.html");
    });
});