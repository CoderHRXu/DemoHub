$(function() {
    init();
});

/*********************************
 * 第三方登录
 *********************************/
(function($) {
    var codeFlag = false; //标记是否已获取短信验证码
    var visitorId = worf.localStorage.get(worf.localStorage.keys.visitorCode) || worf.tools.getTimestamp();
    var ajax = {
            /*第三方登录-绑定已有账号&注册*/
            bind: function(options, callback) {
                var url = { wx: "authWXRegister.json", wb: "authWeiBoRegister.json", qq: "authQQRegister.json" }[options.type];
                worf.ajax({
                    data: options.data,
                    url: worf.API_URL + "/v1/userAuth/" + url,
                    success: function(json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            },
            /*第三方登录绑定-发送手机验证码*/
            sendCode: function(data, callback) {
                worf.ajax({
                    data: data,
                    url: worf.API_URL + "/v1/user/sendVerificationCode.json",
                    success: function(json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            }
        }
        /**
         * 第三方登录
         */
    var otherLogin = {
        type: 1, //第三方登录类型
        openId: "", //第三方登录id
        /*rjs登录*/
        rjsLogin: function() {
            worf.ajax.overlayShow();
            window.thirdPartyLogin && thirdPartyLogin.rjsLogin();
        },
        /* qq登录*/
        qqlogin: function() {
            worf.ajax.overlayShow();
            window.thirdPartyLogin && thirdPartyLogin.qqLogin();
        },
        /* 微博登陆*/
        wblogin: function() {
            worf.ajax.overlayShow();
            window.thirdPartyLogin && thirdPartyLogin.wbLogin();
        },
        /*微信登录*/
        wxLogin: function() {
            worf.ajax.overlayShow();
            window.thirdPartyLogin && thirdPartyLogin.wxLogin();
        },
        /*登录成功*/
        loginSuccess: function() {
            var token = worf.cookie.get("session_token_dd");
            var fromApp = worf.tools.queryString("requestfrom");
            worf.cookie.del("fromIndex");
            if (fromApp == "app") {
                if (otherLogin.type == "rjs") {
                    window.app && app.goHome && app.goHome(token);
                    window.app && app.goIos && app.goIos(token);
                } else {
                    window.app && window.app.loginCall(token);
                }
            } else {
                if (!worf.device.wap) {
                    window.app && window.app.loginCall(token);
                    return;
                }
                worf.nav.back();
            }

            //var token = worf.cookie.get("session_token_dd");
            //var fromApp = worf.tools.queryString("requestfrom");
            //var fromIndex = (worf.tools.queryString("fromIndex") || worf.cookie.get("fromIndex")) ? true : false;
            //worf.cookie.del("fromIndex");
            //if (fromApp == "app") {
            //    if (otherLogin.type == "rjs") {
            //        window.app && app.goHome && app.goHome(token, fromIndex);
            //        window.app && app.goIos && app.goIos(token, fromIndex);
            //    } else {
            //        window.app && window.app.loginCall(token, fromIndex);
            //    }
            //} else {
            //    if (!worf.device.wap) {
            //        window.app && window.app.loginCall(token, fromIndex);
            //        return;
            //    }
            //    worf.nav.back();
            //}
        },
        /**
         * 第三方登录的回调
         * @param index 第三方类型（1: "wx", 2: "qq", 3: "wb", 4: "rjs"）
         * @code 第三方回调参数 (thirdToken或者thirdId)
         * @unionid 第三方回调参数
         * @isWap 
         */
        loginCallback: function(index, code, unionid, isWap) {
            otherLogin.type = { 1: "wx", 2: "qq", 3: "wb", 4: "rjs" }[index];
            var url = { 1: "authWXLogin.json", 2: "authQQLogin.json", 3: "authWeiBoLogin.json", 4: "authLogin.json" }[index];
            var data = {};
            if (isWap && index != 4) {
                data.thirdToken = code;
            } else {
                //app
                data.thirdId = code;
                data.unionid = unionid;
            }
            data = JSON.stringify({ platform: worf.device.name, data: data });
            $.ajax({
                type: 'POST',
                url: worf.API_URL + "/v1/userAuth/" + url,
                dataType: 'json',
                contentType: "application/json",
                data: data,
                success: function(json) {
                    worf.ajax.overlayHide();
                    if (otherLogin.type == "rjs") {
                        var fromApp = worf.tools.queryString("requestfrom");
                        if (json.status == 1) {
                            worf.cookie.set("session_token_dd", json.data);
                            otherLogin.loginSuccess();
                        } else {
                            worf.prompt.fail("授权失败");
                            if (fromApp == "app") {
                                window.app.finish();
                            }
                        }
                    } else if (json.status == 3) {
                        var name = { 1: "微信", 2: "qq", 3: "新浪微博" }[index];
                        otherLogin.openId = json.data.openid;
                        otherLogin.showSuccessBox(name);
                    } else if (json.status == 1) {
                        worf.cookie.set("session_token_dd", json.data.uid || json.data);
                        otherLogin.loginSuccess();
                    } else {
                        worf.prompt.fail(json.message || "授权失败");
                    }
                }
            });
            setTimeout(function() { worf.ajax.overlayHide(); }, 300);
        },
        /*登录成功，弹出选择框*/
        showSuccessBox: function(name) {
            $("#wxloginFirst #thirdName").html("与" + name + "绑定，更加方便快捷！");
            $("#selectDialog").removeClass("hide");
        },
        /*隐藏选择框*/
        hideBox: function() {
            $("#selectDialog").addClass("hide");
        },
        /*登录成功，弹出注册框*/
        showRegister: function() {
            $("#selectDialog").addClass("hide");
            $("#regDialog").removeClass("hide");
            //加载图片验证码
            otherLogin.showImgCode();
            $("#btnPicCode").off().click(otherLogin.showImgCode);
            $("#btnCode").off().click(otherLogin.getMsgCode);
        },
        /*隐藏注册框*/
        hideRegister: function() {
            $("#regDialog").addClass("hide");
            $("#selectDialog").removeClass("hide");
        },
        /*登录成功，弹出绑定框*/
        showBind: function() {
            $("#selectDialog").addClass("hide");
            $("#bindDialog").removeClass("hide");
        },
        /*隐藏绑定框*/
        hideBind: function() {
            $("#bindDialog").addClass("hide");
            $("#selectDialog").removeClass("hide");
        },
        /*绑定账号*/
        bind: function() {
            var phone = worf.tools.val("#txtBindPhone");
            var password = worf.tools.val("#txtBindPwd");
            if (!phone) {
                worf.prompt.tip("请输入手机号码");
                return;
            } else if (!/^1[3|4|5|8|7][0-9]{9}$/.test(phone)) {
                worf.prompt.tip("手机号码不正确");
                return;
            } else if (!password) {
                worf.prompt.tip("请输入密码");
                return;
            }
            var options = {
                type: otherLogin.type,
                data: {
                    phone: phone,
                    password: password,
                    openid: otherLogin.openId, //微博参数 && qq参数 && 微信参数
                    unionId: "" //微信独有参数
                }
            };
            ajax.bind(options, function(data) {
                worf.cookie.set("session_token_dd", data);
                otherLogin.loginSuccess();
            });
        },
        /*手机号注册*/
        register: function() {
            var phone = worf.tools.val("#txtRegPhone");
            var password = worf.tools.val("#txtRegPwd");
            var phoneCode = worf.tools.val("#txtRegPhoneCode");
            if (!phone) {
                worf.prompt.tip("请输入手机号码");
                return;
            } else if (!/^1[3|4|5|8|7][0-9]{9}$/.test(phone)) {
                worf.prompt.tip("手机号码不正确");
                return;
            } else if (!codeFlag) {
                worf.prompt.tip("请获取短信验证码");
                return false;
            } else if (!phoneCode) {
                worf.prompt.tip("请输入短信验证码");
                return;
            } else if (!/^\d{6}$/.test(phoneCode)) {
                worf.prompt.tip("短信验证码不正确");
                return;
            } else if (!password) {
                worf.prompt.tip("请输入密码");
                return;
            }

            var options = {
                type: otherLogin.type,
                data: {
                    phone: phone,
                    password: password,
                    phoneCode: phoneCode,
                    openid: otherLogin.openId, //微博参数 && qq参数 && 微信参数
                    unionId: "" //微信独有参数
                }
            };
            ajax.bind(options, function(data) {
                worf.cookie.set("session_token_dd", data);
                otherLogin.loginSuccess();
            });
        },
        /*更换图片验证码*/
        showImgCode: function() {
            $("#txtRegPicCode").val("").parent().find(".icon-delete").addClass("hide");
            $("#imgCode").attr("src", worf.API_URL + "/v1/captcha/captcha?id=" + visitorId + "&r=" + worf.tools.getTimestamp());
        },
        /*获取短信验证码*/
        getMsgCode: function() {
            var phone = worf.tools.val("#txtRegPhone");
            var picCode = worf.tools.val("#txtRegPicCode");
            if (!phone) {
                worf.prompt.tip("请输入手机号码");
                return false;
            } else if (!/^1[3|4|5|8|7][0-9]{9}$/.test(phone)) {
                worf.prompt.tip("手机号码格式不正确");
                return false;
            } else if (!picCode) {
                worf.prompt.tip("请输入图片验证码");
                return false;
            }

            /*倒计时*/
            function startTimer() {
                var label = $("#btnCode");
                worf.tools.countdown({
                    before: function() { label.off("click"); },
                    jump: function(time) { label.text(time + "秒"); },
                    after: function() {
                        label.text("获取验证码").click(otherLogin.getMsgCode);
                        otherLogin.showImgCode();
                    }
                });
            }

            ajax.sendCode({ phone: phone, captcha: picCode, clientId: visitorId }, function(data) {
                startTimer();
                codeFlag = true;
                if (data) worf.prompt.tip(data);
            });
        },
        /*web登录回调*/
        autoLogin: function() {
            var from = worf.tools.queryString("from");
            var code = worf.tools.queryString("code");
            if (from) {
                //回退跳到第三方的记录
                worf.history.back();
                var loginType = { wx: "1", qq: "2", wb: "3", "rjs": 4 }[from];
                otherLogin.loginCallback(loginType, code, null, true);
            }
        },
        /*切换第三方登录*/
        toggleThird: function() {
            $("#thirdIcon").toggleClass("hide");
            $("#thirdSwitch").find(".icon").toggleClass("icon-down").toggleClass("icon-up");
            $("#thirdText").toggleClass("hide");
        },
        /* 修复键盘 (弹起时第三方登录位置问题)*/
        fixKeyboard: function() {
            var currHeight = $(window).height();
            var timer;
            $("#form input").on("focus", function() {
                timer && clearTimeout(timer);
                $("#thirdlogin").addClass("hide");
            }).on("blur", function() {
                show();
            });
            $(window).on("resize", function() {
                var el = $("#thirdlogin");
                var winHeight = $(window).height();
                if (winHeight >= currHeight) {
                    show();
                } else {
                    timer && clearTimeout(timer);
                    el.addClass("hide");
                }
                currHeight = winHeight;
            });

            function show() {
                timer && clearTimeout(timer);
                timer = setTimeout(function() { $("#thirdlogin").removeClass("hide"); }, 200);
            }
        },
        /*为输入框添加清除按钮*/
        toggleInput: function(el) {
            worf.tools.toggleInput(el, {
                getIcon: function(input) { return $(input).parent().find(".icon-close") },
                getInput: function(icon) { return $(icon).parent().find("input") }
            });
        },
        init: function() {
            otherLogin.fixKeyboard();
            $("#thirdText,#thirdSwitch").click(otherLogin.toggleThird);
            window.loginCallback = otherLogin.loginCallback;
            //worf.web.loginCallback = function (json) {
            //    if (!json.typeId) {
            //        json = JSON.parse(json);
            //    }
            //    otherLogin.loginCallback(json.typeId, json.openId,json.unionId);
            //}
            worf.web.loginCallback = function() {
                console.log("哈哈");
            }
            otherLogin.toggleInput("#regDialog input,#bindDialog input");
            if (!worf.device.wap) {
                worf.app.resume(function() {
                    worf.ajax.overlayHide();
                });
            }
        }
    };

    ///*
    //* 绑定app(登录成功后绑定app的推送的id)
    //*/
    //window.bindClientId = function (clientId) {
    //    if (!clientId) {
    //        return;
    //    }
    //    worf.ajax({
    //        url: worf.API_URL + "/v1/userPush/bindClient.json",
    //        animate: 1,
    //        data: {
    //            clientId: clientId
    //        },
    //        success: function (json) {
    //            //if (json.status != 1) {
    //            //    worf.prompt.tip(json.message);
    //            //}
    //        }
    //    });
    //}

    window.otherLogin = otherLogin;
    otherLogin.autoLogin();
})(window.Zepto);

/********************************
 *  常规登录
 *********************************/
(function($) {
    /**
     * 登录提交
     */
    function submit() {
        var name = worf.tools.val("#txtName");
        var password = worf.tools.val("#txtPwd");
        if (!name) {
            worf.prompt.tip("手机号码不能为空");
            return;
        } else if (!/^1[3|4|5|8|7][0-9]{9}$/.test(name)) {
            worf.prompt.tip("手机号码不正确");
            return;
        } else if (!password) {
            worf.prompt.tip("密码不能为空");
            return;
        }

        worf.ajax({
            url: worf.API_URL + "/v1/user/loginV2.json",
            data: {
                loginName: name,
                password: password
            },
            success: function(json) {
                if (json.status == 1) {
                    //更新缓存
                    worf.localStorage.set("user-info", JSON.stringify(json.data));
                    worf.cookie.set("session_token_dd", json.data.sessionToken);
                    otherLogin.loginSuccess();
                } else {
                    worf.prompt.tip(json.message);
                }
            }
        });
    }

    /**
     * 注册
     */
    window.goRegister = function() {
        worf.nav.go("/view/user/register.html");
    }

    /**
     * 忘记密码
     */
    window.goPassword = function() {
        worf.nav.go('/view/user/findpassword.html');
    }

    window.goback = function() {
        worf.nav.back();
        //var lastUrl = DD.history.getLast();
        //if (lastUrl && lastUrl.indexOf("activity") != -1) {
        //    worf.nav.back(lastUrl);
        //} else {
        //    worf.nav.back("/index.html");
        //}
    }

    /**
     * 切换输入框状态
     */
    function toggleInput(el) {
        //切换按钮状态
        function toggleButton() {
            var name = worf.tools.val("#txtName");
            var pwd = worf.tools.val("#txtPwd");
            if (!name || !pwd) {
                $("#btnLogin").removeClass("active").parent().find("button").removeClass("active");

            } else {
                $("#btnLogin").addClass("active").parent().find("button").addClass("active");
            }
        }

        worf.tools.toggleInput(el, {
            getIcon: function(input) { return $(input).parent().parent().find(".icon-delete") },
            getInput: function(icon) { return $(icon).parent().find("input") },
            callback: toggleButton
        });
    }

    /**
     * 眨眼睛
     */
    function changeEye() {
        var eye = $(this).find(".icon");
        var input = $(this).parent().find("input");
        var isClose = eye.is(".icon-eye-close");
        if (isClose) {
            eye.removeClass("icon-eye-close").addClass("icon-eye-open");
            input.attr("type", "text");
        } else {
            eye.removeClass("icon-eye-open").addClass("icon-eye-close");
            input.attr("type", "password");
        }
    }

    /**
     * 初始化
     */
    window.init = function() {
        $("#btnLogin").click(submit);
        $("#iconEye").click(changeEye);
        toggleInput("#txtName,#txtPwd");
        otherLogin.init();
    };
})(window.Zepto);