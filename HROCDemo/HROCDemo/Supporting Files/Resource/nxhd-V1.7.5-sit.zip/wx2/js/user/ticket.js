

/**
 * 抢单券记录
 */
(function ($) {
  var jroll,
    status = 0,
    isEnd = false,
    rowSize = 10;

  var ticket = {
    ajax: {
      /*产品列表*/
      list: function (data, callback) {
        //status-筛选条件 0: 全部 1：平台审核中 2:待选择门店 3: 门店签约 4: 审核失败
        data.rows = rowSize;
        worf.ajax({
          url: worf.API_URL + "/v1/userGifts/getDetails.json",
          data: data,//{ page: page,rows:12,status:0 },
          success: function (json) {
            if (json.status == 1) {
              callback && callback(json.data);
            } else {
              worf.prompt.tip(json.message);
            }
          }
        });
      }
    },
    /*初始化下刷新组件*/
    initScroll: function () {
      var that = this;
      jroll = new JRoll("#wrapper");
      jroll.infinite({
        total: 10000,
        g: 0.0012,
        getData: function (page, callback) {
          if (isEnd) {
            $("#scroller").find(".jroll-infinite-tip").html("已加载全部内容");
            return;
          }
          ticket.ajax.list({ pageNo: page }, function (data) {
            data = (data && data.giftList) || [];
            callback(data);
            if (data.length < rowSize) {
              isEnd = true;
              $("#scroller").find(".jroll-infinite-tip").html((page == 1 && data.length == 0) ? "当前无记录" : "已加载全部内容");
            }
          });
        },
        template: $("#template").html()
      });
      //下拉刷新
      jroll.pulldown({
        refresh: function (complete) {
          isEnd = false;
          jroll.options.page = 1;
          jroll.scroller.innerHTML = "";
          jroll.scrollTo(0, 0);
          ticket.ajax.list({ pageNo: 1}, function (data) {
            data = (data && data.giftList) || [];
            jroll.infinite_callback(data);
            complete();
            if (data.length < rowSize) {
              isEnd = true;
              $("#scroller").find(".jroll-infinite-tip").html((data.length == 0) ? "当前无记录" : "已加载全部内容");
            }
          });
        }
      });
    },
    /*显示券数量*/
    showNum: function() {
      $("#spNumber").text(worf.tools.queryString("num")||0);
    },
    /*初始化列表页*/
    init: function () {
      var that = this;
      that.initScroll();
    }
  };
  window.ticket = ticket;
})(Zepto);