(function ($) {
    var isEdit = false;
    var ajax = {
        /*删除产品*/
        del: function (data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/user/deleteUserProductList.json",
                success: function (json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*获取列表*/
        list: function (callback) {
            worf.ajax({
                url: worf.API_URL + "/v1/user/showUserProductList.json",
                success: function (json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        }
    };

    /**
    * 加载产品列表
    */
    function getList() { 
        var currentType, currentProduct;

        ajax.list(function (data) {
            $("#wrapper").empty();
            var types = data && data.userProductTypeList || {};
            for (var key in types) {
                renderType({ id: key, text: types[key] }, data.userProductList);
            }
        });

        /*渲染类型*/
        function renderType(type, products) {
            var typeIcon = type.id > 3 ? 3 : type.id;
            var html = [
                '<div class="wrap_pro">',
                '<dl class="pro_item" data-id="' + type.id + '">',
                ' <dt><span class="pro-type pro-type' + typeIcon + '"></span>' + type.text + '<span class="abs-right btn-add" data-type="' + (JSON.stringify(type).replace(/"/ig, "`")) + '"><i class="icon icon-add"></i></span></dt>'];
            var len = products.length;
            $.each(products, function (index, item) {
                if (item.productType == type.id) {
                    html.push(renderProduct(item, index+1 == len));
                }
            });
            html.push("</dl></div>");
            $("#wrapper").append(html.join(""));
            bindEvent();
        }

        /*
       * 渲染产品
       */
        function renderProduct(product,isLast) {
            var cssClass = isLast ? "" : "after-left15";
            var html = [
                '<dd data-id="' + product.id + '" class="' + cssClass + '">',
                    '<span class="pro_name">产品名称：' + product.productName + '</span>',
                    '<span class="abs-right btn-more" data-pro="' + (JSON.stringify(product).replace(/"/ig, "`")) + '"><i class="icon icon-more"></i></span>',
                '</dd>'
            ];
            return html.join("");
        }

        /*编辑产品*/
        function editProduct() {
            var id = currentProduct.id;
            worf.nav.go("/view/user/product-edit.html?type=edit&id=" + id + "&typeId=" + currentType.id + "&typeName=" + encodeURIComponent(currentType.text));
        }

        /**删除产品*/
        function delProduct() {
            var id = currentProduct.id;
            ajax.del([id], function (data) {
                worf.prompt.tip("删除成功");
                setTimeout(function () { $("#wrapper dd[data-id='" + id + "']").remove(); }, 0.2 * 1000);
            });
        }

        /*弹出操作选择框*/
        function sliderUpBox() {
            worf.ui.slideUpBox({
                data: { 1: "编辑", 2: "删除" },
                select: function (data) {
                    if (data.value == 1) {
                        editProduct();
                    } else {
                        delProduct();
                    }
                }
            });
        }


        /*绑定事件*/
        function bindEvent() {
            $("#wrapper").off().click(function(e) {
                var me = $(e.target);
                if (me.is(".icon-add") || me.is(".icon-more")) {
                    me = me.parent();
                }
                if (me.is(".btn-add")) {
                    var type = JSON.parse(me.data("type").replace(/`/ig, '"'));
                    worf.nav.go('/view/user/product-edit.html?typeId=' + type.id + '&typeName=' + encodeURIComponent(type.text));
                } else if (me.is(".btn-more")) {
                    var btnAdd = me.parent().parent().find("dt .btn-add");
                    currentType = JSON.parse(btnAdd.data("type").replace(/`/ig, '"'));
                    currentProduct = JSON.parse(me.data("pro").replace(/`/ig, '"'));
                    sliderUpBox();
                }
            });
        }
    }

    /*
    * 刷新页面数据
    */
    window.loadData = function () {
        getList();
    }

    /**
     * 初始化
     */
    window.init = function () {
        getList();
    };
})(window.Zepto);



