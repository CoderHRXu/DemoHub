$(function () {
    init();
});

(function () {
    var step = 1;
    var codeFlag = false;
    var protocolFlag = false;
    var visitorId = worf.localStorage.get(worf.localStorage.keys.visitorCode) || worf.tools.getTimestamp();

    var ajax = {
        /*发送手机验证码*/
        sendCode: function (data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/user/sendPhoneCodePS.json",
                success: function (json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*下一步*/
        next: function (data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/user/resetPwdNextStep.json",
                success: function (json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*找回密码*/
        reset: function (data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/user/restPassword.json",
                success: function (json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        }
    };

    window.goback = function () {
        if (step == 2) {
            showStep1();
            return;
        }
        worf.nav.back();
    }

    /**
     * 更换图片验证码
     */
    function showImgCode() {
        $("#txtPicCode").val("").parent().find(".icon-delete").addClass("hide");
        $("#imgCode").attr("src", worf.API_URL + "/v1/captcha/captcha?id=" + visitorId + "&r=" + worf.tools.getTimestamp());
    };

    /**
     * 注册成功
     */
    function registerSuccess() {
        worf.nav.go("/index.html", false, { backHide: true });
    };

    /**
     * 获取短信验证码
     */
    window.getMsgCode = function () {
        var phone = worf.tools.val("#txtPhone");
        var picCode = worf.tools.val("#txtPicCode");
        if (!phone) {
            worf.prompt.tip("请输入手机号码");
            return false;
        } else if (!/^1[3|4|5|8|7][0-9]{9}$/.test(phone)) {
            worf.prompt.tip("手机号码格式不正确");
            return false;
        }
        else if (!picCode) {
            worf.prompt.tip("请输入图片验证码");
            return false;
        }
        ajax.sendCode({ phone: phone, captcha: picCode, clientId: visitorId }, function (data) {
            startTimer();
            codeFlag = true;
            if (data) worf.prompt.tip(data);
        });
    };

    /**
     * 倒计时
     */
    function startTimer() {
        var label = $("#btnCode");
        worf.tools.countdown({
            before: function () { label.off("click"); },
            jump: function (time) { label.text(time + "秒"); },
            after: function() {
                label.text("获取验证码").click(getMsgCode);
                showImgCode();
            }
        });
    }


    /**
   * 切换输入框状态
   */
    function toggleInput(el) {
        worf.tools.toggleInput(el, {
            getIcon: function (input) { return $(input).parent().find(".icon-delete") },
            getInput: function (icon) { return $(icon).parent().find("input") },
            callback: null
        });
    }

    /**
   * 显示步骤1
   */
    function showStep1() {
        step = 1;
        $("#formStep1").removeClass("hide");
        $("#formStep2").addClass("hide");
        $("#btnProtocol").addClass("hide");
        $("#divStep .cycle").removeClass("active").eq(0).addClass("active");
    }

    /**
   * 显示步骤2
   */
    function showStep2() {
        step = 2;
        $("#formStep1").addClass("hide");
        $("#formStep2").removeClass("hide");
        $("#btnProtocol").removeClass("hide");
        $("#divStep .cycle").removeClass("active").eq(1).addClass("active");
    }

    /**
    * form校验
    */
    function checkForm() {
        var phone =worf.tools.val("#txtPhone");
        var code = worf.tools.val("#txtCode");
        var picCode = worf.tools.val("#txtPicCode");
        if (!phone) {
            worf.prompt.tip("请输入手机号码");
            return false;
        } else if (!/^1[3|4|5|8|7][0-9]{9}$/.test(phone)) {
            worf.prompt.tip("手机号码格式不正确");
            return false;
        } else if (step==1 && !picCode) {
            worf.prompt.tip("请输入图片验证码");
            return false;
        }
        else if (!codeFlag) {
            worf.prompt.tip("请获取短信验证码");
            return false;
        } else if (code == "") {
            worf.prompt.tip("请输入短信验证码");
            return false;
        } else if (!/^[0-9]{6}$/.test(code)) {
            worf.prompt.tip("短信验证码格式不正确");
            return false;
        }
        return { phone: phone, phoneCode: code, captcha: picCode };
    }

    /**
     * 提交-下一步
     */
    function next() {
        var data = checkForm();
        if (!data) {
            return false;
        }
        ajax.next(data, function (data) {
            showStep2();
        });
    }

    /**
     * 提交-第二步
     */
    function submit() {
        var data = checkForm();
        if (!data) {
            return false;
        }
        var password =worf.tools.val("#txtPassword");
        if (!password) {
            worf.prompt.tip("请输入密码");
            return false;
        } else if (!/^[a-zA-Z0-9]{6,16}$/.test(password)) {
            worf.prompt.tip("密码格式不正确");
            return false;
        }
       
        ajax.reset($.extend(data, {
            newPassword: password
            }),function (data) {
                worf.prompt.success("密码重置成功，请重新登录", function () {
                    worf.user.goLogin(true);
                });
            });
    }

    /*眨眼睛*/
    function changeEye() {
        var eye = $(this).find(".icon");
        var input = $(this).parent().find("input");
        var isClose = eye.is(".icon-eye-close");
        if (isClose) {
            eye.removeClass("icon-eye-close").addClass("icon-eye-open");
            input.attr("type", "text");
        } else {
            eye.removeClass("icon-eye-open").addClass("icon-eye-close");
            input.attr("type", "password");
        }
    }

    /**
     * 初始化
     */
    window.init = function () {
        //加载图片验证码
        showImgCode();
        $("#btnPicCode").click(showImgCode);
        //文本框效果
        toggleInput("#txtPhone,#txtPicCode,#txtCode,#txtPassword");
        $("#iconEye").click(changeEye);
        //按钮事件
        $("#btnNext").click(next);
        $("#btnCode").click(getMsgCode);
        $("#btnSave").click(submit);
    };
})();