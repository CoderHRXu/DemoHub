/*
* 左滑插件
**/
(function () {
    var LSwiperMaker = function (o) {
        var that = this;
        this.config = o;
        this.control = false;
        this.sPos = {};
        this.mPos = {};
        this.dire;
        // this.config.bind.addEventListener('touchstart', function(){ return that.start(); } ,false);
        // 这样不对的，event对象只在事件发生的过程中才有效;
        this.config.bind.addEventListener('touchstart', function (e) { return that.start(e); }, false);
        this.config.bind.addEventListener('touchmove', function (e) { return that.move(e); }, false);
        this.config.bind.addEventListener('touchend', function (e) { return that.end(e); }, false);
    }

    LSwiperMaker.prototype.start = function (e) {
        GlobalFastClick.trackingClick = false;
        GlobalFastClick.targetElement = null;
        var point = e.touches ? e.touches[0] : e;
        this.sPos.x = point.screenX;
        this.sPos.y = point.screenY;
        //console.log("开始位置是：" + this.sPos.x);
    }
    LSwiperMaker.prototype.move = function (e) {
        GlobalFastClick.trackingClick = false;
        GlobalFastClick.targetElement = null;
        var point = e.touches ? e.touches[0] : e;
        this.control = true;
        this.mPos.x = point.screenX;
        this.mPos.y = point.screenY;
        //console.log( "您的位置是：" + this.mPos.x );
    }

    LSwiperMaker.prototype.end = function (e) {
        GlobalFastClick.trackingClick = false;
        GlobalFastClick.targetElement = null;
        this.dire = 'R';
        var deltaY = this.mPos.y - this.sPos.y;
        if (this.config.dire_h && (deltaY < 50 && deltaY > -50)) {
            if (this.mPos.x > this.sPos.x) {
                this.dire = 'R';
            } else {
                this.dire = 'L';
            }
        }
        this.control = false;
        this.config.backfn(this);

    }
    window.LSwiperMaker = LSwiperMaker;
    //document.addEventListener('touchmove', function (e) { e.preventDefault(); }, false);// 禁止微信touchmove冲突
})();

/**
* 消息 
*/
(function ($) {
    var jroll ,isEnd=false,rowSize=12;
    var message = {
        ajax: {
            /*消息列表*/
            list: function (page, callback) {
                worf.ajax({
                    url: worf.API_URL + "/v1/message/getAllMessage.json",
                    data: { pageNo: page },
                    success: function (json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            },
            /*读取一条记录*/
            get: function (id, callback) {
                worf.ajax({
                    url: worf.API_URL + "/v1/message/readMsg.json",
                    data: { id: id },
                    success: function (json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            },
            /*删除一条记录*/
            remove: function (id, callback) {
                worf.ajax({
                    url: worf.API_URL + "/v1/message/deleteMsg.json",
                    data: { id: id },
                    success: function (json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            },
            /*全部已读*/
            readAll: function (callback) {
                worf.ajax({
                    url: worf.API_URL + "/v1/message/setRead.json",
                    data: {},
                    success: function (json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            }
        },
        /**
         * 初始化下刷新组件
         */
        initScroll: function () {
            var that = this;
            jroll = new JRoll("#wrapper");
            jroll.infinite({
                total: 10000,
                g: 0.0012,
                //iconUpdate:"<span style='color:red'>A</span>",
                getData: function (page, callback) {
                    if (isEnd) {
                        $("#scroller").find(".jroll-infinite-tip").html("已加载全部内容");
                        return;
                    }
                    message.ajax.list(page, function (data) {
                        data = data || [];
                        $.each(data, function(index, item) {
                            item.content = $("<p>" + item.content + "</p>").text().substr(0, 30);
                        });
                        callback(data);
                        that.bindSwiper();
                        if(data.length<rowSize){
                            isEnd = true;
                            $("#scroller").find(".jroll-infinite-tip").html((page == 1 && data.length ==0) ? "没有查询到记录" : "已加载全部内容");
                        }
                    });
                },
                template: $("#template").html()
            });
            jroll.on("scroll", function() {
                GlobalFastClick.trackingClick = false;
                GlobalFastClick.targetElement = null;
            });
            jroll.on("scrollStart", function () {
                GlobalFastClick.trackingClick = false;
                GlobalFastClick.targetElement = null;
            });
            jroll.on("scrollEnd", function () {
                GlobalFastClick.trackingClick = false;
                GlobalFastClick.targetElement = null;
            });
            //下拉刷新
            jroll.pulldown({
                refresh: function (complete) {
                    isEnd = false;
                    jroll.options.page = 1;
                    jroll.scroller.innerHTML = "";
                    jroll.scrollTo(0, 0);
                    message.ajax.list(1, function (data) {
                        data = data || [];
                        $.each(data, function (index, item) {
                            item.content = $("<p>" + item.content + "</p>").text().substr(0, 30);
                        });
                        jroll.infinite_callback(data);
                        that.bindSwiper();
                        complete();
                        if (data.length < rowSize) {
                            isEnd = true;
                            $("#scroller").find(".jroll-infinite-tip").html((!data || (data.length == 0)) ? "没有查询到记录" : "已加载全部内容");
                        }
                    });
                }
            });
        },
        /**
        * 绑定左滑
        */
        bindSwiper: function () {
            var that = this;
            $("#scroller .ms-item").each(function (index) {
                var a = new LSwiperMaker({
                    bind: this, // 绑定的DOM对象
                    dire_h: true, //true 判断左右， false 判断上下
                    backfn: function (o) { //回调事件
                        if (o.dire == "L") {
                            var self = $(this.bind);
                            //防止重复提交
                            if (window.leftDroping) return;
                            window.leftDroping = true;
                            var messageId = self.data("id");
                            $("#scroller .on").removeClass("on");
                            window.clearTimeout(window.dropTimer);
                            window.dropTimer = setTimeout(function () { window.leftDroping = false; }, 300);
                            //执行左滑动画
                            $(this.bind).addClass("on");
                            //绑定删除事件
                            $(this.bind).find(".remove").off("click").click(function (event) {
                                event.stopPropagation();
                                that.remove(messageId,self);
                                return false;
                            });
                        } else {
                            $(".scroller .on").removeClass("on");
                        }
                    }
                });
            });
        },
        /*全部已读*/
        readAll: function () {
            this.ajax.readAll(function (data) {
                $("#scroller i.ms-redpoint").css("opacity", "0");
                worf.prompt.tip("标记成功");
            });
        },
        /*删除1条*/
        remove: function (id,element) {
            this.ajax.remove(id, function (data) {
                isEnd = false;
                var parent = element.parent();
                element.remove();
                var h = 0;
                parent.children().each(function(index,item) {
                    h += $(item).height();
                });
                parent.height(h);
                jroll.refresh();
                //loadData();
            });
        },
        /*初始化列表页*/
        init: function () {
            var that = this;
            that.initScroll();
            $("#btnReadAll").off("click").click(function () { that.readAll(); });
            window.showDetail = function (id) {
                $("#scroller .ms-item[data-id='"+id+"'] i.ms-redpoint").css("opacity", "0");
                worf.nav.go("/view/user/messageInfo.html?id=" + id);
            };
        },
        /*初始化详情页*/
        detailInit: function () {
            var id = worf.tools.queryString("id");
            this.ajax.get(id, function (data) {
                if (data) {
                    $("#title").html(data.title);
                    $("#content").html(data.content);
                    $("#date").html(data.create_date);
                    $("#sign").html(data.sign);
                } else {
                    worf.prompt.tip("未查询到此条消息的详情");
                }
            });
        }
    };
    //window.loadData = function () {
    //    isEnd = false;
    //    jroll.destroy();
    //    that.initScroll();
    //}
    window.sysMessage = message;
})(Zepto);