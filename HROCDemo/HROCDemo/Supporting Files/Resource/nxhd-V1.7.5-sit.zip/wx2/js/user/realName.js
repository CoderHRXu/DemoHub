$(function() {
    $("#submit").click(submit);
});

/**
* 提交
*/
function submit() {
    var failCount =parseInt(worf.cookie.get("idvarNameFailCount")||0);
	if (failCount >= 3) {
	    worf.prompt.fail("实名认证已失败三次，请联系客服处理");
		return false;
	}

	var realName = worf.tools.val("#txtName");
	var number = worf.tools.val("#txtNum");
	if (!realName) {
	    worf.prompt.tip("请输入姓名", "", -1);
	    return false;
	} else if (!/^[\u4E00-\u9FA5]+$/ig.test(realName)) {
	    worf.prompt.tip("姓名格式不正确", "", -1);
	    return false;
	} else if (!number) {
	    worf.prompt.tip("请输入身份证号码", "", -1);
	    return false;
	} else if (!/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/ig.test(number)) {
	    worf.prompt.tip("身份证号码格式不正确", "", -1);
	    return false;
	}
	
	worf.ajax({
	    url: worf.API_URL + "/v1/user/authCardNo.json",
		data:{
			cardName:realName,
			cardNo: number
		},
		success: function(json){
			if(json.status==1){
			    worf.prompt.success("验证成功",goback);
			}else{
			    if (json.message.indexOf("认证失败") > -1) {
			        failCount++;
			        worf.cookie.set("idvarNameFailCount", failCount, "", "", 1);
				}
				worf.prompt.tip(json.message);
			}
		}
	});	
}

/**
* 返回 
*/
function goback() {
  var lastUrl = worf.history.getLast();
	if (lastUrl.indexOf("registerSuccess.html") > -1) {
	  worf.nav.back("/view/user/me.html");
	} else {
	  worf.nav.back();
	}
}