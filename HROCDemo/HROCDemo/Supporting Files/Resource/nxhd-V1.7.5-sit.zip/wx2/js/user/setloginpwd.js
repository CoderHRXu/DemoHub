$(function () {
    init();
});

(function () {

    var ajax = {
        /*检查旧密码*/
        checkOldPwd: function (data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/user/updatePasswordNextStep.json",
                success: function (json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*保存新密码*/
        saveNewPwd: function (data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/user/updatePassword.json",
                success: function (json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        }
    };

    /**
      * 检查旧手机号码
      */
    function check() {
        var code = worf.tools.val("#txtOldPwd");
        if (!code) {
            worf.prompt.tip("请输入原登录密码");
            return;
        }
        ajax.checkOldPwd({ password: code }, function (data) {
            $("#newDialog").removeClass("hide");
        });
    }

    /**
    * 提交新手机号码
    */
    function submit() {
        var oldPwd = worf.tools.val("#txtOldPwd");
        var newPwd = worf.tools.val("#txtNewPwd");
        if (!oldPwd) {
            worf.prompt.tip("请输入原登录密码");
            return;
        } else if (!newPwd) {
            worf.prompt.tip("请输入新登录密码");
            return;
        }
        ajax.saveNewPwd({ password: oldPwd, newPassword: newPwd }, function (data) {
            worf.prompt.success("修改成功", function () {
                worf.nav.back();
            });
        });
    }

    /**
    * 眨眼睛
    */
    function changeEye() {
        var me = $(this).find("i");
        var isClose = $(me).is(".icon-eye-close");
        me.toggleClass("icon-eye-close").toggleClass("icon-eye-open");
        me.parent().parent().find("input").attr("type", isClose?"text":"password");
    }

    /**
     * 初始化
     */
    window.init = function () {
        $("#iconEye1,#iconEye2").click(changeEye);
        $("#btnNext").click(check);
        $("#btnSubmit").click(submit);
    };
})();