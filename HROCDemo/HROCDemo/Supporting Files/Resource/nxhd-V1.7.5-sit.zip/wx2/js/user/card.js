$(function() {
    init();
});

(function() {
    var defaultPhoto = "../../img/user/default-photo.png?v=201608";
    /**
     * 选择项定义
     */
    var itemConfig = {
        sex: { "2": "男", 1: "女" },
        //担保   小贷   银行   理财  典当    P2P  其他
        companyType: { 0: "担保", 1: "小贷", 2: "银行", 3: "理财", 4: "典当", 5: "P2P", 6: "其他" },
        //车辆贷款  房产质押贷款  小额贷款  银行抵押贷款  银行信用贷款  其他
        companyCoreBusiness: { 0: "车辆贷款", 1: "房产质押贷款", 2: "小额贷款", 3: "银行抵押贷款", 4: "银行信用贷款", 5: "其他" }
    };
    var ajax = {
        /*读取名片信息*/
        getCardInfo: function(data, callback, error) {
            worf.ajax({
                url: worf.API_URL + "/v1/user/showBusinessCardInfo.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                },
                error: error
            });
        },
        /*获取TA的名片信息*/
        getTACard: function(data, callback, error) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/user/showBusCardNoToken.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                },
                error: error
            });
        }
    };
    /**
     * 读取名片信息
     */
    function loadUserInfo() {
        var data = {};
        var ajaxFunc = ajax.getCardInfo;
        if (window.location.href.indexOf("card-info.html") > -1) {
            //TA的名片
            data = { id: parseInt(worf.tools.queryString("uid") || "0", 10) };
            ajaxFunc = ajax.getTACard;
        }
        ajaxFunc.apply(this, [data, function(data) {
            worf.localStorage.set("user-card-detail", JSON.stringify(data));
            //头像
            var photo = worf.localStorage.get("user-photo-final");
            $("#imgPhoto").attr("src", data.iconPath || photo || defaultPhoto);
            if (data) {
                data.workYear = (data.workYear || 0) + "年";
                data.companyType = itemConfig.companyType[data.companyType] || " ";
                data.companyCoreBusiness = itemConfig.companyCoreBusiness[data.companyCoreBusiness] || " ";
                data.productCount = (data.productCount || 0) + "个";
                var areas = (data.provinceAndCityName || " ").split(/[\s\,\/]/ig);
                if (areas[0] == areas[1]) {
                    data.provinceAndCityName = areas[0];
                }
            }
            var sexCss = { 1: "icon-female", 2: "icon-male" }[data.sex];
            $("#iconSex").addClass(sexCss || "hide");
            if (sexCss) $("#iconSex").removeClass("hide");
            for (var key in data) {
                $("#sp_" + key).text(data[key]);
            }
            if (!data.wechat) {
                $("#sp_wechat").parent().hide();
            }
        }, function() {
            var userInfo = JSON.parse(worf.localStorage.get("user-info") || "{}");
            if (userInfo.userPhone) {
                userInfo.iconPath && $("#imgPhoto").attr("src", userInfo.iconPath);
                $("#sp_userPhone").text(userInfo.userPhone || "&nbsp;");
                $("#sp_userName").text(userInfo.userName || "&nbsp;");
            }
        }]);
    }

    /**
     * 刷新数据（app回退到此页）
     */
    window.loadData = function() {
        loadUserInfo();
    }

    window.init = function() {
        $("#imgPhoto").off().on("error", function() {
            this.src = defaultPhoto;
        });
        loadUserInfo();
    };
})();