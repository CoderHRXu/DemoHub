(function () {
  var totalScore = 0;
  var preScore = 50;//每张券对应积分
  var ticketNum = $("#ticketNum");
  var pageLevel = 0;
  var ajax = {
    //临时缓存数据
    ruleData: null,
    /*兑换*/
    exchange: function (data, callback) {
      if (worf.tools.requestLimit()) return;
      worf.ajax({
        data: data,
        animate: true,
        url: worf.API_URL + "/v1/userScores/exchange.json",
        success: function (json) {
          if (json.status == 1) {
            callback && callback(json.data);
          } else {
            worf.prompt.tip(json.message);
          }
        }
      });
    },
    /*获取积分规则*/
    getRule: function (callback) {
      worf.ajax({
        url: worf.API_URL + "/v1/userScores/exchangeList.json",
        success: function (json) {
          if (json.status == 1) {
            ajax.ruleData = json.data;
            callback && callback(json.data);
          } else {
            worf.prompt.tip(json.message);
          }
        }
      });
    }
  };

  /**
   * 修改需要的积分数
   */
  function updateCost(currentNum) {
    $("#costScore").text((currentNum * preScore) + "积分");
    if (currentNum == 0) {
      $("#btnSubmit").addClass("btn100-gray");
    } else {
      $("#btnSubmit").removeClass("btn100-gray");
    }
  }

  /**
  * 增加张数
  */
  function addTicket() {
    var currentNum = parseInt(ticketNum.text());
    if ((currentNum + 1) * preScore <= totalScore) {
      currentNum++;
    } else {
      worf.prompt.tip("积分不足");
    }
    ticketNum.text(currentNum);
    updateCost(currentNum);
  }

  /**
  * 减少张数
  */
  function plusTicket() {
    var currentNum = ticketNum.text();
    currentNum > 0 && currentNum--;
    ticketNum.text(currentNum);
    updateCost(currentNum);
  }

  /**
  * 提交
  */
  function submit() {
    var currentNum = parseInt(ticketNum.text(), 10);
    if (currentNum == 0) {
      worf.prompt.tip("最少兑换1张");
      return false;
    } else if (currentNum * preScore > totalScore) {
      worf.prompt.tip("积分不足");
      return false;
    }
    ajax.exchange({ exchangeNum: currentNum }, function (data) {
      totalScore -= currentNum * preScore;
      refreshScore();
      worf.prompt.success("兑换成功", function () {
        worf.nav.back();
      });
    });
  }

  /**
  * 显示积分规则
  */
  var ruleLoaded = false;
  function showRule() {
    ajax.getRule(function (data) {
      ruleLoaded = true;
      var html = [];
      $.each(data, function (index, item) {
        var i = 1 - index % 2;
        html.push(' <tr class="ticket-row' + i + '"><td class="ticket-left">' + item.displayName + '</td><td class="ticket-right">' + item.configValue + '</td></tr>');
      });
      $("#tbRule").append(html.join(""));

      //显示活动
      if (new Date().getTime() < new Date(2016, 12 - 1, 1).getTime()) {
        $("#divActivity").removeClass("hide");
      }
    });
  }

  /**
  * 刷新总积分
  */
  function refreshScore() {
    $("#totalScore").data("value", totalScore).text(totalScore);
    if (Math.floor(totalScore / 50) <= 0) {
      $("#ticketNum").text("0");
      $("#btnSubmit").addClass("btn100-gray");
    } else {
      $("#ticketNum").text("1");
      $("#btnSubmit").removeClass("btn100-gray");
    }
  }

  /**
   * 初始化
   */
  window.init = function () {
    //总积分
    var userInfo = JSON.parse(worf.localStorage.get("user-info") || "{}");
    totalScore = userInfo.scores || 0;
    refreshScore();
    $("#btnAdd").click(addTicket);
    $("#btnPlus").click(plusTicket);
    $("#btnSubmit").click(submit);
  };
  /**
  * 初始化-积分规则
  */
  window.initPoint = function () {
    showRule();
  }
})();

/**************************************
****** 积分记录
**************************************/
(function ($) {
  var jroll,
    status = 0,
    isEnd = false,
    rowSize = 10;

  /**
  * 产品
  */
  var points = {
    ajax: {
      list: function (data, callback) {
        data.rows = rowSize;
        worf.ajax({
          url: worf.API_URL + "/v1/userScores/getDetails.json",
          data: data,//{ page: page,rows:12,status:0 },
          success: function (json) {
            if (json.status == 1) {
              callback && callback(json.data);
            } else {
              worf.prompt.tip(json.message);
            }
          }
        });
      }
    },
    /*初始化下刷新组件*/
    initScroll: function () {
      var that = this;
      jroll = new JRoll("#wrapper");
      jroll.infinite({
        total: 10000,
        g: 0.0012,
        //iconUpdate:"<span style='color:red'>A</span>",
        getData: function (page, callback) {
          if (isEnd) {
            $("#scroller").find(".jroll-infinite-tip").html("已加载全部内容");
            return;
          }
          points.ajax.list({ pageNo: page}, function (data) {
            data = (data &&  data.scoreList) || [];
            callback(data);
            if (data.length < rowSize) {
              isEnd = true;
              $("#scroller").find(".jroll-infinite-tip").html((page == 1 && data.length == 0) ? "当前无记录" : "已加载全部内容");
            }
          });
        },
        template: $("#template").html()
      });
      //下拉刷新
      jroll.pulldown({
        refresh: function (complete) {
          isEnd = false;
          jroll.options.page = 1;
          jroll.scroller.innerHTML = "";
          jroll.scrollTo(0, 0);
          points.ajax.list({ pageNo: 1 }, function (data) {
            data = (data && data.scoreList) || [];
            jroll.infinite_callback(data);
            complete();
            if (data.length < rowSize) {
              isEnd = true;
              $("#scroller").find(".jroll-infinite-tip").html((data.length == 0) ? "当前无记录" : "已加载全部内容");
            }
          });
        }
      });
    },
    /*初始化列表页*/
    init: function () {
      var that = this;
      that.initScroll();
    }
  };
  window.points = points;
})(Zepto);