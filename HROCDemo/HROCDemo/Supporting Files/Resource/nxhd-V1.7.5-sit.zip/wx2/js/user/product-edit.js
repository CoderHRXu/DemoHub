//立即修改头部
var isEdit = worf.tools.queryString("type") == "edit";
$(".header p").text(isEdit ? "编辑产品" : "添加产品").removeClass("hide");

$(function () {
    init();
});

(function () {
    var editPageOpened = false;
    /**
    * 选择项定义
    */
    var itemConfig = {
        repaymentMethod: { 1: "等额等息", 2: "等额本金", 3: "等额本息", 4: "其他" },
        lendingTime: {1:"1个工作日",2:"2个工作日",3:"3个工作日",4:"4个工作日",5:"5个工作日",6:"6个工作日",7:"7个工作日",8:"7个工作日以上"}
    };
    var ajax = {
        /*读取定义*/
        getDefined: function (data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/common/getDefined.json",
                success: function (json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*查询产品*/
        get: function (data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/user/showUserProductById.json",
                success: function (json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*添加产品*/
        add: function (data, callback) {
            if (worf.tools.requestLimit()) return;
            worf.ajax({
                animate: true,
                data: data,
                url: worf.API_URL + "/v1/user/addProduct.json",
                success: function (json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*编辑产品*/
        edit: function (data, callback) {
            if (worf.tools.requestLimit()) return;
            worf.ajax({
                animate: true,
                data: data,
                url: worf.API_URL + "/v1/user/updateProduct.json",
                success: function (json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        }
    };

    /**
       * 读取产品信息
       */
    function getProductInfo() {
        var id = worf.tools.queryString("id");
        var typeId = worf.tools.queryString("typeId");
        var typeName = decodeURIComponent(worf.tools.queryString("typeName"));
        if (!isEdit) {
            $("#sp_productType").attr("data-value", typeId).html(typeName);
            return;
        }

        ajax.get(id, function (data) {
            if (data) {
                data.productTypeText = typeName;//产品类型
                data.cityIdsText = data.areaName;
                //还款方式
                data.repaymentMethodText = data.repaymentMethodName;
                //参考月利息
                data.monthlyInterestRate = data.monthlyInterestRateFrom + "," + data.monthlyInterestRateTo;
                data.monthlyInterestRateText = data.monthlyInterestRateFrom + "%~" + data.monthlyInterestRateTo + "%";
                //贷款期限
                data.repaymentTerm = data.repaymentTermFrom.replace("期", "") + "," + data.repaymentTermTo.replace("期", "");
                data.repaymentTermText = data.repaymentTermFrom + "期" + "~" + data.repaymentTermTo + "期";
                //放款时间
                data.lendingTimeText = itemConfig.lendingTime[data.lendingTime];
            }
            for (var key in data) {
                if (!/Text$/ig.test(key)) {
                    var text = (data[key + "Text"] || data[key]);
                    var element = $("#sp_" + key);
                    if (!element.data("readonly")) text += "<em></em>";
                    element.attr("data-value", data[key]).html(text);
                }
            };
        });
    }

    /**
      * 保存产品
      */
    function saveProduct() {
        var data = {};
        var isAll =true;//是否填写完整
        $("#form .form-value").each(function() {
            var me = $(this);
            var name = me.attr("id").replace("sp_", "");
            var required = me.data("required");
            var value = me.attr("data-value");
            if (required!=false && (value == "" || value==undefined)) {
                isAll = false;
            }
            data[name] = value;
        });

        if (!isAll) {
            worf.prompt.confirm("您的信息没有填写完整<br/>是否保存？", function () { worf.prompt.closeMe(); return false; }, function () { worf.nav.back(); }, { cancelText: "放弃", okText: "继续填写" });
            return;
        }

        //参考月利息
        var range = (data.monthlyInterestRate || "").split(",");
        if (range.length==2) {
            data.monthlyInterestRateFrom =parseFloat(range[0],10);
            data.monthlyInterestRateTo = parseFloat(range[1], 10);
            delete (data.monthlyInterestRate);
        }
        //贷款期限
        range = (data.repaymentTerm || "").split(",");
        if (range.length == 2) {
            data.repaymentTermFrom = parseInt(range[0], 10);
            data.repaymentTermTo = parseInt(range[1], 10);
            delete (data.monthlyInterestRate);
        }

        var callback = function (resData) {
            worf.prompt.success("保存成功", function () {
                var key = isEdit?"user-product-edit":"user-product-add";
                worf.localStorage.set(key, JSON.stringify({ id: data.id || resData.id, name: data.productName, type: data.productType }));
                worf.nav.back();
            });
        };
        isEdit ? ajax.edit(data, callback) : ajax.add(data, callback);
    }

    /**
     * 底部弹出滚动选择框-放款时间
     */
    function slideUpScrollBox() {
        var me = $(this),
               type = me.data("box-scroll"),
               config = itemConfig[type];
        worf.ui.slideUpScrollBox({
            el: me,
            level:1,
            currentValue:[me.find(".form-value").data("value")],
            data: config,
            selected: function (data) {
                me.find("#sp_" + type).attr("data-value", data[0].value).html(data[0].text + "<em></em>");
            }
        });
    }

    /**
    * 显示编辑form
    */
    function openEidt() {
        var me = $(this);
        var name = me.find("label").text();
        var element = me.find(".form-value");
        var elementId = element.attr("id");
        var mode = me.data("mode");
        var regex = me.data("regex");
        var inputMode = me.data("input");
        var regexMessage = me.data("regexms");
        var placeholder = me.attr("data-placeholder");
        var maxlength = me.data("maxlength");
        var helpTip = me.data("helptip");
        var rangeTitle = me.data("rangetitle");
        var inputGroup, getResult, check, rangeUnit, multiSelectData;
        if (elementId == "sp_monthlyInterestRate") {
            //参考月利率
            rangeUnit = "%";
            helpTip = "一位整数，最多2位小数";
            check = function (data) {
                var text = data.text;
                var temp = text.split(",");
                if (!temp[0] || !temp[1]) {
                    worf.prompt.tip("请输入参考月利率");
                    return false;
                } else if (!/^([1-9]|0)(\.\d{1,2})?$/ig.test(temp[0]) || !/^([1-9]|0)(\.\d{1,2})?$/ig.test(temp[1])) {
                    worf.prompt.tip("格式不正确");
                    return false;
                } else if (parseFloat(temp[0], 10) > parseFloat(temp[1], 10)) {
                    worf.prompt.tip("起始利率必须小于等于结束利率");
                    return false;
                }
                return true;
            };
        } else if (elementId == "sp_repaymentTerm") {
            //贷款期限
            rangeUnit = "期";
            check = function (data) {
                var text = data.text;
                var temp = text.split(",");
                if (!temp[0] || !temp[1]) {
                    worf.prompt.tip("请输入贷款期限");
                    return false;
                } else if (!/^[1-9]\d*\,[1-9]\d*$/ig.test(text)) {
                    worf.prompt.tip("请输入整数");
                    return false;
                } else if (parseInt(temp[0], 10) > parseInt(temp[1], 10)) {
                    worf.prompt.tip("起始期限必须小于等于结束期限");
                    return false;
                }
                return true;
            };
        } else if (elementId == "sp_repaymentMethod") {
            //还款方式
            multiSelectData = $.map(itemConfig.repaymentMethod, function(index, item) {
                return { text: itemConfig.repaymentMethod[item], value: item };
            });
            check = function (data) {
                var text = data.text;
                var temp = text.split(",");
                if (!temp[0]) {
                    worf.prompt.tip("请选择还款方式");
                    return false;
                } else if (temp.length>3) {
                    worf.prompt.tip("最多选择3个");
                    return false;
                } 
                return true;
            };
        } else if (elementId == "sp_cityIds") {
            //覆盖城市
            inputGroup = $("#cityTemplate").html();
            getResult = function (wrapper) {
                var value = [];
                var text = [];
                wrapper.find("#selectedCityWrapper .city-item").each(function () {
                    value.push($(this).data("id"));
                    text.push($(this).text());
                });
                return {text:text,value:value};
            }
        }

        worf.ui.editPage({
            mode: mode, //输入框的模式 input,textarea,range
            placeholder: placeholder,//提示信息
            maxlength:maxlength,//字数限制
            inputGroup: inputGroup, //输入框的html
            rangeUnit:rangeUnit,//范围值的单位：如：%
            text: element.text(), //当前文本
            regex: regex,//检验正则
            inputMode: inputMode,//输入模式：比如 tel，number
            regexMessage: regexMessage,//检验提示语
            value: element.attr("data-value"),//当前值
            rangetitle:rangeTitle,//范围值的头部
            helpTip:helpTip,//输入框下面的提示语
            name: name, //当前头部显示名称
            multiSelectData: multiSelectData,//多选项的数据
            getResult: getResult,//获取结果的方法
            check: check,//检查结果的方法
            success: function (data) {
                var text = data.text;
                var value =data.value;
                if (mode == "range") {
                    var texts = text.split(",");
                    element.data("value", texts).html(texts[0] + rangeUnit + " - " + texts[1] + rangeUnit + "<em></em>");
                } else if (mode == "multi-select" || mode=="city") {
                    element.data("value", value).html(text + "<em></em>");
                } else {
                    element.data("value", text).html(text + "<em></em>");
                }
            },
            opening: function (options) {
                editPageOpened = true;
                //改变当前显示的头部
                worf.nav.changeHeader(1);
                //设置添加标题
                worf.app.toogleTitle($("#editTitle").text(), {rightTitle:"保存"});
                if (elementId == "sp_cityIds") {
                    window.cityPicker.init({
                        scrollWrapper: !worf.device.wap ? $("#editInput") : $(document.body)
                    });
                }
            },
            opened: function(options) {
                if (elementId == "sp_cityIds") {
                    var values = (options.value||"").split(/,|、/ig);
                    $.each(options.text.split(/,|、/ig), function (index, item) {
                        if (values[index]) window.cityPicker.selectCity({ id: values[index], text: item });
                    });
                }
            },
            closed: function () {
                editPageOpened = false;
                //改变当前显示的头部
                worf.nav.changeHeader(0);
                //设置添加标题
                worf.app.toogleTitle($(".app-title").eq(0), { rightTitle: "保存" });
            }
        });
    }

    window.goback = function() {
        if (editPageOpened) {
            worf.ui.editPage.hide();
            return;
        }
        worf.nav.back();
    };

    /**
     * 获取定义
     */
    function getDefined() {
        ajax.getDefined(["userCompanyType", "companyBussinessType"], function (data) {
            itemConfig = $.extend(itemConfig, data);
        });
    }

    /**
   * 初始化
   */
    window.init = function () {
        getDefined();
        getProductInfo();
        $("#btnSave").click(saveProduct);
        $("[data-box-scroll]").click(slideUpScrollBox);
        $("[data-edit]").click(openEidt);
    };
})();

