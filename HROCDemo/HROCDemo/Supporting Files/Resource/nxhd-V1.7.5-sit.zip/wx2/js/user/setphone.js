$(function() {
    init();
});

(function() {
    var oldPhone = worf.tools.queryString("phone");
    var oldPhoneText =oldPhone.substr(0, 3) + "****" + oldPhone.substr(7, 4);
    var ajax = {
        /*发送旧手机验证码*/
        sendOldCode: function(data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/user/sendPhoneCode.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*验证旧手机*/
        checkOldPhone: function(data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/user/updateUserPhoneNextStep.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*发送新手机验证码*/
        sendNewCode: function(data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/user/sendNewPhoneCode.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*验证新手机*/
        checkNewPhone: function(data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/user/updateUserPhone.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        }
    };

    /**
    * 发送旧手机验证码
    */
    function sendOldCode() {
        ajax.sendOldCode({phone:oldPhone}, function(data) {
            var button = $("#btnOldCode");
            worf.tools.countdown({
                before: function () { button.off("click"); },
                jump: function (time) { button.text(time + "秒"); },
                after: function() {
                    button.text("获取验证码").click(sendOldCode); 
                    
                }
            });
        });
    }

    /**
   * 发送旧手机验证码
   */
    function sendNewCode() {
        var newPhone = worf.tools.val("#txtNewPhone");
        if (!newPhone) {
            worf.prompt.tip("请输入新手机号码");
            return;
        }
        ajax.sendNewCode({ phone: newPhone }, function (data) {
            var button = $("#btnNewCode");
            worf.tools.countdown({
                before: function () { button.off("click"); },
                jump: function (time) { button.text(time + "秒"); },
                after: function () { button.text("获取验证码").click(sendNewCode); }
            });
        });
    }

    /**
      * 检查旧手机号码
      */
    function checkOldPhone() {
        var code = worf.tools.val("#txtOldCode");
        if (!code) {
            worf.prompt.tip("请输入手机短信中的验证码");
            return;
        }
        var data = { phone: oldPhone, phoneCode: code };
        ajax.checkOldPhone(data, function (data) {
            worf.animate.sliderLeft("#newDialog");
            //改变当前显示的头部
            worf.nav.changeHeader(1);
        });
    }

    /**
    * 提交新手机号码
    */
    function submit() {
        var newPhone = worf.tools.val("#txtNewPhone");
        var code = worf.tools.val("#txtNewCode");
        if (!newPhone) {
            worf.prompt.tip("请输入新手机号码");
            return;
        }else if (!code) {
            worf.prompt.tip("请输入手机短信中的验证码");
            return;
        }
        ajax.checkNewPhone({ phone: newPhone, phoneCode: code }, function (data) {
            worf.prompt.success("修改成功", function () {
                worf.nav.back();
            });
        });
    }

    window.goback= function() {
        if ($("#newDialog").is(".slide_visible")) {
            worf.animate.sliderRight("#newDialog");
            //改变当前显示的头部
            worf.nav.changeHeader(0);
            return;
        }
        worf.nav.back();
    }

    /**
     * 初始化
     */
    window.init = function () {
        $("#oldPhone").text(oldPhoneText);
        $("#btnOldCode").click(sendOldCode);
        $("#btnNewCode").click(sendNewCode);
        $("#btnNext").click(checkOldPhone);
        $("#btnSubmit").click(submit);
    };
})();