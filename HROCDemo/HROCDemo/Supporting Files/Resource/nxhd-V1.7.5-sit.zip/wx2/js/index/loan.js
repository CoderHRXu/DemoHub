$(function() {
    init();
});

(function($) {
    var id = 0;
    /**
     * 选择项定义
     */
    var itemConfig = {
        sex: { "2": "男", 1: "女" },
        //上次解押时间
        previousReleaseTime: { "1": "一个月内", "2": "超过一个月", "3": "无抵押记录" },
        //是否接受抵押
        canMortgage: { "1": "接受抵押", "2": "不接受抵押" },
        //婚姻状况
        maritalStatus: { "1": "未婚", "2": "已婚", "3": "离异", "4": "丧偶" },
        //企业性质
        enterpriseNature: { "1": "机关事业", "2": "国企", "3": "外资/合资", "4": "社会团体", "5": "民营私营", "6": "个体" },
        //发薪方式
        payDeal: { "1": "代发", "2": "现金", "3": "代发+现金" },
        //24小时自动发布
        redeployAuto: { "1": "开启", "0": "关闭" },
        //购置状态
        typesOfPurchasing: { 0: "全款车", 1: "按揭中" }
    };
    var ajax = {
        /*读取定义*/
        getDefined: function(data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/common/getDefined.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*用户信息*/
        getUserInfo: function(callback) {
            worf.ajax({
                data: { key: worf.tools.getTimestamp() },
                url: worf.API_URL + "/v1/user/getUserHomePageInfo.json",
                errorTip: function(json) {
                    //console.log(json.message);
                },
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        //console.log(json.message);
                    }
                }
            });
        },
        /*读取车信息（品牌，系列）*/
        getCarType: function(data, callback) {
            worf.ajax({
                data: data,
                url: worf.API_URL + "/v1/car/carType.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*读取详情*/
        getDetail: function(data, callback) {
            worf.ajax({
                data: data,
                animate: true,
                url: worf.API_URL + "/v1/list/reSubmitApplyDetail.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*发布贷款需求*/
        apply: function(data, callback) {
            if (worf.tools.requestLimit()) return;
            worf.ajax({
                data: data,
                animate: true,
                url: worf.API_URL + "/v1/loan/apply.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        }
    };

    /**
     * 底部弹出选择框
     */
    function slideUpBox() {
        var me = $(this),
            type = me.data("box"),
            config = itemConfig[type];
        worf.ui.slideUpBox({
            data: config,
            select: function(data) {
                me.find(".form-value").attr("data-value", data.value).text(data.text).removeClass("color-gray");
                //【购置状态】为【按揭中】时显示【已按揭期数】
                if (type == "typesOfPurchasing") {
                    showRepaidMonth(data.value);
                }
            }
        });
    }

    /**
     * 控制已按揭期数的显示
     */
    function showRepaidMonth(type, month) {
        if (type == 1) {
            $("#divRepaidMonth").removeClass("hide");
            $("#sp_repaidMonth").attr("data-val", "required").val(month || "");
        } else {
            $("#divRepaidMonth").addClass("hide");
            $("#sp_repaidMonth").attr("data-val", "1").val("");
        }
    }

    /**
     * 底部弹出时间选择框
     */
    function datePick() {
        var me = $(this);
        var type = me.data("field");
        var value = me.find(".form-value").data("value");
        var year = value && value.substr(0, 4);
        var month = value && parseInt(value.substr(5, 2), 10);
        var day = value && parseInt(value.substr(8, 2), 10);
        worf.ui.datePicker({
            el: me,
            year: year,
            month: month,
            day: day,
            selected: function(year, month, day) {
                month = month < 10 ? "0" + month : month;
                day = day < 10 ? "0" + day : day;
                var data = year + "-" + month + "-" + day;
                me.find("#sp_" + type).attr("data-value", data).html(data).removeClass("color-gray");
            }
        });
    }

    /*控制页面滚动*/
    var scrollControl = {
        /*打开弹出页面时禁止滚动*/
        top: function() {
            window._scrollTop = document.body.scrollTop;
            document.body.scrollTop = 0;
            $("body").addClass("noscroll");
        },
        /*关闭弹出页面时还原位置*/
        original: function() {
            $("body").removeClass("noscroll");
            document.body.scrollTop = window._scrollTop || 0;
        }
    };

    /**
     * 显示编辑form
     */
    var editFlag = true;

    function openEidt() {
        var me = $(this);
        var name = me.find(".pull-left").text();
        var element = me.find(".form-value");
        var elementId = element.attr("id");
        var mode = me.data("mode");
        var rightText = me.data("title-righttext");
        var inputMode = me.data("input");
        var regex = me.data("regex");
        var helpTip = me.data("helptip");
        var regexMessage = me.data("regexms");
        var placeholder = me.data("placeholder");
        var maxlength = me.data("maxlength");
        var inputGroup, getResult, check, rangeUnit, multiSelectData;
        if (elementId == "sp_city") {
            inputGroup = $("#cityTemplate").html();
            getResult = function(wrapper) {
                var value = [];
                var text = [];
                wrapper.find("#selectedCityWrapper .city-item").each(function() {
                    value.push($(this).data("id"));
                    text.push($(this).text());
                });
                return { text: text, value: value };
            }
        } else if (elementId == "sp_brand") {
            inputGroup = $("#brandTemplate").html();
        } else if (elementId == "sp_licenseNum") {
            inputGroup = $("#carNoTemplate").html();
            getResult = function(wrapper) {
                var value = [];
                var text = [];
                var num = (wrapper.find(".carno-group").text() + wrapper.find("input").val()).replace(/\s/ig, "").toUpperCase();
                value.push(num);
                text.push(num);
                return { text: text, value: value };
            }
        }

        worf.ui.editPage({
            mode: mode, //输入框的模式 input,textarea,range
            placeholder: placeholder, //提示信息
            maxlength: maxlength, //字数限制
            regex: regex, //检验正则
            regexMessage: regexMessage, //检验提示语
            rightText: rightText, //头部右侧的按钮文字
            text: element.text(), //当前文本
            inputMode: inputMode, //输入模式：比如 tel，number
            value: element.attr("data-value"), //当前值
            name: name,
            helpTip: helpTip, //输入框下面的提示语
            multiSelectData: multiSelectData, //多选项的数据
            getResult: getResult, //获取结果的方法
            check: check, //检查结果的方法
            inputGroup: inputGroup, //输入框的html
            success: function(data) {
                var text = data.text;
                var value = data.value;
                var suffix = element.data("suffix") || "";
                if (suffix) {
                    text = text.replace(suffix, "") + suffix;
                }
                element.data("value", value).text(text).removeClass("color-gray");
            },
            opening: function(options) {
                //改变当前显示的头部
                worf.nav.changeHeader(1);
                var rightText = (elementId == "sp_city" || elementId == "sp_brand") ? "" : "保存";
                //设置添加标题
                worf.app.toogleTitle($("#editTitle").text(), { rightTitle: rightText });

                if (elementId == "sp_city") {
                    window.cityPicker.init({
                        scrollWrapper: !worf.device.wap ? $("#editInput") : $(document.body),
                        selectCity: function(data) {
                            worf.ui.editPage.hide();
                            options.success({ value: data.id, text: data.text });
                        }
                    });
                } else if (elementId == "sp_brand") {
                    window.carBrandPicker.init({
                        scrollWrapper: !worf.device.wap ? $("#editInput") : $(document.body),
                        selectModel: function(data) {
                            worf.ui.editPage.hide();
                            var series = window.carBrandPicker.currentData.series;
                            options.success({ value: data.id, text: series.text + " " + data.text });
                        }
                    });
                } else if (elementId == "sp_licenseNum") {
                    worf.ui.carNumPicker.init({ value: element.attr("data-value") });
                }
            },
            berforeOpening: function() {
                scrollControl.top();
            },
            closed: function() {
                editFlag = false;
                //改变当前显示的头部
                worf.nav.changeHeader(0);
                //设置添加标题
                worf.app.toogleTitle($(".app-title").eq(0), { rightTitle: "提交" });
                scrollControl.original();
            }
        });
    }

    /**
     * 获取定义
     */
    function getDefined(callback) {
        ajax.getDefined(["preRelease", "loanMortgageEnum", "maritalStatus", "enterpriseNature", "payDeal", "userSex"], function(data) {
            //属性匹配：key为接口定义名称，value为js定义的名称
            var mapping = {
                "preRelease": "previousReleaseTime", //上次解押时间
                "loanMortgageEnum": "canMortgage", //是否接受抵押
                "maritalStatus": "maritalStatus", //婚姻情况
                "enterpriseNature": "enterpriseNature", //企业性质
                "payDeal": "payDeal", //发薪方式
                "userSex": "sex" //性别
            };
            for (var key in mapping) {
                itemConfig[mapping[key]] = data[key];
            }
            callback && callback();
        });
    }

    /**
     * 返回
     */
    window.goback = function() {
        if (worf.ui.editPage.isOpen) {
            worf.animate.sliderRight("#editForm");
            //改变当前显示的头部
            worf.nav.changeHeader(0);
            //设置添加标题
            worf.app.toogleTitle($(".app-title").eq(0));
            return;
        }

        var isAny = false;
        $("#form .form-value").each(function() {
            var me = $(this);
            var value = $.trim(me.attr("data-value") || "");
            if (value) {
                isAny = true;
                return false;
            }
        });
        if (isAny) {
            worf.prompt.confirm("您填写的资料还未提交，是否放弃？", function() {
                worf.prompt.closeMe();
                return false;
            }, function() {
                worf.nav.back();
            }, { cancelText: "放弃", okText: "继续填写" });
            return;
        }
        if (id == 0 || worf.device.wap) {
            worf.nav.back();
        } else if (id > 0) {
            window.app && app.commitLoansAgainSuccess && app.commitLoansAgainSuccess();
        }
    }

    /**
     * 加载用户信息
     */
    function loadUserInfo() {
        var data = JSON.parse(worf.localStorage.get("user-info") || "{}");
        if (data.userName) {
            $("#sp_name").text(data.userName || "");
            $("#sp_phone").text(worf.tools.phoneEncrypt(data.userPhone || ""));
        } else {
            ajax.getUserInfo(function(data) {
                //更新缓存
                worf.localStorage.set("user-info", JSON.stringify(data));
                loadUserInfo();
            });
        }
    }

    /**
     * 还原数据
     */
    function restoreData() {
        id = worf.tools.queryString("id");
        if (!id) {
            return;
        }
        ajax.getDetail({ id: id }, function(data) {
            if (!data) {
                return;
            }
            data.brand = data.brandId;
            data.city = data.cityId;
            $(".form-value").each(function(index, item) {
                var me = $(item);
                var name = me.attr("name");
                var suffix = me.attr("suffix") || "";
                var value = data[name];
                if (value === undefined || value === null) {
                    value = "";
                }
                var text = (data[name + "Str"] || data[name]);
                if (me.is("input")) {
                    me.removeClass("color-gray").val(value);
                } else {
                    me.removeClass("color-gray").data("value", value).text(text);
                }
            });
            //购置状态
            showRepaidMonth(data.typesOfPurchasing, data.repaidMonth);
        });
    }

    /**
     * 保存借款需求
     */
    function saveLoan() {
        var data = worf.validate("#form", { filter: ".form-value" });
        if (!data) {
            return false;
        }
        //类型转换
        for (var key in data) {
            var value = data[key];
            if (/^(([1-9]\d*)|0)(\.\d{1,2})?$/.test(value)) {
                data[key] = parseFloat(value, 10);
            }
        }
        data.vehicleLicensingTime = getTimeStamp(data.vehicleLicensingTime);

        ajax.apply(data, function(data) {
            worf.prompt.success("提交成功", function() {
                if (id == 0 || worf.device.wap) {
                    worf.nav.back();
                } else if (id > 0) {
                    window.app && app.commitLoansAgainSuccess && app.commitLoansAgainSuccess();
                }
            });
        });

        /*获取的日期的毫秒数*/
        function getTimeStamp(dateStr) {
            var date = (dateStr || "").split("-");
            var year = parseInt(date[0], 10);
            var month = parseInt(date[1], 10);
            var day = parseInt(date[2], 10);
            return new Date(year, month - 1, day).getTime() / 1000;
        }
    }

    /**
     * 初始化
     */
    window.init = function() {
        loadUserInfo();
        getDefined();
        $("#signTime").click(datePick);
        $("#btnSave").click(saveLoan);
        $("[data-box]").click(slideUpBox);
        $("[data-edit]").click(openEidt);
        carBrandPicker.preloadData();
        restoreData();
    };
})(window.Zepto);