$(function () {
  init();
});

(function ($) {
  var codeFlag = false;//标记是否已获取短信验证码
  var filter = ".form-value";//验证的过滤选择器
  var visitorId = worf.tools.getTimestamp();
  //选择项定义
  var itemConfig = {
    typesOfPurchasing: { "0": "全款车", 1: "按揭车" }
  };
  var ajax = {
    /*发送手机验证码*/
    sendCode: function (data, callback) {
      worf.ajax({
        data: data,
        url: worf.API_URL + "/v1/loan/collectCode.json",
        success: function (json) {
          if (json.status == 1) {
            callback && callback(json.data);
          } else {
            worf.prompt.tip(json.message);
          }
        }
      });
    },
    /*下一步*/
    next: function (data, callback) {
      if (worf.tools.requestLimit()) return;
      worf.ajax({
        animate: true,
        data: data,
        url: worf.API_URL + "/v1/loan/collectNext.json",
        success: function (json) {
          if (json.status == 1) {
            callback && callback(json.data);
          } else {
            worf.prompt.tip(json.message);
          }
        }
      });
    },
    /*保存*/
    submit: function (data, callback) {
      if (worf.tools.requestLimit()) return;
      worf.ajax({
        animate: true,
        data: data,
        url: worf.API_URL + "/v1/loan/borrowerCollect.json",
        success: function (json) {
          if (json.status == 1) {
            callback && callback(json.data);
          } else {
            worf.prompt.tip(json.message);
          }
        }
      });
    }
  };

  /**
  * 更换图片验证码
  */
  function showImgCode() {
    $("#txtPicCode").val("").parent().find(".icon-delete").addClass("hide");
    $("#imgCode").attr("src", worf.API_URL + "/v1/captcha/captcha?id=" + visitorId + "&r=" + worf.tools.getTimestamp());
  };

  /**
   * 获取短信验证码
   */
  window.getMsgCode = function () {
    var phone = worf.tools.val("#txtPhone");
    var picCode = worf.tools.val("#txtPicCode");
    if (!phone) {
      worf.prompt.tip("请输入手机号码");
      return false;
    } else if (!/^1[3|4|5|8|7][0-9]{9}$/.test(phone)) {
      worf.prompt.tip("手机号码格式不正确");
      return false;
    }
    else if (!picCode) {
      worf.prompt.tip("请输入图片验证码");
      return false;
    }
    ajax.sendCode({ phone: phone, captcha: picCode, clientId: visitorId }, function (data) {
      startTimer();
      codeFlag = true;
      if (data) worf.prompt.tip(data);
    });
  };

  /**
    * 底部弹出时间选择框
    */
  function datePick() {
    var me = $(this);
    var type = me.data("field");
    var value = me.find(".form-value").data("value");
    var year = value && value.substr(0, 4);
    var month = value && parseInt(value.substr(5, 2), 10);
    var day = value && parseInt(value.substr(8, 2), 10);
    worf.ui.datePicker({
      el: me,
      year: year,
      month: month,
      day: day,
      selected: function (year, month, day) {
        month = month < 10 ? "0" + month : month;
        day = day < 10 ? "0" + day : day;
        var data = year + "-" + month + "-" + day;
        me.find(".form-value").attr("data-value", data).text(data).removeClass("color-gray");
      }
    });
  }

  /**
   * 倒计时
   */
  function startTimer() {
    var label = $("#btnCode");
    worf.tools.countdown({
      before: function () { label.off("click"); },
      jump: function (time) { label.text(time + "秒"); },
      after: function () {
        label.text("获取验证码").click(getMsgCode);
      }
    });
  }

  /**
 * 底部弹出选择框
 */
  function slideUpBox() {
    var me = $(this),
           type = me.data("box"),
           config = itemConfig[type];
    worf.ui.slideUpBox({
      data: config,
      select: function (data) {
        me.find(".form-value").attr("data-value", data.value).text(data.text).removeClass("color-gray");
        //【购置状态】为【按揭中】时显示【已按揭期数】
        if (type == "typesOfPurchasing") {
          if (data.value == 1) {
            $("#divRepaidMonth").removeClass("hide");
            $("#txtRepaidMonth").attr("data-val", "required").val("");
          } else {
            $("#divRepaidMonth").addClass("hide");
            $("#txtRepaidMonth").attr("data-val", "1").val("");
          }
        }
      }
    });
  }


  /**
   * 显示编辑form
   */
  var editFlag = true;
  function openEidt() {
    var me = $(this);
    var name = me.find("label").text();
    var element = me.find(".form-value");
    var elementId = element.attr("id");
    var mode = me.data("mode");
    var rightText = me.data("title-righttext");
    var inputMode = me.data("input");
    var regex = me.data("regex");
    var helpTip = me.data("helptip");
    var regexMessage = me.data("regexms");
    var placeholder = me.data("placeholder");
    var maxlength = me.data("maxlength");
    var inputGroup, getResult, check, rangeUnit, multiSelectData;
    if (elementId == "txtCity") {
      inputGroup = $("#cityTemplate").html();
      getResult = function (wrapper) {
        var value = [];
        var text = [];
        wrapper.find("#selectedCityWrapper .city-item").each(function () {
          value.push($(this).data("id"));
          text.push($(this).text());
        });
        return { text: text, value: value };
      }
    } else if (elementId == "txtBrand") {
      inputGroup = $("#brandTemplate").html();
    } else if (elementId == "txtNum") {
      inputGroup = $("#carNoTemplate").html();
      getResult = function (wrapper) {
        var value = [];
        var text = [];
        var num = (wrapper.find(".carno-group").text() + wrapper.find("input").val()).replace(/\s/ig, "").toUpperCase();
        value.push(num);
        text.push(num);
        return { text: text, value: value };
      }
    }

    worf.ui.editPage({
      mode: mode, //输入框的模式 input,textarea,range
      placeholder: placeholder,//提示信息
      maxlength: maxlength,//字数限制
      regex: regex,//检验正则
      regexMessage: regexMessage,//检验提示语
      rightText: rightText,//头部右侧的按钮文字
      text: element.text(), //当前文本
      inputMode: inputMode,//输入模式：比如 tel，number
      value: element.attr("data-value"),//当前值
      name: name,
      helpTip: helpTip,//输入框下面的提示语
      multiSelectData: multiSelectData,//多选项的数据
      getResult: getResult,//获取结果的方法
      check: check,//检查结果的方法
      inputGroup: inputGroup, //输入框的html
      success: function (data) {
        var text = data.text;
        var value = data.value;
        var suffix = element.data("suffix") || "";
        if (suffix) {
          text = text.replace(suffix, "") + suffix;
        }
        element.data("value", value).text(text).val(text).removeClass("color-gray");
      },
      opening: function (options) {
        //改变当前显示的头部
        worf.nav.changeHeader(1);
        //设置添加标题
        worf.app.toogleTitle($("#editTitle").text(), { rightTitle: "保存" });
        if (elementId == "txtCity") {
          window.cityPicker.init({
            scrollWrapper: !worf.device.wap ? $("#editInput") : $(document.body),
            selectCity: function (data) {
              //element.data("value", data.id).text(data.text).removeClass("color-gray");
              options.success({ value: data.id, text: data.text });
              worf.ui.editPage.hide();
            }
          });
        } else if (elementId == "txtBrand") {
          window.carBrandPicker.init({
            scrollWrapper: !worf.device.wap ? $("#editInput") : $(document.body),
            selectModel: function (data) {
              var series = window.carBrandPicker.currentData.series;
              options.success({ value: data.id, text: series.text + " " + data.text });
              //element.data("value", data.id).text(series.text+data.text).removeClass("color-gray");
              worf.ui.editPage.hide();
            }
          });
        } else if (elementId == "txtNum") {
          worf.ui.carNumPicker.init({ value: element.attr("data-value") });
        }
      },
      closed: function () {
        editFlag = false;
        //改变当前显示的头部
        worf.nav.changeHeader(0);
        //设置添加标题
        worf.app.toogleTitle($(".app-title").eq(0));
      }
    });
  }

  /**
    * 下一步
    */
  function next() {
    //检验数据
    var data = worf.validate("#form1", { filter: filter });
    if (!data) return false;
    if (!codeFlag) {
      worf.prompt.tip("#tipCode", "还未获取验证码");
      return false;
    }
    //提交
    data.clientId = visitorId;
    data.source = 2;//来源:1-WEB端;2-微端
    ajax.next(data, function () {
      $("#form1").addClass("hide");
      $("#form2").removeClass("hide");
    });
  }

  /**
  * 保存借款需求
  */
  function submit() {
    //检验数据
    var data1 = worf.validate("#form1", { filter: filter });
    if (!data1) return false;
    if (!codeFlag) {
      worf.prompt.tip("#tipCode", "还未获取验证码");
      return false;
    }
    //检验数据
    var data2 = worf.validate("#form2", { filter: filter });
    if (!data2) return false;

    //计算日期
    var times = data2.vehicleLicensingTime.split("-");
    var year = parseInt(times[0], 10);
    var month = parseInt(times[1], 10);
    var day = parseInt(times[2], 10);
    var date = new Date(year, month - 1, day);
    var timeStamp = Math.ceil(date.getTime() / 1000);
    //提交
    var data = $.extend({}, data1, data2);
    data.clientId = visitorId;
    data.brand = parseInt(data.brand, 10);
    data.loanMoney = parseFloat(data.loanMoney, 10);
    data.typesOfPurchasing = parseInt(data.typesOfPurchasing, 10);
    data.repaid_month = parseInt(data.repaid_month, 10);
    data.city = parseFloat(data.city, 10);
    data.purchasePrice = parseFloat(data.purchasePrice, 10);
    data.vehicleLicensingTime = timeStamp;
    data.source = parseInt(worf.tools.queryString("channel") || "2", 10);//来源:1-WEB端;2-微端
    ajax.submit(data, function () {
      worf.prompt.confirm("提交成功，<br/>您也可以下载客户端体验更多服务", function () {
        //worf.form.reset("#form1,#form2", {
        //    after: function () {
        //        $("#form1").removeClass("hide");
        //        $("#form2").addClass("hide");
        //        showImgCode();
        //        window.clearTimeout(window.countdownTimer);
        //        $("#btnCode").off().text("获取验证码").click(getMsgCode);
        //    }
        //});
        window.location.href = worf.app.url;
      }, null, { okText: "下载客户端", cancelText: "留在此界面" });
    });
  }

  /**
    * 返回
    */
  window.goback = function () {
    if (worf.ui.editPage.isOpen) {
      worf.animate.sliderRight("#editForm");
      //改变当前显示的头部
      worf.nav.changeHeader(0);
      //设置添加标题
      worf.app.toogleTitle($(".app-title").eq(0));
      return;
    }
    if ($("#form1").hasClass("hide")) {
      $("#form1").removeClass("hide");
      $("#form2").addClass("hide");
      return;
    }
    if (worf.app.isReady && worf.app.toIndex) {
      worf.app.toIndex("/view/index/toloan.html", true);
    }
  }

  /**
 * 初始化
 */
  window.init = function () {
    showImgCode();
    $("#btnSubmit").click(submit);
    $("#btnNext").click(next);
    $("#divOwnStatus").click(slideUpBox);
    $("[data-edit]").click(openEidt);
    $("[data-sel-date]").click(datePick);
    $("#btnPicCode").click(showImgCode);
    $("#btnCode").click(getMsgCode);
    carBrandPicker.preloadData();
  };
})(window.Zepto);

