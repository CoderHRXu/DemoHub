(function ($) {

    var info = {
        ajax: {
            /*获取详情*/
            getInfo: function (data,callback) {
                worf.ajax({
                    animate: true,
                    data:data,
                    url: worf.API_URL + "/v1/list/robListDetailNoSessionToken.json",
                    success: function (json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            },
            /*获取分享链接*/
            getShare: function (data, callback) {
                worf.ajax({
                    animate: true,
                    data: data,
                    url: worf.API_URL + "/v1/user/getShareLink.json",
                    success: function (json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            }
        },
        getInfo: function () {
            var id =parseInt(worf.tools.queryString("id")||"0");
            info.ajax.getInfo({ id: id }, function (data) {
                if (data) {
                    $("body [data-name]").each(function () {
                      var that = $(this);
                      var value = data[that.data("name")];
                      if (value) {
                        that.text(value + (that.data("suffix") || ""));
                      }
                    });
                    //【购置状态】为按揭的才显示按揭月数
                    if (data.typesOfPurchasing == 1) {
                      $("#divRepaidMonth").removeClass("hide");
                    }
                  info.initShare(data);
                }
            });
        },
        getShareLink: function() {
          var userId = parseInt(worf.tools.queryString("userid") || "0");
            info.ajax.getShare({ userId: userId }, function (data) {
                if (data) {
                    $("#picImg").attr("src",data.qrcode);
                }
            });
        },
        initShare: function (data) {
          var desc =data.areaName + data.name + "申请车贷" + data.loanMoney + "万，快来抢，点击查看单子详情" ;
              var options = {
                      "title": "送个车贷单子给你",
                      "msg":desc ,
                      "url": window.location.href,
                      "shareId": "loanInfo-001"
              }
              wxShare.init(options);
              //其他分享使用meta标签的内容
              $("#metaDesc").attr("content", desc);
              $("#metaImg").attr("content", worf.origin + "/img/shareIcon.png");
        },
        init: function () {
            info.getInfo();
            info.getShareLink();
            $("#btnSubmit").click(function() {
                window.location.href = worf.app.url;
            });
        }
    };

    $(function () {
        info.init();
    });
})(Zepto);

