$(function() {
    init();
});

(function() {
    var json;
    var pageLevel = 0;
    //数据以借款利率为主体
    var definedConfig = {
        loanTermSelected: 0, //选中的借款利率
        loanTermData: {}, //借款期限数据
        /*下拉组件数据 */
        selectable: {
            loanTerm: [], //借款期限
            loanRate: [], // 借款利率
            clRtnRate: [], //存量返还点数
            clRtnTimes: [], //存量返还次数
            ycxRtnRate: [] //一次性返还点数
        },
        //获取当前值
        /* getCurrent: function(attr) {
             return definedConfig[attr][definedConfig.levelSelectedIndex];
         }*/
    };

    /**
     * 获取配置
     */
    function getConfig() {
        worf.ajax({
            url: worf.API_URL + "/partner/v1/queryCalculatorInfo.json",
            success: function(json) {
                var data = json.data;
                $(data.rebate).each(function(index, item) {
                    item.loanPeriod = item.loanPeriod + "期";
                    if (!definedConfig.loanTermData[item.loanPeriod]) {
                        definedConfig.loanTermData[item.loanPeriod] = [];
                        definedConfig.selectable.loanTerm.push(item.loanPeriod);
                    }
                    definedConfig.loanTermData[item.loanPeriod].push(item);
                });

                //默认显示第一个借款期限
                definedConfig.selectable.loanTerm = definedConfig.selectable.loanTerm.sort();
                var loanTerm = definedConfig.selectable.loanTerm[0];
                setValue($("#txtTerm"), loanTerm);
                changeLoanTerm(loanTerm);
            }
        });
    }

    /**
     * 修改期限
     * （改变借款利率数据）
     */
    function changeLoanTerm(loanTerm) {
        definedConfig.loanTermSelected = loanTerm;
        definedConfig.loanTermData[loanTerm].sort(function(a, b) {
            return parseFloat(a.lendingRate.replace("%", ""), 10) - parseFloat(b.lendingRate.replace("%", ""), 10);
        });
        var data = definedConfig.loanTermData[loanTerm];
        var sel = definedConfig.selectable;
        sel.loanRate = [], sel.ycxRtnRate = [];
        $(data).each(function(index, item) {
            item.lendingRate = item.lendingRate.replace("%", "") + "%";
            if (sel.loanRate.indexOf(item.lendingRate) == -1) {
                sel.loanRate.push(item.lendingRate); //借款利率
                sel.ycxRtnRate.push(item.ycxRtnRate); //一次性返还点数
            }
        });

        //默认显示第一个借款利率？
        var rate = $("#txtRate").attr("data-value");
        if (sel.loanRate.indexOf(rate) == -1) {
            rate = sel.loanRate[0];
        }
        setValue($("#txtRate"), rate);
        changeLoanRate(rate);
    }

    /**
     * 修改利率
     * （改变存量返回利率和次数的数据）
     */
    function changeLoanRate(loanRate) {
        //对数据进行排序
        definedConfig.loanTermData[definedConfig.loanTermSelected].sort(function(a, b) {
            return parseFloat(a.clRtnTimes, 10) - parseFloat(b.clRtnTimes, 10);
        });

        var data = definedConfig.loanTermData[definedConfig.loanTermSelected];
        var sel = definedConfig.selectable;
        sel.clRtnRate = [], sel.clRtnTimes = [],
            $(data).each(function(index, item) {
                if (item.lendingRate == loanRate && sel.clRtnTimes.indexOf(item.clRtnTimes) == -1) {
                    sel.clRtnRate.push(item.clRtnRate); //存量返还利率
                    sel.clRtnTimes.push(item.clRtnTimes); //存量返还次数
                }
            });

        var time = $("#txtTime").data("data-value");
        if (sel.clRtnTimes.indexOf(time) == -1) {
            time = sel.clRtnTimes[0];
        }
        setValue($("#txtTime"), time);
    }

    function setValue($el, value) {
        $el.removeClass("color-gray").addClass("color-black").attr("data-value", value).text(value);
    }

    /**
     * 提交
     */
    function submit() {
        var amount = worf.tools.val("#txtAmount");
        var rate = $("#txtRate").data("value");
        var term = $("#txtTerm").data("value");
        var time = $("#txtTime").data("value");
        if (!amount) {
            worf.prompt.tip("请输入审批金额");
            return false;
        } else if (!/^[1-9]\d{0,2}$/ig.test(amount) || (amount < 3 || amount > 100)) {
            worf.prompt.tip("审批金额格式不正确<br/>3~100万");
            return false;
        } else if (!term) {
            worf.prompt.tip("请输入借款期限");
            return false;
        } else if (!rate) {
            worf.prompt.tip("请输入借款年利率");
            return false;
        } else if (!time) {
            worf.prompt.tip("请输入返还次数");
            return false;
        }

        //添加诸葛统计
        zhuge.track("存量计算器按钮-立即计算按钮");

        var data = {
            amount: amount,
            loanRate: rate,
            term: term,
            ycxRtnRate: definedConfig.selectable.ycxRtnRate[definedConfig.selectable.loanRate.indexOf(rate)],
            clRtnRate: definedConfig.selectable.clRtnRate[definedConfig.selectable.clRtnTimes.indexOf(time)],
            clRtnTime: time
        };
        calculator(data, function(result) {
            showDetail(result);
        });
    }

    /**
     * 开始计算
     * 
     * 一次性提成=(审批金额)*一次性返点数
     * 存量收益合计=(审批金额)*存量返点数
     * 每期存量收益合计=存量收益合计/返还次数
     * 
     */
    function calculator(data, callback) {
        data.amount = data.amount * 10000;
        data.loanRate = data.loanRate.replace("%", "");
        data.term = data.term.replace("期", "");
        var result = {};
        result.oneTime = data.amount * data.ycxRtnRate;
        result.total = (data.amount) * data.clRtnRate;
        result.perTermAmount = result.total / data.clRtnTime;

        callback && callback(result);
    }

    /**
     * 显示明细
     */
    window.showDetail = function(result) {
        $("#divResult").removeClass("on");
        setTimeout(function() {
            $("#pOneTime").text(formatNumber(result.oneTime));
            $("#pAmount").text(formatNumber(result.total));
            $("#pperAmount").text(formatNumber(result.perTermAmount));
            $("#divResult").addClass("on");
        }, 200);

        /*格式化数字*/
        function formatNumber(num) {
            var numStr = num.toFixed(2);
            var numbers = numStr.split(".");
            var letters = numbers[0].split("").reverse();
            for (var i = 0; i < letters.length; i++) {
                if (i + 1 % 3 == 0) {
                    letters.slice(i + 1, 0, ",");
                }
            }
            return letters.reverse().join("") + (numbers[1] ? ("." + numbers[1]) : "");
        }
    }

    /**
     * 底部弹出选择框
     */
    window.slideUpBox = function() {
        var me = $(this);
        var type = me.attr("data-scrollUp");
        var data = definedConfig.selectable[type];

        worf.ui.slideUpBox({
            data: data,
            select: function(data) {
                setValue(me.find(".form-value"), data.text);
                if (type == "loanRate") {
                    //setValue($("#txtTime"), "");
                    changeLoanRate(data.text);
                } else if (type == "loanTerm") {
                    //setValue($("#txtTime"), "");
                    changeLoanTerm(data.text);
                }
            }
        });
    }

    /**
     * 返回 
     */
    window.goback = function() {
        if (pageLevel == 1) {
            worf.animate.sliderRight("#divResult");
            //改变当前显示的头部
            worf.nav.changeHeader(0);
            //设置添加标题
            worf.app.toogleTitle($(".app-title").eq(0));
            pageLevel = 0;
            return;
        }
        if (worf.app.isReady && worf.app.toIndex) {
            worf.app.toIndex("/view/tool/calculator.html", true);
        }
    };

    function reset() {
        $("#form").find("input").val("");
        $(".form-value").data("value", "").text("请选择").removeClass("color-black").addClass("color-gray");
        $("#divResult").removeClass("on");
    }

    window.init = function() {
        $("#btnSubmit").click(submit);
        $("#btnReset").click(reset);
        $("[data-scrollUp]").click(slideUpBox);
        getConfig();
    };
})(window.Zepto);