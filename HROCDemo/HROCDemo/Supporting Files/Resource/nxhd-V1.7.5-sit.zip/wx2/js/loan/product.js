(function ($) {
    var jroll,
        status = 0,
        isEnd = false,
        rowSize = 5,
        pageLevel = 0,
        loanId=0;

    /**
    * 产品
    */
    var product = {
        ajax: {
            /*产品列表*/
            list: function (data, callback) {
                //status-筛选条件 0: 全部 1：平台审核中 2:待选择门店 3: 门店签约 4: 审核失败
                data.rows = rowSize;
                worf.ajax({
                    url: worf.API_URL + "/v1/borrowerAudit/applyLoanList.json",
                    data: data,//{ page: page,rows:12,status:0 },
                    success: function (json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            },
            /*产品详情*/
            get: function (id, callback) {
                worf.ajax({
                    url: worf.API_URL + "/v1/borrowerAudit/borrowerAuditDetails.json",
                    data: {id:id},
                    success: function (json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            },
            /*确认借款*/
            confirmLoan: function (callback) {
                worf.ajax({
                    animate:true,
                    url: worf.API_URL + "/v1/borrowerAudit/confirm.json",
                    data: {
                        id: loanId //单子id
                    },
                    errorTip: function (json) {
                        if (json.status == 1 || json.status == 6001) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                        return true;
                    },
                    success: function (json) {
                        if (json.status == 1 || json.status == 6001) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            }
        },
        /*初始化下刷新组件*/
        initScroll: function () {
            var that = this;
            jroll = new JRoll("#wrapper");
            jroll.infinite({
                total: 10000,
                g: 0.0012,
                //iconUpdate:"<span style='color:red'>A</span>",
                getData: function (page, callback) {
                    if (isEnd) {
                        $("#scroller").find(".jroll-infinite-tip").html("已加载全部内容");
                        return;
                    }
                    product.ajax.list({ page: page, status: status }, function (data) {
                        data = data || [];
                        callback(data);
                        
                        if (data.length < rowSize) {
                            isEnd = true;
                            $("#scroller").find(".jroll-infinite-tip").html((page == 1 && data.length == 0) ? "当前无记录" : "已加载全部内容");
                        }
                    });
                },
                template: $("#template").html()
            });
            //下拉刷新
            jroll.pulldown({
                refresh: function (complete) {
                    isEnd = false;
                    jroll.options.page = 1;
                    jroll.scroller.innerHTML = "";
                    jroll.scrollTo(0, 0);
                    product.ajax.list({ page: 1, status: status }, function (data) {
                        data = data || [];
                        jroll.infinite_callback(data);
                        complete();
                        if (data.length < rowSize) {
                            isEnd = true;
                            $("#scroller").find(".jroll-infinite-tip").html((data.length == 0) ? "当前无记录" : "已加载全部内容");
                        }
                    });
                }
            });
        },
        /*显示过滤条件*/
        showFilter: function () {
            var that = this;
            $("#divFilter").toggleClass("on");
            if (that.isBindFilter) return;
            $("#divFilter li").click(function () {
                $(this).addClass("active").siblings().removeClass("active");
                $("#divFilter").toggleClass("on");
                var newStatus = $(this).data("value");
                if (status != newStatus) {
                    status = newStatus;
                    isEnd = false;
                    jroll.scrollTo(0, 0);  //滚回顶部
                    loadData();
                }
            });
            that.isBindFilter = true;
        },
        /*切换菜单*/
        toggleMenu: function() {
            var that = this;
            if (that.isBindMenu) return;
            $("#menu div").click(function () {
                $(this).addClass("active").siblings().removeClass("active");
                var newStatus = $(this).data("value");
                if (status != newStatus) {
                    status = newStatus;
                    isEnd = false;
                    jroll.scrollTo(0, 0);  //滚回顶部
                    loadData();
                }
            });
            that.isBindMenu = true;
        },
        /*获取详情*/
        getDetail: function () {
            var id =parseInt(worf.tools.queryString("id"),10);
            product.ajax.get(id, function (data) {
                loanId = data.id;
                var status =data.status ;
                var icon = ["checking", "fail-check", "select-store", "sign-contract"];
                $("#load-state").addClass(icon[status - 1]);
                if (status == 3) {
                    //待确认借款
                    product.showConfirmLoan(data);
                }
                for (var key in data) {
                		$("#sp_" + key).text(data[key]);
                }
                //身份证有效期
                $("#sp_cardExpireDate").text(data.cardExpireDate+"天");
                //失败的显示原因
                //if (data.comment) {
                //    $("#step9").removeClass("hide");
                //}
            });
        },
        /*初始化-待确认借款*/
        showConfirmLoan: function (data) {
            var defaultTime = new Date(new Date().getTime()+30*24*60*60*1000).Format("yyyy年M月d日");
            $("#spConfirmAmount").text(data.loanQuota || 0);
            $("#spLoanType").text(data.loanType || "未知");
            $("#spLoanTerm").text(data.loanPeriod || "未知");
            $("#spDeadTime").text(data.deadlineStr || defaultTime);
            $("#btnConfirm").show();
            $("#btnConfirmLoan").click(function() {
                product.ajax.confirmLoan(function(data) {
                    worf.prompt.success("提交成功，后续签约事宜由该机构的线下客服跟进！", function() {
                        worf.nav.back();
                    });
                });
            });
        },
        /*初始化详情页*/
        initDetail: function() {
            var that = this;
            that.getDetail();
            $("#btnConfirm").click(function () {
                document.body.scrollTop = 0;
                $("body").addClass("noscroll");
                worf.animate.sliderLeft("#confirmPage");
                //改变当前显示的头部
                worf.nav.changeHeader(1);
                //设置添加标题
                worf.app.toogleTitle($(".app-title").eq(1));
                $("#submitBox").show();
                $("#btnConfirm").hide();
                pageLevel = 1;  
            });
            //控制返回
            window.goback = function () {
                if (pageLevel == 1) {
                    $("body").removeClass("noscroll");
                    worf.animate.sliderRight("#confirmPage");
                    //改变当前显示的头部
                    worf.nav.changeHeader(0);
                    //设置添加标题
                    worf.app.toogleTitle($(".app-title").eq(0));
                    $("#submitBox").hide();
                    $("#btnConfirm").show();
                    pageLevel = 0;
                    return;
                }
                worf.nav.back();
            };
        },
        /*初始化列表页*/
        init: function () {
            var that = this;
            that.initScroll();
            that.toggleMenu();
            //$("#btnFilter").click(that.showFilter);
            window.loadData = function () {
                isEnd = false;
                jroll.destroy();
                that.initScroll();
            }
            window.showDetail = function (id) {
                worf.nav.go("/view/loan/productInfo.html?id=" + id);
            };
        }
    };
    window.product = product;
})(Zepto);