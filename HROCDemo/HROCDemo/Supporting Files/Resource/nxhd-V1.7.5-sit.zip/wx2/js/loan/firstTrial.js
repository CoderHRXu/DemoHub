var docHeight = document.documentElement.clientHeight;
$(function () {
    init();
});

/*
* 选择品牌组件
*/
(function () {
    var scrollWrapperr, jRoll;
    var brand = {
        currentData: { brand: {}, series: {},model: {} },
        localData: {
            brandId: 0,//品牌id
            seriesId: 0,//系列id
            modelId: 0,//模型id
            provinces: [],//所有城市数据
            brands: [],//所有品牌数据
            series: {},//车系列数据
            model: {}//车型号数据
        },
        ajax: {
            /*分析品牌和省份数据*/
            getChe300: function (callback) {
                //检测网络
                var netStatus = worf.app.getNetStatus();
                if (netStatus.status == 0) {
                    worf.prompt.tip("请检查您的网络连接是否正常");
                    return;
                };
                $.get(worf.API_URL+"/v1/che300/assess", function (res) {
                    var html = $(res);
                    //车品牌数据
                    var letter = "A";
                    html.find("#showBrand dl").children().each(function (index, item) {
                        var me = $(item),
                            text = me.text(),
                            id = me.data("brandid");
                        if (!id) {
                            letter = text;
                            return true;
                        }
                        brand.localData.brands.push({ firstLetter: letter, id: id, brand: text });
                    });
                    //省份数据
                    html.find("#showCity dl.prov-list dd").each(function (index, item) {
                        item = $(item);
                        var value = item.data("provid");
                        var text = item.find("div").text();
                        if (/\d+/.test(value)) {
                            brand.localData.provinces.push({ value: value, text: text });
                        }
                    });
                    callback && callback(brand.localData);
                });
            },
            /*获取车品牌*/
            getBrand: function (key, callback) {
                //检测网络
                var netStatus = worf.app.getNetStatus();
                if (netStatus.status == 0) {
                    worf.prompt.tip("请检查您的网络连接是否正常");
                    return;
                };
                var json = brand.localData.brands;
                if (key) {
                    var data = [];
                    $.each(json, function (index, item) {
                        if (item.firstLetter == key || item.brand.indexOf(key) > -1) {
                            data.push(item);
                        }
                    });
                    json = data;
                }
                callback && callback(json);
            },
            /*获取车系列*/
            getSeries: function (brandId, callback) {
                var data = brand.localData.series[brandId];
                if (data) {
                  return  callback && callback(data);
                }
                //检测网络
                var netStatus = worf.app.getNetStatus();
                if (netStatus.status == 0) {
                    worf.prompt.tip("请检查您的网络连接是否正常");
                    return;
                };
                $.get(worf.API_URL + "/v1/che300/seriesBrand?brandId=" + brandId, function (data) {
                    data = JSON.parse(data || "[]");
                    brand.localData.series[brandId] = data;
                    callback && callback(data);
                });
            },
            /*获取车型号*/
            getModel: function (seriesId, callback) {
                var data = brand.localData.model[seriesId];
                if (data) {
                    return callback && callback(data);
                }
                //检测网络
                var netStatus = worf.app.getNetStatus();
                if (netStatus.status == 0) {
                    worf.prompt.tip("请检查您的网络连接是否正常");
                    return;
                };
                $.get(worf.API_URL + "/v1/che300/modelSeries?seriesId=" + seriesId + "&v=" + worf.tools.getTimestamp(), function (data) {
                    data = JSON.parse(data || "[]");
                    brand.localData.model[seriesId] = data;
                    callback && callback(data);
                });
            }
        },

        /**
       * 初始化数据
       */
        initData: function (callback) {
            brand.ajax.getChe300(function (data) {
                callback && callback(data);
            });
        },
        /**
        * 搜索品牌
        */
        searchBrand: function (key) {
            key = key || '';
            //检测网络
            var netStatus = worf.app.getNetStatus();
            if (netStatus.status == 0) {
                worf.prompt.tip("请检查您的网络连接是否正常");
                return;
            };
            brand.ajax.getBrand(key, function (data) {
                if (!key && data.length == 0) {
                    worf.ajax.overlayShow();
                    setTimeout(function () { carSeriesPicker.searchBrand(key); }, 100);
                    return;
                }
                worf.ajax.overlayHide();
                var showNum = "A";
                var html;
                if (!key) {
                    var letter = [];
                    html = '<div class="group-letter" id="letterA">A</div>';
                    for (var i = 0; i < data.length; i++) {
                        var item = data[i];
                        var cssClass = (data[i + 1] && data[i + 1].firstLetter != item.firstLetter) ? "last" : "";
                        if (item.firstLetter == showNum) {
                            html += '<div class="brand ' + cssClass + '" data-id="' + item.id + '" ><div class="bb-gray">' + item.brand + '</div></div>';
                        } else {
                            html += '<div class="group-letter" id="letter' + item.firstLetter + '">' + item.firstLetter + '</div>';
                            showNum = item.firstLetter;
                            html += '<div class="brand ' + cssClass + '"  data-id="' + item.id + '" ><div class="bb-gray">' + item.brand + '</div></div>';
                        }
                        if (item.firstLetter != letter[letter.length - 1]) {
                            letter.push(item.firstLetter);
                        }
                    }
                    $("#allBrand").html(html);
                } else {
                    html = '';
                    for (var i = 0; i < data.length; i++) {
                        var item = data[i];
                        html += '<div class="brand"  data-id="' + item.id + '" ><div class="bb-gray">' + item.brand + '</div></div>';
                    }
                    $("#allBrand").html(html);
                }
                if (!jRoll) {
                    jRoll = new JRoll("#brandScroll", {
                        scrollX: false, //x方向不允许滚动
                        bounce: false //不回弹
                    });
                } else {
                    jRoll.scrollTo(0, 0, 100).refresh();
                }
            });
        },

        /*搜索系列*/
        searchSeries: function (key) {
            brand.ajax.getSeries(key, function (data) {
                var showNum = data[0] && data[0].series_group_name;
                var html = "";
                if (showNum) {
                    html = '<div class="series-letter">' + showNum + '</div>';
                }
                for (var i = 0; i < data.length; i++) {
                    var item = data[i];
                    if (item.series_group_name == showNum) {
                        html += '<div class="series" data-id=' + item.series_id + ' ><div class="bb-gray">' + item.series_name + '</div></div>';
                    } else {
                        showNum = item.series_group_name;
                        html += '<div class="series-letter" >' + showNum + '</div>';
                        html += '<div class="series"  data-id=' + item.series_id + ' ><div class="bb-gray">' + item.series_name + '</div></div>';
                    }
                }
                $("#allSeries").empty().html(html);
                $("#brandSeriesBg").removeClass("hide");
                setTimeout(function () { $("#brandSeries").addClass("open"); }, 0);
            });
        },

        /*搜索型号*/
        searchModel: function (id, name) {
            brand.ajax.getModel(id, function (data) {
                var showNum = data[0] && data[0].model_year + "款";
                var html = "";
                if (showNum) {
                    html = '<div class="series-letter">' + showNum + '</div>';
                }
                for (var i = 0; i < data.length; i++) {
                    var item = data[i];
                    var year = item.model_year + "款";
                    var extendData = 'data-maxyear="' + item.max_reg_year + '" data-minyear="' + item.min_reg_year + '"';
                    if (year == showNum) {
                        html += '<div class="series" data-id="' + item.model_id + '"  ' + extendData + '><div class="bb-gray">' + item.model_name.replace(year, "").replace(name, "") + '</div></div>';
                    } else {
                        showNum = year;
                        html += '<div class="series-letter" >' + showNum + '</div>';
                        html += '<div class="series"  data-id="' + item.model_id + '"  ' + extendData + '><div class="bb-gray">' + item.model_name.replace(year, "").replace(name, "") + '</div></div>';
                    }
                }

                $("#allModel").empty().html(html);
                $("#brandModelBg").removeClass("hide");
                setTimeout(function () { $("#brandModel").addClass("open"); }, 0);
            });
        },

        selectBrand: function (data) {
            brand.localData.brandId = data.id;
            brand.localData.seriesId = 0;
            brand.localData.modelId = 0;
            brand.currentData.brand = data;
            brand.searchSeries(data.id);
        },
        selectSeries: function (data) {
            brand.localData.seriesId = data.id;
            brand.localData.modelId = 0;
            brand.currentData.series = data;
            brand.searchModel(data.id, data.text);
        },
        selectModel: function (data) {
            brand.localData.modelId = data.modelId;
            brand.currentData.model = data;
            brand.currentData.modelText = brand.currentData.series.text + " " + brand.currentData.modelText;
            console.log(data);
        },
        bindEvent: function () {
            //选择品牌
            $("#allBrand").on("click", function (e) {
                var me = $(e.target);
                if (me.is(".bb-gray")) me = me.parent();
                if (me.is(".brand")) {
                    brand.selectBrand({ id: me.data("id"), text: me.text() });
                    brand.cancelSearch();
                }
            });
            //选择系列
            $("#allSeries").on("click", function (event) {
                var me = $(event.target);
                if (me.is(".bb-gray")) me = me.parent();
                if (me.is(".series")) {
                    brand.selectSeries({ id: me.data("id"), text: me.text() });
                }
                event.stopPropagation();
            });
            //选择型号
            $("#allModel").on("click", function (event) {
                var me = $(event.target);
                if (me.is(".bb-gray")) me = me.parent();
                if (me.is(".series")) {
                    brand.selectModel({
                        brandId: brand.localData.brandId,//品牌id
                        seriesId: brand.localData.seriesId,//系列id
                        modelId: me.data("id"), //型号id
                        modelText:me.text(),//型号名称
                        maxYear: me.data("maxyear"),//最大上牌日期
                        minYear: me.data("minyear")//最小上牌日期
                    });
                }
                event.stopPropagation();
            });
            //切换搜索区域
            $("#brandSearchCenter").click(function () {
                $(this).addClass("hide");
                $("#brandSearch").removeClass("hide");
                setTimeout(function () { $("#txtBrandSearch").focus(); }, 200);
            });
            //输入框输入事件
            $("#txtBrandSearch").on("input", function () {
                var key = $.trim($(this).val() || "");
                brand.searchBrand(key);
            });
            //字母选中
            $("#brandLetter").click(function (e) {
                var me = $(e.target);
                if (me.is("span")) {
                    if ($("#txtBrandSearch").val() != "") return;
                    var letterSelector = "#letter" + me.text();
                    var y = 0, isFind = false;
                    $("#allBrand").children().each(function (index, item) {
                        item = $(item);
                        var isStop = item.is(letterSelector);
                        if (!isStop) {
                            y += item.height();
                        } else {
                            isFind = true;
                            return false;
                        }
                    });
                    isFind && jRoll.scrollTo(0, 0 - y, 100).refresh();
                }
            });
            //关闭系列 
            $("#brandSeriesBg,#brandSeriesTitle").on("click", function () {
                $("#brandSeries").removeClass("open");
                setTimeout(function () { $("#brandSeriesBg").addClass("hide"); }, 400);
            });
            //关闭型号 touchstart
            $("#brandModelBg,#brandModelTitle").on("click", function () {
                $("#brandModel").removeClass("open");
                setTimeout(function () { $("#brandModelBg").addClass("hide"); }, 400);
            });
            //阻止父层滚动
            $("#allSeries,#allModel").on("scroll", function (event) {
                event.stopPropagation();
                return false;
            });
        },
        /*退回到搜索状态以前*/
        cancelSearch: function () {
            if ($("#brandSearchCenter").hasClass("hide")) {
                brand.searchBrand();
            }
            $("#txtBrandSearch").blur();
            $("#brandSearch").addClass("hide");
            $("#brandSearchCenter").removeClass("hide");
        },
        init: function (options) {
            jRoll = null;//重置
            options = options || {};
            scrollWrapper = options.scrollWrapper ? $(options.scrollWrapper) : document.body;
            if (options.selectModel) {
                brand.selectModel = options.selectModel;
            }
            brand.searchBrand();
            brand.bindEvent();
        }
    };
    window.carSeriesPicker = brand;
})(window.Zepto);


(function () {
    var pageLevel = 0;
    var cityPickerUUID = "city";
    
    var ajax = {
        /*获取省份*/
        getProvince: function (callback) {
            var data = [
                { value: 1, text: "北京" },
                { value: 2, text: "天津" },
                { value: 3, text: "上海" },
                { value: 4, text: "重庆" },
                { value: 5, text: "河北" },
                { value: 6, text: "山西" },
                { value: 8, text: "辽宁" },
                { value: 9, text: "吉林" },
                { value: 10, text: "黑龙江" },
                { value: 11, text: "江苏" },
                { value: 12, text: "浙江" },
                { value: 13, text: "安徽" },
                { value: 14, text: "福建" },
                { value: 15, text: "江西" },
                { value: 16, text: "山东" },
                { value: 17, text: "河南" },
                { value: 18, text: "湖北" },
                { value: 19, text: "湖南" },
                { value: 20, text: "广东" },
                { value: 21, text: "甘肃" },
                { value: 22, text: "四川" },
                { value: 24, text: "贵州" },
                { value: 25, text: "海南" },
                { value: 26, text: "云南" },
                { value: 27, text: "青海" },
                { value: 28, text: "陕西" },
                { value: 29, text: "广西" },
                { value: 30, text: "西藏" },
                { value: 31, text: "宁夏" },
                { value: 32, text: "新疆" },
                { value: 33, text: "内蒙古" }
            ];
            return callback(data);
        },
        /*获取城市*/
        getCity: function (provinceId, callback) {
            //检测网络
            var netStatus = worf.app.getNetStatus();
            if (netStatus.status == 0) {
                worf.prompt.tip("请检查您的网络连接是否正常");
                return;
            };
            $.get(worf.API_URL + "/v1/che300/cityProv?provinceId=" + provinceId + "&v=" + worf.tools.getTimestamp(), function (json) {
                json = JSON.parse(json||"[]");
                if (json && json.length > 0) {
                    var data = $.map(json, function (item, index) {
                        return { value: item.key, text: item.value };
                    });
                    callback && callback(data);
                } else {
                    worf.prompt.tip("查询城市数据失败");
                }
            });
        },

        /*预估*/
        estimate: function (data, callback) {
            var url = worf.API_URL + '/v1/che300/assessResult?province=' + data.province
               + '&city=' + data.city + '&brand=' + data.brand +
               '&series=' + data.series + '&model=' + data.model +
               '&month=' + data.month + '&age=' + data.age+
               "&v=" + worf.tools.getTimestamp();

           //检测网络
            var netStatus = worf.app.getNetStatus();
            if (netStatus.status == 0) {
                worf.prompt.tip("请检查您的网络连接是否正常");
                return;
            };
            worf.ajax.overlayShow();
            $.get(url, function (xml) {
                worf.ajax.overlayHide();
                var html = $(xml);
                var price = html.find(".dealer_buy_price").text();
                if (price) {
                    worf.ajax({
                        animate:true,
                        type: "GET",
                        url: worf.API_URL + "/v1/car/estimate.json",
                        data: "price=" + price,
                        success: function (json) {
                            if (json.status == 1) {
                                callback && callback(json.data);
                            } else {
                                worf.prompt.fail("预估失败");
                            }
                        }
                    });
                } else {
                    worf.prompt.fail("预估失败");
                }
            });
        },
        
        
        /*
         * 恢复缓存时，取消继续编辑，清楚后台缓存数据
         */
        cancelEdit:function(callback){
        	worf.ajax({
				url: worf.API_URL + "/v1/borrowerAudit/cancelEdit.json",
				errorTip: function(json) {
					worf.prompt.tip(json.message);
				},
				success: function(json) {
					if(json.status == 1) {
						callback && callback(json.data);
					} else {
						worf.prompt.tip(json.message);
					}
				}
			});
        }
        
        
    };
    /**
    * 提交
    */
    function submit() {
        var brandElement = $("#sp_brand"),
            citys = ($("#sp_city").data("value") || ",").split(","),
            province = citys[0],
            city = citys[1],
            brand = brandElement.data("brandId"),
            series = brandElement.data("seriesId"),
            model = brandElement.data("modelId"),
            month = $("#sp_month").data("value"),
            age = worf.tools.val("#sp_age");
        if (!city) {
            worf.prompt.tip("请选择所在城市");
            return false;
        } else if (!model) {
            worf.prompt.tip("请选择入车辆型号");
            return false;
        } else if (!month) {
            worf.prompt.tip("请选择入首次上牌年月");
            return false;
        } else if (!age) {
            worf.prompt.tip("请输入行驶里程");
            return false;
        } else if (!/^(([1-9]\d{0,3})|0)(\.\d{1,2})?$/ig.test(age)) {
            worf.prompt.tip("行驶里程格式不正确<br/>最多4位整数，2位小数");
            return false;
        }
        var reqData = {
            province: province,
            city: city,
            brand: brand,
            series: series,
            model: model,
            month: month,
            age: age
        };

        //1上牌时间至今大于等于10年，拒绝
        //2.额度预估值的最大值小于4万，拒绝
        var message = "您的资质无法申请该产品";
        var back = function() { worf.nav.back(); };
        if (monthDiff(month) >= 10 * 12) {
            console.log("上牌时间至今大于等于10年，拒绝");
            worf.prompt.fail(message);
                return;
        }
        ajax.estimate(reqData, function (data) {
            if (data.max < 4) {
                console.log("额度预估值："+data.max);
                console.log("额度预估值的最大值小于4万，拒绝");
                worf.prompt.fail(message);
                return;
            }
            worf.localStorage.set("loan-firstTrial", JSON.stringify(data));
            $("#spMin").text(data.min.toFixed(1));
            $("#spMax").text(data.max.toFixed(1));
            worf.animate.sliderLeft("#confirmPage");
            //改变当前显示的头部
            worf.nav.changeHeader(1);
            //设置添加标题
            worf.app.toogleTitle($(".app-title").eq(1));
            $("#submitBox").show();
            pageLevel = 1;
        });

        //计算上牌年份至今的月份数
        function monthDiff(month) {
            var dates = month.split("-"),now= new Date();
            var startYear = parseInt(dates[0],10) ;
            var startMonth = parseInt(dates[1], 10);
            var endYear = now.getFullYear();
            var endMonth = now.getMonth() + 1;
            return (endYear*12+endMonth)-(startYear * 12 + startMonth);
        }
    }

    /**
     * 底部弹出时间选择框
     */
    function datePick() {
        var me = $(this);
        var type = me.data("field");
        var input =me.find(".form-value") ;
        var value = input.data("value");
        var maxYear =input.data("maxYear");
        var minYear = input.data("minYear");
        var year = value && value.substr(0, 4);
        var month = value && parseInt(value.substr(5, 2), 10);
        var day = value && parseInt(value.substr(8, 2), 10);
        worf.ui.datePicker({
            el: me,
            year: year,
            month: month,
            day: day,
            max: {year:maxYear},
            min: {year:minYear},
            selected: function (year, month,day) {
                day = day || "1";
                month = month < 10 ? "0" + month : month;
                day = day < 10 ? "0" + day : day;
                var data = year + "-" + month + "-" + day;
                worf.localStorage.set("loan-firstTrial-date", data);
                me.find("#sp_" + type).removeClass("color-gray").attr("data-value", data).html(data);
            }
        });
    }

    /**
     * 选择城市
     */
    function scrollCity() {
        var uuid = cityPickerUUID;
        var data = worf.ui.slideUpScrollBox.data[uuid];
        if (!data || !data[1] || data[1].length==0) {
            //查询省份
            ajax.getProvince(function (json) {
                worf.ui.slideUpScrollBox.data[uuid][0] = json;
                //查询初始城市
                var firstProvince = json[0].value;
                ajax.getCity(firstProvince, function (json) {
                    worf.ui.slideUpScrollBox.data[uuid][1] = json;
                    setTimeout(function () { scrollCity(); }, 300);
                });
            });
            return;
        }
        var me = $("#sp_city");
        worf.ui.slideUpScrollBox({
            el: me,
            uuid: uuid,
            level: 2,
            currentValue: (me.data("value") || "").split(","),
            data: data,
            getLevel2Data: function (data, callback) {
                ajax.getCity(data.value, callback);
            },
            selected: function (data) {
                var text = data[1].text;
                var value = data[0].value + "," + data[1].value;
                me.removeClass("color-gray").attr("data-value", value).html(text);
            }
        });
    }
    /**
     * 选择城市-初始化第一个省份的城市数据
     */
    function initCityData() {
        var uuid = cityPickerUUID;
        //缓存数据定义
        worf.ui.slideUpScrollBox.localData[uuid] = { data1: [], data2: {}, data3: {} };
        //当前数据定义
        worf.ui.slideUpScrollBox.data[uuid] = [];
        //查询省份
        ajax.getProvince(function (json) {
            worf.ui.slideUpScrollBox.data[uuid][0]=json;
            //查询初始城市
            var firstProvince = json[0].value;
            ajax.getCity(firstProvince, function (json) {
                worf.ui.slideUpScrollBox.data[uuid][1]= json;
            });
        });
    }

    /**
        * 选择车辆型号
        */
    var editFlag = true;
    function selectCarSeries() {
        var me = $(this);
        var name = me.find("label").text();
        var element = me.find(".form-value");
        var elementId = element.attr("id");
        var inputMode = me.data("input");
        var regex = me.data("regex");
        var rightText = "";
        var regexMessage = me.data("regexms");
        var inputGroup, getResult, check, rangeUnit, multiSelectData;
        if (elementId == "sp_brand") {
            inputGroup = $("#brandTemplate").html();
        }
        worf.ui.editPage({
            regex: regex,//检验正则
            regexMessage: regexMessage,//检验提示语
            text: element.text(), //当前文本
            name: name,
            rightText: rightText,//头部右侧的按钮文字
            inputMode: inputMode,//输入模式：比如 tel，number
            value: element.attr("data-value"),//当前值
            getResult: getResult,//获取结果的方法
            inputGroup: inputGroup, //输入框的html
            success: function (data) {
                var text = data.modelText;
                var value = data.modelId;
                element.data("brandId", data.brandId).data("seriesId", data.seriesId).data("modelId", data.modelId).data("maxYear", data.maxYear).data("minYear", data.minYear).data("value", value).removeClass("color-gray").text(text);
                $("#sp_month").data("maxYear", data.maxYear).data("minYear", data.minYear).addClass("color-gray").attr("data-value", "").html("请选择");
            },
            opening: function (options) {
                //改变当前显示的头部
                worf.nav.changeHeader(2);
                //设置添加标题
                worf.app.toogleTitle($("#editTitle").text(), { rightTitle: "保存" });
                if (elementId == "sp_brand") {
                    window.carSeriesPicker.init({
                        scrollWrapper: !worf.device.wap ? $("#editInput") : $(document.body),
                        selectModel: function (data) {
                            worf.ui.editPage.hide();
                            data.modelText = carSeriesPicker.currentData.series.text + " " + data.modelText;
                            options.success(data);
                        }
                    });
                }
            },
            closed: function () {
                editFlag = false;
                //改变当前显示的头部
                worf.nav.changeHeader(0);
                //设置添加标题
                worf.app.toogleTitle($(".app-title").eq(0), { rightTitle: "" });
            }
        });
    }
    /**
     * 检查缓存
     */
    function checkCache(){
    	
    	//TODO 检查缓存
    	
        var dataCacheKey = "loan-apply-data";
            var cacheData = worf.localStorage.get(dataCacheKey);
            worf.localStorage.set("loan-apply-back", window.location.href);
            if (cacheData) {
                worf.prompt.confirm("您上次填写的资料还没提交，<br/>是否继续编辑？", function() {
                    worf.prompt.closeMe();
                    worf.nav.go('/view/loan/apply.html');
                }, function() {
                    worf.localStorage.del(dataCacheKey);
                    ajax.cancelEdit(function(){});
                    worf.prompt.closeMe();
                }, { okText: "继续编辑", cancelText: "取消" });
            } 
    }

    /**
    * 返回 
    */
    window.goback = function () {
        //关闭弹出框
        var dialogShow =false;
        ["#scrollBoxWrapper","#datePickerWrapper","#bbBox"].forEach(function(item){
          var element =$(item);
          if(element.length>0 && !element.hasClass("hide")){
             element.addClass("hide");
             dialogShow =true;
          }  
        });
        if(dialogShow){
          return;
        }

        if (pageLevel == 1) {
            worf.animate.sliderRight("#confirmPage");
            //改变当前显示的头部
            worf.nav.changeHeader(0);
            //设置添加标题
            worf.app.toogleTitle($(".app-title").eq(0));
            $("#submitBox").hide();
            pageLevel = 0;
            return;
        }

        worf.nav.back();
    };

    /**
    * 检查员工是否是风控的纳鑫战士
    */
    function checkStaff(){
        worf.ajax({
          animate: true,
          data: null,
          url: worf.API_URL + "/v1/borrowerAudit/checkExistStaff.json",
          errorTip: function (json) {
            worf.prompt.tip(json.message);
            return true;
          },
          success: function (json) {
            if (json.data && json.data.staffNum) {
              worf.nav.go("/view/loan/apply.html");
            } else {
              worf.prompt.tip("您的身份为非纳鑫战士，无法申请贷款");
            }
          }
        });
    }

    window.init = function () {
        checkCache();
        $("#divCity").click(scrollCity);
        $("#divCar").click(selectCarSeries);
        $("#divMonth").click(datePick);
        $("#btnSubmit").click(submit);
        $("#btnGo").click(checkStaff);
        $("#btnLoan").click(function () {
            if (worf.device.wap) {
                worf.nav.go("/view/index/toloan.html", false);
            } else {
                worf.nav.go("/view/index/loan.html", false);
            }
        });
        initCityData();
        window.carSeriesPicker.initData(function (data) {
            //异步更新掉省份数据
            if (data.provinces && data.provinces.length > 0) {
                worf.ui.slideUpScrollBox.localData[cityPickerUUID].data1 = data.provinces;
            }
        });
    };
})(window.Zepto);
