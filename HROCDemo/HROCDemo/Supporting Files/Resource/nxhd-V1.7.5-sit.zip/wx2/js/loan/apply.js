/**
 * 选择地址组件
 */
(function($) {
    //转换数据
    function transData(json) {
        var data = [];
        for (var key in json) {
            data.push({
                text: json[key],
                value: key
            });
        };
        return data;
    }

    var address = {
        localData: {
            all: [],
            province: null,
            city: {},
            area: {},
            error: "",
            firstProvinceCode: null,
            firstCityCode: null
        },
        ajax: {
            getAll: function(callback) {
                worf.ajax({
                    type: "GET",
                    data: null,
                    url: worf.API_URL + "/v1/district/getDistricts.json",
                    success: function(json) {
                        if (json.status == 1) {
                            address.localData.all = json.data;
                            callback && callback(json.data);
                        } else {
                            address.localData.error = json.message;
                        }
                    }
                });
            },
            getProvince: function(callback) {
                var data = address.localData;
                var province = data.province;
                if (data.error) {
                    worf.prompt.tip(data.error);
                    return;
                }
                if (!province) {
                    province = {};
                    $.each(data.all, function(index, item) {
                        if (item.parent == "1" && !province[item.code]) {
                            province[item.code] = item.name;
                        }
                        if (!address.localData.firstProvinceCode) {
                            address.localData.firstProvinceCode = item.code;
                        }
                    });
                    province = transData(province);
                    address.localData.province = $.extend([], province);
                }
                callback && callback(province);
            },
            getCity: function(parentCode, callback) {
                var data = address.localData;
                var city = data.city;
                if (data.error) {
                    worf.prompt.tip(data.error);
                    return;
                }
                if (!city[parentCode]) {
                    var citys = {};
                    $.each(data.all, function(index, item) {
                        if (item.parent == parentCode && !citys[item.code]) {
                            citys[item.code] = item.name;
                            if (!address.localData.firstCityCode) {
                                address.localData.firstCityCode = item.code;
                            }
                        }
                    });
                    city[parentCode] = transData(citys);
                    address.localData.city[parentCode] = $.extend([], city[parentCode]);
                }
                callback && callback(city[parentCode]);
            },
            getArea: function(parentCode, callback) {
                var data = address.localData;
                var area = data.area;
                if (data.error) {
                    worf.prompt.tip(data.error);
                    return;
                }
                if (!area[parentCode]) {
                    var areas = {};
                    $.each(data.all, function(index, item) {
                        if (item.parent == parentCode && !areas[item.code]) {
                            areas[item.code] = item.name;
                        }
                    });
                    area[parentCode] = transData(areas);
                    address.localData.area[parentCode] = $.extend([], area[parentCode]);
                }
                callback && callback(area[parentCode]);
            }
        },
        /*预加载数据*/
        preloadData: function(callback) {
            var ajax = address.ajax;
            ajax.getAll(function() {
                ajax.getProvince(function(pdata) {
                    ajax.getCity(address.localData.firstProvinceCode, function(cdata) {
                        ajax.getArea(address.localData.firstCityCode, function(adata) {
                            callback && callback();
                        });
                    });
                });
            });
        },
        init: function(el, options) {
            var uuid = options.uuid;
            var me = $(el);
            var localData = address.localData;
            var currentValue = (me.data("value") || "").replace(/#/ig, ",").split(",");
            var data = [localData.province, [],
                []
            ];
            if (!currentValue[0]) {
                currentValue[0] = localData.firstProvinceCode;
                currentValue[1] = localData.firstCityCode;
                data[1] = localData.city[localData.firstProvinceCode];
                data[2] = localData.area[localData.firstCityCode];
            } else if (localData.area[currentValue[1]]) {
                data[1] = localData.city[currentValue[0]];
                data[2] = localData.area[currentValue[1]];
            } else {
                var ajax = address.ajax;
                ajax.getCity(currentValue[0], function(city) {
                    localData.city[currentValue[0]] = city;
                    //城市和地区都加载了才弹出来
                    if (localData.area[currentValue[1]]) {
                        address.init(el, { uuid: uuid });
                    }
                });
                ajax.getArea(currentValue[1], function(area) {
                    localData.area[currentValue[1]] = area;
                    //城市和地区都加载了才弹出来
                    if (localData.city[currentValue[0]]) {
                        address.init(el, { uuid: uuid });
                    }
                });
                return;
            }

            if (!localData.firstProvinceCode || !localData.firstCityCode) {
                var el2 = el,
                    uuid2 = uuid;
                setTimeout(function() {
                    address.preloadData(address.init(el2, { uuid: uuid2 }));
                }, 200);
                return;
            }

            worf.ui.slideUpScrollBox({
                el: me,
                controlScroll: options.controlScroll,
                uuid: uuid,
                level: 3,
                currentValue: currentValue,
                data: data,
                getLevel2Data: function(data, callback) {
                    address.ajax.getCity(data.value, callback);
                },
                getLevel3Data: function(data, callback) {
                    address.ajax.getArea(data.value, callback);
                },
                selected: function(data) {
                    data.forEach(function(d) {
                        if (!d.text) {
                            d.text = "";
                        }
                        if (!d.value) {
                            d.value = "";
                        }
                    });

                    var text = data[0].text + " " + data[1].text + " " + data[2].text;
                    var value = data[0].value + "," + data[1].value + "," + data[2].value;
                    text = text.replace("null", "");
                    value = value.replace("undefined", "");
                    me.attr("data-value", value).html(text).removeClass("color-gray");
                    options.selected && options.selected(text, value);
                }
            });
        }
    };
    window.addressPicker = address;
})(Zepto);

/** 
 * 选择车系组件
 */
(function() {
    var scrollWrapper, jRoll;
    var brand = {
        currentData: {
            brand: {},
            series: {}
        },
        localData: {
            brandId: 0, //品牌id
            seriesId: 0, //系列id
            brands: [], //所有品牌数据
            series: {} //车系列数据
        },
        ajax: {
            /*预加载品牌数据*/
            getBrands: function(callback) {
                worf.ajax({
                    data: {},
                    url: worf.API_URL + "/v1/borrowerAudit/queryVehicleBrandList.json",
                    success: function(json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    },
                    errorTip: function(json) {
                        if (!json.data || json.data.length == 0) {
                            callback && callback();
                        }
                    }
                });
            },
            /*获取车品牌*/
            getBrand: function(key, callback) {
                var json = brand.localData.brands;
                if (!json || json.length == 0) {
                    //主动再次请求数据
                    brand.ajax.getBrands(function(data) {
                        brand.localData.brands = data;
                        if (data && data.length > 0) {
                            brand.ajax.getBrand(key, callback);
                        }
                    });
                    return;
                }
                if (key) {
                    var data = [];
                    $.each(json, function(index, item) {
                        if (item.firstLetter == key || item.brand.indexOf(key) > -1) {
                            data.push(item);
                        }
                    });
                    json = data;
                }
                callback && callback(json);
            },
            /*获取车系列*/
            getSeries: function(brandId, callback) {
                var data = brand.localData.series[brandId];
                if (data) {
                    return callback && callback(data);
                }
                worf.ajax({
                    data: {
                        key: brandId
                    },
                    url: worf.API_URL + "/v1/borrowerAudit/queryVehicleSeriesList.json",
                    success: function(json) {
                        if (json.status == 1) {
                            brand.localData.series[brandId] = json.data || [];
                            callback && callback(json.data || []);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    },
                    errorTip: function(json) {
                        if (!json.data || json.data.length == 0) {
                            callback && callback([]);
                        }
                    }
                });
            }
        },

        /**
         * 初始化数据
         */
        initData: function() {
            brand.ajax.getBrands(function(data) {
                brand.localData.brands = data;
            });
        },
        /**
         * 搜索品牌
         */
        searchBrand: function(key) {
            key = key || '';
            brand.ajax.getBrand(key, function(data) {
                //if (!key && data.length == 0) {
                //    worf.ajax.overlayShow();
                //    setTimeout(function () { carSeriesPicker.searchBrand(key); }, 100);
                //    return;
                //}
                //worf.ajax.overlayHide();
                var showNum = "A";
                var html;
                if (!key) {
                    var letter = [];
                    html = '<div class="group-letter" id="letterA">A</div>';
                    for (var i = 0; i < data.length; i++) {
                        var item = data[i];
                        var cssClass = (data[i + 1] && data[i + 1].firstLetter != item.firstLetter) ? "last" : "";
                        if (item.firstLetter == showNum) {
                            html += '<div class="brand ' + cssClass + '" data-id="' + item.brand + '" ><div class="bb-gray">' + item.brand + '</div></div>';
                        } else {
                            html += '<div class="group-letter" id="letter' + item.firstLetter + '">' + item.firstLetter + '</div>';
                            showNum = item.firstLetter;
                            html += '<div class="brand ' + cssClass + '"  data-id="' + item.brand + '" ><div class="bb-gray">' + item.brand + '</div></div>';
                        }
                        if (item.firstLetter != letter[letter.length - 1]) {
                            letter.push(item.firstLetter);
                        }
                    }
                    $("#allBrand").html(html);
                } else {
                    html = '';
                    for (var i = 0; i < data.length; i++) {
                        var item = data[i];
                        html += '<div class="brand"  data-id="' + item.brand + '" ><div class="bb-gray">' + item.brand + '</div></div>';
                    }
                    $("#allBrand").html(html);
                }
                if (!jRoll) {
                    jRoll = new JRoll("#brandScroll", {
                        scrollX: false, //x方向不允许滚动
                        bounce: false //不回弹
                    });
                } else {
                    jRoll.scrollTo(0, 0, 100).refresh();
                }
            });
        },

        /*搜索系列*/
        searchSeries: function(key) {
            brand.ajax.getSeries(key, function(data) {
                var html = "";
                for (var i = 0; i < data.length; i++) {
                    var item = data[i];
                    html += '<div class="series" data-id=' + item + ' ><div class="bb-gray">' + item + '</div></div>';
                }
                $("#allSeries").empty().html(html);
                $("#brandSeriesBg").removeClass("hide");
                setTimeout(function() {
                    $("#brandSeries").addClass("open");
                }, 0);
            });
        },

        selectBrand: function(data) {
            brand.localData.brandId = data.id;
            brand.localData.seriesId = 0;
            brand.localData.modelId = 0;
            brand.currentData.brand = data;
            brand.searchSeries(data.id);
        },
        selectSeries: function(data) {
            brand.localData.seriesId = data.id;
            brand.localData.modelId = 0;
            brand.currentData.series = data;
            brand.searchModel(data.id, data.text);
        },
        bindEvent: function() {
            //选择品牌
            $("#allBrand").on("click", function(e) {
                var me = $(e.target);
                if (me.is(".bb-gray")) me = me.parent();
                if (me.is(".brand")) {
                    brand.selectBrand({
                        id: me.data("id"),
                        text: me.text()
                    });
                    brand.cancelSearch();
                }
            });
            //选择系列
            $("#allSeries").on("click", function(event) {
                var me = $(event.target);
                if (me.is(".bb-gray")) me = me.parent();
                if (me.is(".series")) {
                    brand.selectSeries({
                        id: me.data("id"),
                        text: me.text()
                    });
                }
                event.stopPropagation();
            });
            //切换搜索区域
            $("#brandSearchCenter").click(function() {
                $(this).addClass("hide");
                $("#brandSearch").removeClass("hide");
                setTimeout(function() {
                    $("#txtBrandSearch").focus();
                }, 200);
            });
            //输入框输入事件
            $("#txtBrandSearch").on("input", function() {
                var key = $.trim($(this).val() || "");
                brand.searchBrand(key);
            });
            //字母选中
            $("#brandLetter").click(function(e) {
                var me = $(e.target);
                if (me.is("span")) {
                    if ($("#txtBrandSearch").val() != "") return;
                    var letterSelector = "#letter" + me.text();
                    var y = 0,
                        isFind = false;
                    $("#allBrand").children().each(function(index, item) {
                        item = $(item);
                        var isStop = item.is(letterSelector);
                        if (!isStop) {
                            y += item.height();
                        } else {
                            isFind = true;
                            return false;
                        }
                    });
                    isFind && jRoll.scrollTo(0, 0 - y, 100).refresh();
                }
            });
            //关闭系列 
            $("#brandSeriesBg,#brandSeriesTitle").on("click", function() {
                $("#brandSeries").removeClass("open");
                setTimeout(function() {
                    $("#brandSeriesBg").addClass("hide");
                }, 400);
            });
            //阻止父层滚动
            $("#allSeries").on("scroll", function(event) {
                event.stopPropagation();
                return false;
            });
        },
        /*退回到搜索状态以前*/
        cancelSearch: function() {
            if ($("#brandSearchCenter").hasClass("hide")) {
                brand.searchBrand();
            }
            $("#txtBrandSearch").blur();
            $("#brandSearch").addClass("hide");
            $("#brandSearchCenter").removeClass("hide");
        },
        init: function(options) {
            jRoll = null; //重置
            options = options || {};
            scrollWrapper = options.scrollWrapper ? $(options.scrollWrapper) : document.body;
            if (options.selectSeries) {
                brand.selectSeries = options.selectSeries;
            }
            brand.searchBrand();
            brand.bindEvent();
        }
    };
    window.carSeriesPicker = brand;
})(window.Zepto);

/** 
 * 上传视频组件
 */
(function() {
    var fileSize = 0;
    var mask = $("#btnGroup7 .temp-mask");
    var uploader;
    var watchTime = 0,
        processNum = 0;
    var watchTimer, processTimer;

    /**
     * 重新上传
     * @isClose 用户主动关闭进度
     */
    function showUpload(isStop) {
        resetTimer();
        if (isStop) {
            //uploader.stop();
            uploader.destroy();
            initUploader();
        }
        $("#divVideoSucessWrap").addClass("hide");
        $("#divVideoProcessWrap").addClass("hide");
        $("#divVideoButtonWrap").removeClass("hide");
        $("#hidVideoSize").val("");
        $("#hidVideoUrl").val("");
        mask.addClass("hide");
    }

    /**
     * 监视上传进度
     */
    function watch() {
        watchTime++;
        var processText = $("#spVideoProcessText").text();
        if (watchTime > 3 && processText == "0%") {
            clearTimeout(watchTimer);
            processTimer = setTimeout(walk, 1000);
        } else if (processText != "0%") {
            clearTimeout(watchTimer);
        } else {
            console.log("watch - " + watchTime);
            setTimeout(watch, 1000);
        }
    }

    /**
     * 虚拟进度
     */
    function walk() {
        var percent = processNum + parseFloat(Math.random().toFixed(2), 10);
        if (percent > 99.9) {
            percent = 99.9;
        }
        $("#spVideoProcess").css("width", percent + "%");
        $("#spVideoProcessText").text(percent + "%");
        processNum++;
        if (percent == 99.9) {
            clearTimeout(processTimer);
        } else {
            console.log("walk - " + percent);
            processTimer = setTimeout(walk, 1000);
        }
    }

    /**
     * 重置定时器
     */
    function resetTimer() {
        console.log("resetTimer");
        watchTime = 0, processNum = 0;
        clearTimeout(watchTimer);
        clearTimeout(processTimer);
    }

    /*
     * 初始化上传插件
     **/
    function initUploader() {
        var maxSize = "100";
        uploader = new plupload.Uploader({
            runtimes: 'html5,flash,silverlight,html4',
            browse_button: 'btnSelectVideo',
            multi_selection: false,
            url: worf.API_URL + "/v1/borrowerAudit/uploadVideo.json",
            //container: document.getElementById('container'),
            //flash_swf_url: 'lib/plupload-2.1.2/js/Moxie.swf',
            //silverlight_xap_url: 'lib/plupload-2.1.2/js/Moxie.xap',
            filters: {
                mime_types: [ //只允许上传图片和zip文件
                    {
                        title: "video files",
                        extensions: "3gp,mp4,mov,m4v,avi"
                    }
                ],
                max_file_size: maxSize + "mb", //最大只能上传100M的文件
                prevent_duplicates: false //允许选取重复文件
            },
            chunk_size: "1024mb",
            file_data_name: "videoFile", //提交时文件的参数名
            multipart_params: {
                platform: worf.cookie.get('source') || "wap",
                sessionToken: worf.user.getToken()
            },
            init: {
                //当Init事件发生后触发
                PostInit: function() {

                },
                FilesAdded: function(up, files) {
                    fileSize = files[0].size;
                    var netStatus = worf.app.getNetStatus();
                    var start = function() {
                        $("#spVideoProcess").css("width", "0%");
                        $("#spVideoProcessText").text("0%");
                        $("#divVideoButtonWrap").addClass("hide");
                        $("#divVideoProcessWrap").removeClass("hide");
                        worf.prompt.closeMe();
                        up.start();
                        resetTimer();
                        watch();
                        mask.removeClass("hide");
                    };
                    if (netStatus.status == 0) {
                        worf.prompt.tip("请检查您的网络连接是否正常");
                        return;
                    } else if (netStatus.status != 1) {
                        worf.prompt.confirm("您处于" + netStatus.text + "网络下,继续上传将会消耗您的流量，是否继续？",
                            function() {
                                start();
                            }, null, {
                                okText: "继续"
                            });
                    } else {
                        start();
                    }
                },
                BeforeUpload: function(up, file) {

                },
                UploadProgress: function(up, file) {
                    var percent = file.percent;
                    if (percent > 99.9) {
                        percent = 99.9;
                    }
                    $("#spVideoProcess").css("width", percent + "%");
                    $("#spVideoProcessText").text(percent + "%");
                },
                FileUploaded: function(up, file, info) {
                    resetTimer();
                    var json = JSON.parse(info.response || "{}");
                    if (json.status == 1) {
                        $("#spVideoProcess").css("width", "100%");
                        $("#spVideoProcessText").text("100%");
                        setTimeout(function() {
                            $("#divVideoProcessWrap").addClass("hide");
                            $("#divVideoSucessWrap").removeClass("hide");
                            $("#hidVideoSize").val(fileSize / 1024);
                            $("#hidVideoUrl").val("uploaded");
                            mask.addClass("hide");
                        }, 300);
                    } else {
                        worf.prompt.tip(json.message || "上传发生错误,请重试");
                        showUpload();
                    }
                },
                Error: function(up, err) {
                    resetTimer();
                    if (err && err.code == -600) {
                        worf.prompt.tip("您上传的视频过大，" + maxSize + "M以内");
                    } else {
                        worf.prompt.tip("上传发生错误,请重试");
                    }
                    showUpload();
                }
            }
        });
        uploader.init();
    }

    window.pluploader = {
        init: function() {
            if (!pluploader.isInited) {
                initUploader();
                $("#btnReupload,#btnProcessReupload").click(function() {
                    showUpload(true);
                });
                pluploader.isInited = true;
            }
        }
    };
})(Zepto);

/** 
 * 上传审核资料图片
 */
(function() {
    var isEdit = false; //是否编辑过
    var indexCacheKey = "apply-material-index";
    var imgIndex = parseInt(worf.localStorage.get(indexCacheKey) || "0", 10); //提交的参数，表示序号
    var required = parseInt(worf.localStorage.get("apply-material-required"), 10);
    var hasUploadCount = 0; //标记一次上传中，已经上传的图片数量
    var imgUploadFailCount = 0; //计数上传过程中失败的图片数量
    var imgUploadingState = 0; //标记图片上传状态，0没有上传 图片，1正在上传图片
    var uploadAjaxHandleArr = []; //图片批量上传时，ajax句柄数据
    var material = {
        data: {
            type: null, //上传类型：1：房产资料 2: 车辆登记证 3: 交强险保单合同 4:商业险保单合同 5: 工作证明 6: 央行征信报告 7: 企业资料 8: 收入证明
            subtype: null, //弹出框选择的子类型
            imgCache: {} //选择的图片缓存
        },
        ajax: {
            /*读取定义*/
            getDefined: function(data, callback) {
                worf.ajax({
                    data: data,
                    url: worf.API_URL + "/v1/common/getDefined.json",
                    success: function(json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            },
            /*保存图片数据*/
            upload: function(data, callback, fail) {
                var ajaxHandle = worf.ajax({
                    timeout: 240 * 1000,
                    through: true, //不拦截多次频繁请求
                    data: data,
                    url: worf.API_URL + "/v1/borrowerAudit/uploadAuditPicData.json",
                    errorTip: function(json) {
                        worf.prompt.tip(json.message);
                        fail && fail();
                    },
                    success: function(json) {
                        if (json.status == 1) {
                            isEdit = true;
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                            fail && fail();
                        }
                    }
                });

                return ajaxHandle;
            },
            /*删除图片数据*/
            remove: function(data, callback, fail) {
                worf.ajax({
                    animate: true,
                    data: data,
                    url: worf.API_URL + "/v1/borrowerAudit/deleteAuditPicData.json",
                    errorTip: function(json) {
                        worf.prompt.tip(json.message);
                        fail && fail();
                    },
                    success: function(json) {
                        if (json.status == 1) {
                            isEdit = true;
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                            fail && fail();
                        }
                    }
                });
            },
            /*删除脏数据*/
            clean: function(data, callback, fail) {
                worf.ajax({
                    animate: true,
                    data: data,
                    url: worf.API_URL + "/v1/borrowerAudit/deleteDirtyData.json",
                    errorTip: function(json) {
                        worf.prompt.tip(json.message);
                        fail && fail();
                    },
                    success: function(json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                            fail && fail();
                        }
                    }
                });
            }
        },
        configs: {
            "fczl": {
                //1：房产资料 2: 车辆登记证 3: 交强险保单合同 4:商业险保单合同 5: 工作证明 6: 央行征信报告 7: 企业资料 8: 收入证明
                type: 1,
                header: "房产资料",
                select: true,
                selectData: [{
                    value: 1,
                    text: "房产证和近1个月物业名下的水费单/电费单/燃气费单"
                }, {
                    value: 2,
                    text: "近一个月内的房产查档证明"
                }, {
                    value: 3,
                    text: "抵押贷款合同和最近3个月的抵押还款流水"
                }, {
                    value: 4,
                    text: "房屋购房合同和最近3个月的抵押还款流水"
                }]
            },
            "cldjz": {
                type: 2,
                header: "车辆登记证",
                select: false
            },
            "jqxbdht": {
                type: 3,
                header: "交强险保单合同",
                select: false
            },
            "sybxht": {
                type: 4,
                header: "商业险保单合同",
                select: false
            },
            "gzzm": {
                type: 5,
                header: "工作证明",
                select: true,
                selectData: [{
                    value: 1,
                    text: "社保/公积金缴纳明细",
                    title: "请上传近6个月社保/公积金缴纳明细照片"
                }, {
                    value: 2,
                    text: "银行流水",
                    title: "请上传个人近6个月银行流水照片"
                }]
            },
            "yhzxbg": {
                type: 6,
                header: "央行征信报告",
                title: "请上传近15个自然日内详版央行征信报告照片",
                select: false
            },
            "qyzl": {
                type: 7,
                header: "企业资料",
                select: true,
                selectData: [{
                    value: 1,
                    text: "法人代表身份证",
                    title: "请上传法人代表身份证照片，申请人必须为该企业法人"
                }, {
                    value: 2,
                    text: "有效期内的营业执照",
                    title: "请上传有效期内营业执照照片"
                }, {
                    value: 3,
                    text: "股东会决议、声明书",
                    title: "请上传股东会决议、声明书照片",
                    tip: "提醒：股东会决议、声明书均需股东签字、按手印、盖公司公章并提供所有签名股东的身份证复印件和公司组织机构代码证，并保证签字股东共持有67%以上股份"
                }]
            },
            "srzm": {
                type: 8,
                header: "收入证明",
                select: true,
                selectData: [{
                    value: 1,
                    text: "银行流水",
                    title: "请上传个人近6个月银行流水照片"
                }, {
                    value: 2,
                    text: "征信报告",
                    title: "请上传近15个自然日内详版央行征信报告照片"
                }]
            },
            "xszfy": {
                type: 11,
                header: "行驶证副页",
                select: false
            }
        },
        /*
         * 显示弹出框
         */
        showDialog: function(config, cacheData) {
            //还原选择项
            cacheData = cacheData || {};
            material.data.subtype = cacheData.subtype;
            var divSelectItem = $("#divSelectItem");
            var count = config.selectData.length;
            $("#uploadTitle").text("请选择" + config.header + "的照片类型");
            var selectTitle = "";
            $.each(config.selectData, function(index, item) {
                var isChecked = item.value == (cacheData.subtype || "-1");
                var checkedClass = isChecked ? "radio-checked" : "";
                item.title = item.title || ("请上传" + item.text + "照片");
                selectTitle = isChecked ? item.title : "";
                var itemClass = (index + 1) == count ? "" : "bb-gray";
                divSelectItem.append('<div class="radio-item ' + itemClass + '" data-value="' +
                    item.value + '" data-title="' + item.title + '" data-tip="' + (item.tip || "") + '"><p class="clearfix">' +
                    item.text + '<span class="radio ' + checkedClass + '"><i class="icon-select"></i></span></p></div>');
            });
            $("#divSelectItem .radio-item").click(function() {
                var me = $(this);
                var tip = me.data("tip");
                if (tip) {
                    $("#divUploadTip").text(tip).removeClass("hide");
                } else {
                    $("#divUploadTip").text("").addClass("hide");
                }
                $("#divTitle").text(me.data("title"));
                me.find(".radio").addClass("radio-checked");
                me.siblings().find(".radio").removeClass("radio-checked");
                $("#divSelectItem").data("prev-sbtype", material.data.subtype);
                material.data.subtype = me.data("value");
            });
            //显示重新选择按钮条
            $("#divReChoose").removeClass("hide").click(function() {
                $("#uploadDialog").removeClass("hide");
            });
            //是否已选择过
            var selected = cacheData.subtype;
            if (!selected) {
                $("#uploadDialog").removeClass("hide");
            } else {
                $("#uploadDialog").addClass("hide");
                $("#divTitle").text(selectTitle);
            }
            //是否显示提示
            var tip = "";
            $.each(config.selectData, function(index, item) {
                if (item.value == cacheData.subtype) {
                    tip = item.tip;
                    return false;
                }
            });
            if (tip) {
                $("#divUploadTip").text(tip).removeClass("hide");
            } else {
                $("#divUploadTip").text("").addClass("hide");
            }
        },
        /*关闭弹出框*/
        removeDialog: function() {
            $("#materialPage").remove();
            worf.app.toogleTitle($("#pTitle").text(), {
                rightTitle: "流程"
            });
            this.options.closeCall && this.options.closeCall();
        },
        goback: function() {

            if (worf.prompt.isShow) {
                //正在上传图片的时候，返回无效
                return;
            }


            var that = this;
            //关闭查看大图
            if ($("#imgZoomWrapper").height() > 0) {
                ImagesZoom.close();
                //设置添加标题
                worf.app.toogleTitle(that.config.header, {
                    rightTitle: "保存"
                });
                return;
            }

            //没保存就提示
            if (that.data.imgCache[that.data.type] && that.data.imgCache[that.data.type].images && that.data.imgCache[that.data.type].images.length > 0) {
                //非首次进入
                if (isEdit || imgUploadingState) {
                    worf.prompt.confirm("您填写的资料还未提交,是否放弃？", function() {
                        /*that.data.imgCache[that.data.type] = {
                        	type: material.data.type,
                        	subtype: material.data.subtype
                        };*/

                        //当图片正在上传，停止ajax上传
                        if (imgUploadingState) {
                            worf.ajaxAbortWay = 1;
                            uploadAjaxHandleArr.forEach(function(ajaxHandle, index) {
                                ajaxHandle.abort();
                            });
                            worf.ajaxAbortWay = 0;
                            imgUploadingState = 0;
                        }

                        //清理后台冗余图片
                        var effectiveIndexs = [];
                        var imgsArrOld = that.data.imgCache[that.data.type].images;
                        imgsArrOld.forEach(function(oneImg) {
                            effectiveIndexs.push(oneImg.index);
                        });
                        that.ajax.clean({
                            type: material.data.type,
                            subType: material.data.subtype,
                            effectiveIndexs: effectiveIndexs
                        }, function(data) {
                            that.removeDialog();
                            worf.prompt.closeMe();
                        }, function(data) {
                            that.removeDialog();
                            worf.prompt.closeMe();
                        });

                        /*that.removeDialog();
                        worf.prompt.closeMe();*/
                    }, function() {
                        worf.prompt.closeMe();
                        if (imgUploadingState) {
                            worf.prompt.tip("<p>上传中,一共" + uploadAjaxHandleArr.length + "张,请稍候… </p>", {
                                time: 420 * 1000
                            });
                        }
                    }, {
                        okText: "放弃"
                    });
                } else {
                    that.removeDialog();
                }
            } else {
                if (isEdit || imgUploadingState) {
                    //首次进入，编辑后又点返回，没点保存
                    if ($("#picContainer .upload-img").length > 0 || imgUploadingState) {
                        worf.prompt.confirm("您填写的资料还未提交,是否放弃？", function() {

                            //当图片正在上传，停止ajax上传
                            if (imgUploadingState) {
                                worf.ajaxAbortWay = 1;
                                uploadAjaxHandleArr.forEach(function(ajaxHandle, index) {
                                    ajaxHandle.abort();
                                });
                                worf.ajaxAbortWay = 0;
                                imgUploadingState = 0;
                            }

                            //清理后台冗余图片
                            that.ajax.clean({
                                type: material.data.type,
                                subType: material.data.subtype,
                                effectiveIndexs: []
                            }, function(data) {
                                that.removeDialog();
                                worf.prompt.closeMe();
                            }, function(data) {
                                that.removeDialog();
                                worf.prompt.closeMe();
                            });
                        }, function() {
                            worf.prompt.closeMe();
                            if (imgUploadingState) {
                                worf.prompt.tip("<p>上传中,一共" + uploadAjaxHandleArr.length + "张,请稍候… </p>", {
                                    time: 420 * 1000
                                });
                            }
                        }, {
                            okText: "放弃"
                        });
                    } else {
                        that.ajax.clean({
                            type: material.data.type,
                            subType: material.data.subtype,
                            effectiveIndexs: []
                        }, function(data) {
                            that.removeDialog();
                        }, function(data) {
                            that.removeDialog();
                        });
                    }
                } else {
                    //首次进入，没做编辑
                    that.removeDialog();
                }
            }

        },
        /*初始化图片上传*/
        initUpload: function(e) {
            var that = material,
                me = e;
            var parent = $(me.target).parent();
            var failCall = function() {
                $("#fileAdd").val("");
                worf.prompt.closeMe();
            };
            var imgCount = e.target.files.length;
            hasUploadCount = 0;
            imgUploadFailCount = 0;
            uploadAjaxHandleArr.length = 0; //清空ajax句柄数组
            var base64Arr = [];
            for (var i = 0; i < imgCount; i++) {

                imgUploadingState = 1;
                worf.prompt.tip("<p>上传中,一共" + imgCount + "张,请稍候… </p>", {
                    time: 420 * 1000
                });

                //TODO 上传图片
                var quality = 1;
                if (e.target.files[i].size > 3072000) { //图片大于3M，压缩质量改为0.7
                    quality = 0.7;
                } else if (e.target.files[i].size > 5120000) { //图片大于5M，压缩质量改为0.5
                    quality = 0.5;
                }
                new html5ImgCompress(e.target.files[i], {
                    maxWidth: 5000,
                    maxHeight: 5000,
                    quality: quality,
                    done: function(file, base64) {
                        base64Arr[file.name] = base64;
                        //二次压缩，生成小图base64，防止页面太大而奔溃
                        new html5ImgCompress(file, {
                            maxWidth: 500,
                            maxHeight: 500,
                            quality: 0.4,
                            done: function(file2, base64Small) {
                                var splitArr = file2.name.split(".");
                                var imgType = splitArr[splitArr.length - 1];
                                that.save(base64Arr[file2.name], base64Small, imgCount, i, imgType);
                                base64Arr[file2.name] = ""; //立即清楚存储的大图base64，释放内存
                            }
                        });
                    },
                    fail: function(file) {
                        imgUploadFailCount = imgUploadFailCount + 1;
                        if (imgUploadFailCount == imgCount) {
                            failCall();
                            imgUploadingState = 0;
                            worf.prompt.tip('图片压缩失败');
                        }
                        /*if(file && file.size == 0) {
                        	failCall();
                        } else {
                        	worf.prompt.tip('图片压缩失败');
                        }*/
                    },
                    notSupport: function(file) {
                        worf.prompt.tip('您的手机不支持此上传');
                    }
                });

            }
        },
        save: function(base64, base64Small, totalCount, currentIndex, imgType) {
            var that = material;
            if (!worf.prompt.isShow) {
                worf.prompt.tip("<p>上传中,一共" + totalCount + "张,请稍候… </p>", {
                    time: 420 * 1000
                });
            }

            var failCall = function() {
                $("#fileAdd").val("");
                worf.prompt.closeMe();
            };
            var data = {
                type: material.data.type,
                subType: material.data.subtype,
                suffix: imgType || "png",
                index: ++imgIndex,
                picBase64: base64.split(",")[1]
            };
            worf.localStorage.set(indexCacheKey, imgIndex);

            var uploadAjaxHandle = that.ajax.upload(data, function(imgIndexBack) {
                $("#fileAdd").val("");
                var cssClass = ($("#picContainer .upload-img").length + 1) % 3 == 0 ? "right0" : "";
                $("#spUpload").before('<span class="upload-img ' + cssClass + '" data-index="' + imgIndexBack + '" style="background: url(' + base64Small + ') center center no-repeat;; background-size: cover;"></span>');
                material.showClear();
                hasUploadCount = hasUploadCount + 1;
                if (worf.device.ios) {
                    if (hasUploadCount + imgUploadFailCount >= uploadAjaxHandleArr.length) {
                        worf.prompt.closeMe();
                        if (imgUploadFailCount > 0) {
                            worf.prompt.tip("<p>上传成功" + hasUploadCount + "张, 上传失败" + imgUploadFailCount + "张</p>");
                        }
                        hasUploadCount = 0;
                        imgUploadFailCount = 0;
                        imgUploadingState = 0;
                        uploadAjaxHandleArr.length = 0; //清空ajax句柄数组
                    }
                } else {
                    if (hasUploadCount + imgUploadFailCount >= totalCount) {
                        worf.prompt.closeMe();
                        if (imgUploadFailCount > 0) {
                            worf.prompt.tip("<p>上传成功" + hasUploadCount + "张, 上传失败" + imgUploadFailCount + "张</p>");
                        }
                        hasUploadCount = 0;
                        imgUploadFailCount = 0;
                        imgUploadingState = 0;
                        uploadAjaxHandleArr.length = 0; //清空ajax句柄数组
                    }
                }

            }, function() {
                imgUploadFailCount = imgUploadFailCount + 1; //上传失败加1

                if (worf.device.ios) {
                    if (imgUploadFailCount == uploadAjaxHandleArr.length) {
                        failCall();
                        imgUploadingState = 0;
                        worf.prompt.tip("<p>图片上传失败</p>");
                        uploadAjaxHandleArr.length = 0; //清空ajax句柄数组
                    } else if (hasUploadCount + imgUploadFailCount >= uploadAjaxHandleArr.length) {
                        worf.prompt.closeMe();
                        if (imgUploadFailCount > 0) {
                            worf.prompt.tip("<p>上传成功" + hasUploadCount + "张, 上传失败" + imgUploadFailCount + "张</p>");
                        }
                        hasUploadCount = 0;
                        imgUploadFailCount = 0;
                        imgUploadingState = 0;
                        uploadAjaxHandleArr.length = 0; //清空ajax句柄数组
                    }
                } else {
                    if (imgUploadFailCount == totalCount) {
                        failCall();
                        imgUploadingState = 0;
                        worf.prompt.tip("<p>图片上传失败</p>");
                        uploadAjaxHandleArr.length = 0; //清空ajax句柄数组
                    } else if (hasUploadCount + imgUploadFailCount >= totalCount) {
                        worf.prompt.closeMe();
                        if (imgUploadFailCount > 0) {
                            worf.prompt.tip("<p>上传成功" + hasUploadCount + "张, 上传失败" + imgUploadFailCount + "张</p>");
                        }
                        hasUploadCount = 0;
                        imgUploadFailCount = 0;
                        imgUploadingState = 0;
                        uploadAjaxHandleArr.length = 0; //清空ajax句柄数组
                    }
                }
            });
            uploadAjaxHandleArr.push(uploadAjaxHandle); //保存ajax句柄，用于即时中断ajax
        },
        /*点击图片弹出操作选择框*/
        imgChoose: function(e) {
            var that = material,
                me = e;
            var target = $(me.target);
            var imgIndex = target.data("index");
            if (target.hasClass("upload-img")) {
                worf.ui.slideUpBox({
                    data: {
                        "review": "查看大图",
                        "delete": "删除"
                    },
                    select: function(data) {
                        if (data.value == "review") {
                            var imgData = target.css("background-image").replace("url(", "").replace(")", "").replace(/"/ig, "");
                            ImagesZoom.init({
                                imgDataUrl: imgData,
                                opened: function() {
                                    worf.app.toogleTitle(that.config.header, {
                                        rightTitle: ""
                                    });
                                    $("#divVideoButtonWrap").hide();
                                },
                                closed: function() {
                                    worf.app.toogleTitle(that.config.header, {
                                        rightTitle: "保存"
                                    });
                                    $("#divVideoButtonWrap").show();
                                }
                            });
                        } else if (data.value == "delete") {
                            /*var deleteData = {
                            	type: material.data.type,
                            	subType: material.data.subtype,
                            	index: imgIndex
                            };
                            material.ajax.remove(deleteData, function(data) {
                            	target.remove();
                            	$("#picContainer .upload-img").each(function(index, item) {
                            		var me = $(item).removeClass("right0");
                            		if((index + 1) % 3 == 0) {
                            			me.addClass("right0");
                            		}
                            	});
                            	//that.saveCache();
                            	material.showClear();
                            	worf.ui.slideUpBox.closeMe();
                            }, function(data) {
                            	worf.ui.slideUpBox.closeMe();
                            });*/

                            /*
                             * 删除
                             */

                            target.remove();
                            $("#picContainer .upload-img").each(function(index, item) {
                                var me = $(item).removeClass("right0");
                                if ((index + 1) % 3 == 0) {
                                    me.addClass("right0");
                                }
                            });
                            isEdit = true;
                            material.showClear();
                            worf.ui.slideUpBox.closeMe();

                        }
                    }
                });
            }
        },
        /*检查是否显示清空按钮*/
        showClear: function() {
            var length = $("#picContainer .upload-img").length;
            if (!required && length > 0) {
                $("#btnClear").css("visibility", "visible");
            } else {
                $("#btnClear").css("visibility", "hidden");
            }
        },
        /*多选之后回调*/
        pickCallback: function(imgUrls) {
            //TODO ios上传
            imgUrls = imgUrls || [];
            var imgCount = imgUrls.length;
            hasUploadCount = 0;
            imgUploadFailCount = 0;
            uploadAjaxHandleArr.length = 0; //清空ajax句柄数组
            if (imgCount > 0) {
                for (var i = 0; i < imgCount; i++) {

                    imgUploadingState = 1;
                    worf.prompt.tip("<p>上传中,请稍候… </p>", {
                        time: 420 * 1000
                    });

                    var img = new Image();
                    $(img).data("index", i);
                    img.onload = function() {
                        var imgIndex = $(this).data("index");
                        material.compress(this, imgCount, imgIndex);
                        img = null;
                    };
                    img.src = imgUrls[i];
                }
            } else {
                //worf.prompt.tip("您取消了选择");
                return;
            }
        },
        compress: function(img, imgCount, imgIndex) {
            //用于压缩图片的canvas
            var canvas = document.createElement("canvas");
            var ctx = canvas.getContext('2d');
            //瓦片canvas
            var tCanvas = document.createElement("canvas");
            var tctx = tCanvas.getContext("2d");

            var initSize = 0;
            var width = img.width;
            var height = img.height;

            //如果图片大于四百万像素，计算压缩比并将大小压至400万以下
            var ratio;
            if ((ratio = width * height / 4000000) > 1) {
                ratio = Math.sqrt(ratio);
                width /= ratio;
                height /= ratio;
            } else {
                ratio = 1;
            }
            canvas.width = width;
            canvas.height = height;

            //铺底色
            ctx.fillStyle = "#fff";
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            //如果图片像素大于100万则使用瓦片绘制
            var count;
            if ((count = width * height / 1000000) > 1) {
                count = ~~(Math.sqrt(count) + 1); //计算要分成多少块瓦片
                //计算每块瓦片的宽和高
                var nw = ~~(width / count);
                var nh = ~~(height / count);

                tCanvas.width = nw;
                tCanvas.height = nh;

                for (var i = 0; i < count; i++) {
                    for (var j = 0; j < count; j++) {
                        tctx.drawImage(img, i * nw * ratio, j * nh * ratio, nw * ratio, nh * ratio, 0, 0, nw, nh);

                        ctx.drawImage(tCanvas, i * nw, j * nh, nw, nh);
                    }
                }
            } else {
                ctx.drawImage(img, 0, 0, width, height);
            }

            //进行压缩
            var quality = 1;
            if (width * height > 3072000) { //图片大于3M，压缩质量改为0.7
                quality = 0.7;
            } else if (width * height > 5120000) { //图片大于5M，压缩质量改为0.5
                quality = 0.5;
            }

            /*console.log('压缩前：' + initSize);
            console.log('压缩后：' + ndata.length);
            console.log('压缩率：' + ~~(100 * (initSize - ndata.length) / initSize) + "%");*/
            //tCanvas.width = tCanvas.height = canvas.width = canvas.height = 0;
            material.save(canvas.toDataURL('image/jpeg', quality), canvas.toDataURL('image/jpeg', 0.1), imgCount, imgIndex, "png");
            tCanvas = null;
            canvas = null;
            img = null;
            //return ndata;
        },
        /*还原数据*/
        reloadData: function(data) {
            if (data && data.type) {
                //还原选中弹出框的选择项
                var selectItem = $("#divSelectItem").find(".radio-item[data-value='" + data.subtype + "']");
                selectItem.find(".radio").addClass("radio-checked");
                //还原头部提示信息
                $("#divTitle").text(selectItem.data("title"));
                //还原上传的图片项
                $.each(data.images || [], function(i, item) {
                    var cssClass = (i + 1) % 3 == 0 ? "right0" : "";
                    $("#spUpload").before('<span class="upload-img ' + cssClass + '" data-index="' + item.index + '" style="background: url(' + item.base64 + ') center center no-repeat;; background-size: cover;"></span>');
                    index = item.index;
                });
                material.showClear();
            }
        },
        saveCache: function(type) {

            if (uploadAjaxHandleArr.length > 0) {
                worf.prompt.closeMe();
                uploadAjaxHandleArr.forEach(function(oneAjax, index) {
                    oneAjax.abort();
                });
                hasUploadCount = 0; //标记一次上传中，已经上传的图片数量
                imgUploadFailCount = 0; //计数上传过程中失败的图片数量
                imgUploadingState = 0; //标记图片上传状态，0没有上传 图片，1正在上传图片
            }

            var images = [],
                effectiveIndexs = [];
            $("#picContainer .upload-img").each(function(index, item) {
                var me = $(this);
                var imgIndex = me.data("index");
                effectiveIndexs.push(imgIndex);
                var imgData = me.css("background-image").replace("url(", "").replace(")", "").replace(/"/ig, "");
                images.push({
                    index: imgIndex,
                    base64: imgData
                });
            });

            if (type == "save" && images.length == 0) {
                worf.prompt.tip("请至少上传1张图片");
                return false;
            }
            var saveData = {
                type: material.data.type,
                subtype: material.data.subtype,
                images: images
            };
            this.data.imgCache[this.data.type] = saveData;
            return effectiveIndexs;
        },
        bindEvent: function() {
            var that = this;
            //弹出框-取消
            $("#btnCancel").click(function() {
                that.removeDialog();
            });
            //弹出框-确定
            $("#btnSure").click(function() {
                if ($("#divSelectItem .radio-checked").length == 0) {
                    worf.prompt.tip("请选择照片类型");
                    return;
                }
                worf.app.toogleTitle(that.config.header, {
                    rightTitle: "保存"
                });
                $("#uploadDialog").addClass("hide");
                //获取缓存数据
                var cacheData = that.data.imgCache[that.data.type] || {
                    type: material.data.type,
                    subtype: material.data.subtype
                };
                //删除已上传的
                var prevValue = $("#divSelectItem").data("prev-sbtype");
                if (prevValue && material.data.subtype != prevValue) {
                    $("#picContainer .upload-img").remove();
                    if (material.data.subtype) {
                        var deleteData = {
                            type: material.data.type,
                            subType: parseInt(prevValue, 10),
                            index: 1,
                            deleteType: 1
                        };
                        material.ajax.remove(deleteData);
                        //清空缓存数据中的图片
                        cacheData.images = [];
                    }
                }
                //保存缓存
                cacheData.subtype = material.data.subtype;
                that.data.imgCache[that.data.type] = cacheData;
            });
            //保存
            $("#btnSave").click(function() {
                if (worf.prompt.isShow) {
                    //正在上传图片的时候，保存无效
                    return;
                }

                effectiveIndexs = that.saveCache("save");
                if (!effectiveIndexs) {
                    return;
                }
                that.ajax.clean({
                    type: material.data.type,
                    subType: material.data.subtype,
                    effectiveIndexs: effectiveIndexs
                }, function(data) {
                    that.removeDialog();
                }, function(data) {
                    that.removeDialog();
                });
            });
            //清空
            $("#btnClear").click(function() {
                var me = $(this);
                if (me.data("disabled")) {
                    return;
                }
                me.data("disabled", 1);
                worf.prompt.confirm("是否清空已上传的照片？", function() {
                    //修改缓存
                    $("#picContainer .upload-img").remove();
                    that.saveCache();

                    var deleteData = {
                        type: material.data.type,
                        subType: material.data.subtype,
                        index: 1,
                        deleteType: 1
                    };
                    material.ajax.remove(deleteData, function(data) {
                        isEdit = true;
                        that.removeDialog();
                        worf.prompt.closeMe();
                    }, function(data) {
                        worf.prompt.closeMe();
                        that.removeDialog();
                    });
                    me.data("disabled", 0);
                }, function() {
                    worf.prompt.closeMe();
                    me.data("disabled", 0);
                });
            });
        },
        init: function(options) {
            var that = this;
            isEdit = false;
            that.inited = true;
            that.data.subtype = null;
            var type = that.data.type;
            that.config = that.configs[type];
            that.options = options || {};
            material.data.type = that.config.type;
            var cacheData = that.data.imgCache[material.data.type] || {};
            var config = that.config;

            this.removeDialog();
            $(document.body).append($("#materialTemplate").html());
            //改变当前显示的头部
            worf.nav.changeHeader("#materialHeader");
            //设置添加标题
            worf.app.toogleTitle(config.header, {
                rightTitle: "保存"
            });

            //判断是否弹出框来选择
            if (config.select) {
                material.showDialog(config, cacheData);
            } else {
                $("#divTitle").text(config.title || "请上传" + config.header + "照片");
            }

            if (worf.device.ios) {
                multiImagePickCallback = that.pickCallback;
                $("#fileAdd").on('click', function(event) {
                    window.app && app.multiImagePick("{}");
                    event.preventDefault();
                    event.stopPropagation();
                });
            } else {
                $("#fileAdd").on('change', that.initUpload);
            }

            $("#picContainer").click(that.imgChoose);
            that.bindEvent();
            that.reloadData(cacheData);
            //调整高度
            $("#picContainer").css("min-height", worf.tools.getViewHeight() - _FONT_SIZE * 2.3);
        }
    };
    window.materialUpload = material;
})(Zepto);

/**
 * 申请
 */
(function($) {
    var editFlag = true;
    var pageTitle = "个人信息";
    var showPartner = false; //显示共借人
    var localData = []; //缓存数据
    var submitData = {}; //要提交的数据
    var carExistLoan = false; //车牌号是否已经存在贷款
    var carExistLoanMessage = ""; //车牌号是否已经存在贷款的提示
    var OCRFlag = {
        "2": 0,
        "3": 0
    }; //图像识别标记
    var dataCacheKey = "loan-apply-data";
    var currentPage = $("#step1");
    var isSubmited = false; //是否已提交
    var pageInitTimestamp = 0; //刚进入页面时，从后台获取的时间戳

    var itemConfig = {
        //申请期数
        installment: {
            "1": "1期",
            "2": "2期",
            "3": "3期",
            "4": "4期",
            "5": "5期",
            "6": "6期",
            "12": "12期",
            "18": "18期"
        },
        //职业身份
        apprIdentity: {
            "0": "企业股东",
            "1": "受薪人士",
            "2": "自雇人士"
        },
        //每月支薪日
        companyPayDate: {}
    };
    //每月支薪日
    for (var i = 1; i <= 31; i++) {
        itemConfig.companyPayDate[i] = i;
    }

    /**
     * 申请
     */
    var apply = {
        element: {
            pages: $(".page")
        },
        ajax: {
            localData: {
                store: []
            },
            /*获取刚进入页面的后台时间戳*/
            getInitTimestamp: function(callback) {
                worf.ajax({
                    url: worf.API_URL + "/v1/borrowerAudit/getStartAuditTime.json",
                    success: function(json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            },
            /*读取定义*/
            getDefined: function(data, callback) {
                worf.ajax({
                    data: data,
                    url: worf.API_URL + "/v1/common/getDefined.json",
                    success: function(json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            },
            //获取信息认证的二维码
            getAuthCode: function(data, callback) {
                worf.ajax({
                    data: data,
                    url: worf.API_URL + "/v1/borrowerAudit/getQRUrl.json",
                    success: function(json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            },
            //图片识别
            OCR: function(data, callback, fail, ajaxFall) {
                function bindData(data, type) {
                    var keys = {
                        "2": ["cardName", "sex", "birthday", "cardNo", "age"],
                        "3": ["cardExpireDateShow"],
                        "6": ["carCardPlateNo", "carCardRegDate", "carCardPublishDate", "carCardVin", "carCardVen", "carCardType"]
                    }[type];
                    var bind = function(el, value, text) {
                        el = $(el);
                        if (value !== null && value !== undefined && value !== "") {
                            if (el.is("input")) {
                                el.val(value);
                            } else {
                                el.attr("data-value", value).text(text);
                                el.removeClass("color-gray");
                            }
                        } else {
                            text = el.data("default");
                            if (el.is("input")) {
                                el.val("");
                            } else {
                                el.attr("data-value", "").text(text);
                                el.addClass("color-gray");
                            }
                        }
                    };
                    var toCamel = function(str) {
                        return str.replace(/\w/, function(v) {
                            return v.toUpperCase()
                        });
                    };
                    for (var key in keys) {
                        key = keys[key];
                        var value = data[key] || "";
                        var text = value;
                        if (key == "sex") {
                            text = itemConfig.userSex[value] || "";
                        } else if (key == "carCardRegDate" || key == "carCardPublishDate") {
                            value = value ? worf.tools.dateFormat(value, "yyyy-MM-dd") : "";
                            text = value;
                            key = key + "Str";
                        }
                        bind("#txt" + toCamel(key), value, text);
                        bind("#sp" + toCamel(key), value, text);
                    }

                    if (type == 6 && data.carCardPlateNo) {
                        apply.ajax.checkExistLoan(data.carCardPlateNo);
                    }
                }
                //控制显示
                function showGroup(data) {
                    OCRFlag[data.cardType] = 1;
                    if (OCRFlag["2"] == 1 && OCRFlag["3"] == 1) {
                        $("#userGroup").removeClass("hide");
                    }
                    if (OCRFlag["6"] == 1) {
                        $("#carPurchaseGroup").removeClass("hide");
                    }
                }

                function hideGroup(data) {
                    OCRFlag[data.cardType] = 0;
                    $("#userGroup").addClass("hide");
                }

                worf.ajax({
                    timeout: 60 * 1000,
                    data: data,
                    url: worf.API_URL + "/v1/borrowerAudit/cardRecognition.json",
                    errorTip: function(json) {
                        if (json.status == -10000) {
                            worf.prompt.tip(json.message);
                            bindData({}, data.cardType);
                            hideGroup(data);
                            ajaxFall && ajaxFall(json);
                        } else {
                            worf.prompt.tip(json.message);
                            bindData({}, data.cardType);
                            showGroup(data);
                            fail && fail(json);
                        }
                    },
                    success: function(json) {
                        showGroup(data);
                        if (json.status == 1) {
                            bindData(json.data, data.cardType);
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                            fail && fail();
                        }
                    }
                });
            },
            //图片上传
            upload: function(data, callback, fail) {
                worf.ajax({
                    timeout: 60 * 1000,
                    data: data,
                    url: worf.API_URL + "/v1/borrowerAudit/uploadCarPic.json",
                    errorTip: function(json) {
                        worf.prompt.tip(json.message);
                        fail && fail();
                    },
                    success: function(json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                            fail && fail();
                        }
                    }
                });
            },
            //门店列表
            storeList: function(callback, fail) {
                worf.ajax({
                    type: "GET",
                    data: {},
                    url: worf.API_URL + "/v1/borrowerAudit/getStoreDetails.json",
                    success: function(json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                            fail && fail();
                        }
                    }
                });
            },
            /*保存缓存*/
            saveCache: function(data, callback) {
                worf.ajax({
                    data: data,
                    url: worf.API_URL + "/v1/borrowerAudit/cache.json",
                    success: function(json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                            fail && fail();
                        }
                    }
                });
            },
            /*检查推荐人编号*/
            checkExistStaff: function(callback, fail) {
                worf.ajax({
                    animate: true,
                    data: null,
                    url: worf.API_URL + "/v1/borrowerAudit/checkExistStaff.json",
                    errorTip: function(json) {
                        fail && fail(json);
                        return true;
                    },
                    success: function(json) {
                        if (json.status == 1 && json.data) {
                            callback && callback(json.data);
                        } else {
                            fail && fail(json);
                        }
                    }
                });
            },
            /*检查车牌是否已有借款*/
            checkExistLoan: function(carNumber, callback) {
                carExistLoan = false;
                worf.ajax({
                    animate: false,
                    data: {
                        key: carNumber
                    },
                    url: worf.API_URL + "/v1/borrowerAudit/checkPlateNo.json",
                    errorTip: function(json) {
                        this.success(json);
                        return true;
                    },
                    success: function(json) {
                        carExistLoan = (json.data == 2) || (json.status == 0);
                        carExistLoanMessage = json.message;
                        //显示温馨提示
                        if (json.data == 3) {
                            $("#divSubmitTip").text(json.message).removeClass("hide");
                        } else {
                            $("#divSubmitTip").addClass("hide");
                        }
                    }
                });
            },
            /*提交*/
            submit: function(data, callback, fail) {
                ["job", "sex", "age", "maritalStatus", "livingType", "hasHouse", "houseStatus", "carTimes", "companyJob", "companySalary", "companyPaymentMethod", "freelanceSalary", "relativeKnown", "installment", "loanPurposesType", "loanMoney", "auditVideoSize", "companyPayDate"].forEach(function(item) {
                    if (/\d+(\.\d+)?/ig.test(data[item])) {
                        data[item] = parseFloat(data[item], 10);
                    }
                });
                //增加时间戳 参数
                data.startAuditTime = pageInitTimestamp;

                worf.ajax({
                    animate: true,
                    timeout: 5 * 60 * 1000,
                    data: data,
                    url: worf.API_URL + "/v1/borrowerAudit/submitAuditData.json",
                    errorTip: function(json) {
                        worf.prompt.tip(json.message);
                        fail && fail(json);
                    },
                    success: function(json) {
                        if (json.status == 1) {
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message || "提交发生错误,请重试");
                        }
                    }
                });
            }
        },
        /*清空*/
        clear: function(el) {
            el = $(el);
            var defaultText = el.data("default");
            if (el.is("input")) {
                el.val("").addClass("color-gray");
            } else {
                el.attr("data-value", "").text(defaultText).addClass("color-gray");
            }
        },
        /*底部弹出滚动选择框*/
        slideUpScrollBox: function() {
            var me = $(this),
                type = me.data("box-scroll"),
                required = me.find(".form-value").data("val").toString().indexOf("required") > -1,
                config = itemConfig[type];
            worf.ui.slideUpScrollBox({
                el: me,
                notRequired: !required,
                level: 1,
                currentValue: [me.find(".form-value").data("value")],
                data: config,
                selected: function(data) {
                    //记录选择的数据
                    var el = me.find(".form-value");
                    var name = el.attr("name");
                    var value = data[0].value;
                    var text = data[0].text;
                    if (value == worf.ui.slideUpScrollBox.setting.notRequired) {
                        value = "";
                        text = el.data("default") || "选填";
                    }
                    apply.saveCache(null, name, value, text);
                    el.attr("data-value", value).text(text).removeClass("color-gray");
                    if (type == "installment") {
                        $("#refundTypeGroup").removeClass("hide");
                        $("#spRefundType").text(value < 6 ? "先息后本" : "等额等息");
                    }
                }
            });
        },
        /*底部弹出选择框*/
        slideUpBox: function() {
            var me = $(this),
                type = me.data("box"),
                value = me.find(".form-value").attr("data-value"),
                required = me.find(".form-value").data("val").toString().indexOf("required") > -1,
                name = me.find("label[for]").attr("for"),
                config = itemConfig[type];
            worf.ui.slideUpBox({
                data: config,
                value: value,
                notRequired: !required,
                select: function(data) {
                    //记录选择的数据
                    var el = me.find(".form-value");
                    var name = el.attr("name");
                    var value = data.value;
                    var text = data.text;
                    if (value == worf.ui.slideUpBox.setting.notRequired) {
                        value = "";
                        text = el.data("default") || "选填";
                    }
                    apply.saveCache(null, name, value, text);
                    el.attr("data-value", value).text(text);
                    if (value === "") {
                        el.addClass("color-gray");
                    } else {
                        el.removeClass("color-gray");
                    }
                    //【职业身份】不同第四页填写的内容不同
                    if (type == "apprIdentity") {
                        apply.changeJob(value);
                    } else if (type == "maritalStatus") {
                        //婚姻状况为已婚，配偶为必填，其它填写直系亲属信息
                        $("#txtStepTitle5").text(value == 2 ? "5.配偶" : "5.直系亲属");
                    } else if (type == "yesNoNum" && name == "hasHouse") {
                        //“本人是否有本地商品房”若选择“是”时 打开房产资料
                        if (value == 0) {
                            $("#houseAddrGroup,#houseStatusGroup").removeClass("hide");
                            $("#fczlGroup").removeClass("hide").find(".form-value").attr("data-val", "required");
                            $("#divHouseStatus").addClass("bb-gray");
                        } else {
                            $("#houseAddrGroup,#houseStatusGroup").addClass("hide");
                            $("#fczlGroup").addClass("hide").find(".form-value").attr("data-val", "1");
                            $("#divHouseStatus").removeClass("bb-gray");
                        }
                    }
                }
            });
        },
        /*改变职业身份时-变换第四步填写的内容块*/
        changeJob: function(job) {
            $("#step41,#step42,#step43").removeClass("active").addClass("hide");
            var temp = $("#step4" + (job * 1 + 1));
            temp.addClass("active");
            $("#mapStep4 p").text(temp.find(".form-title").text().replace("4.", ""));
        },
        /*底部弹出时间选择框*/
        datePick: function() {
            var me = $(this);
            var type = me.data("field");
            var name = me.find("label").attr("for");
            var required = me.find(".form-value").data("val").toString().indexOf("required") > -1;
            var value = me.find(".form-value").data("value");
            var year = value && value.substr(0, 4);
            var minYear, maxYear;
            var month = value && parseInt(value.substr(5, 2), 10);
            var day = value && parseInt(value.substr(8, 2), 10);
            if (name == "birthday") {
                minYear = new Date().getFullYear() - 100;
            } else if (name == "cardExpireDateShow") {
                maxYear = new Date().getFullYear() + 30;
                minYear = maxYear - 30;
            } else if (name == "moveToDateStr" || name == "companyJoinDateStr") {
                minYear = 1900;
            }
            var clearCall = function(el) {
                apply.clear(el);
                apply.saveCache(null, name, "", "");
            };

            worf.ui.datePicker({
                el: me,
                notRequired: !required,
                clearCall: clearCall,
                year: year,
                month: month,
                day: day,
                max: {
                    year: maxYear
                },
                min: {
                    year: minYear
                },
                selected: function(year, month, day) {
                    month = month < 10 ? "0" + month : month;
                    day = day < 10 ? "0" + day : day;
                    var data = year + "-" + month + "-" + day;
                    //记录选择的数据
                    var el = me.find(".form-value");
                    var name = el.attr("name");
                    apply.saveCache(null, name, data, data);
                    el.attr("data-value", data).text(data).removeClass("color-gray");
                }
            });
        },
        /* 获取定义*/
        getDefined: function(callback) {
            apply.ajax.getDefined(["installment", "apprIdentity", "userSex", "maritalStatus", "education", "housingType", "yesNoNum", "housingStatus", "apprJob", "payDeal", "yesNoNum", "loanPurposesEnum", "carOwnershipEnum"], function(data) {
                for (var key in data) {
                    itemConfig[key] = data[key];
                }
                callback && callback();
            });
        },
        /*初始化18张车图片上传*/
        initUpload: function(e) {

            //TODO 图片上传2

            var that = apply,
                me = e;
            var parent = $(me.target).parent();
            var cardIndex = $(me.target).data("index");
            var failCall = function() {
                parent.css({
                    "background": null,
                    "background-size": null
                });
                parent.find("b.ok").addClass("hide");
                parent.find("b.sel").removeClass("hide");
                parent.find("input[type='file']").removeClass("hide").val("");
                parent.find(".form-value").val("");
                worf.prompt.closeMe();
            };
            worf.prompt.tip("<p>上传中,请稍候… </p>", {
                time: 50 * 1000
            });
            var base64Big = "";
            new html5ImgCompress(e.target.files[0], {
                maxWidth: 5000,
                maxHeight: 5000,
                quality: 1,
                done: function(file, base64) {
                    base64Big = base64;
                    new html5ImgCompress(file, {
                        maxWidth: 500,
                        maxHeight: 500,
                        quality: 0.4,
                        done: function(file, base64Small) {
                            that.ajax.upload({
                                type: cardIndex,
                                carPic: base64Big.split(",")[1]
                            }, function(data) {
                                parent.css({
                                    "background": "url(" + base64Small + ") center center no-repeat;",
                                    "background-size": "contain"
                                });
                                parent.find(".form-value").val(data);
                                parent.find("b.ok").removeClass("hide");
                                parent.find("input[type='file']").addClass("hide").val("");
                                parent.find("b.sel").addClass("hide");
                                worf.prompt.closeMe();
                            }, function() {
                                failCall();
                            });
                            base64Big = "";
                        }
                    });


                },
                fail: function(file) {
                    if (file && file.size == 0) {
                        failCall();
                    } else {
                        worf.prompt.tip('图片压缩失败');
                    }
                },
                notSupport: function(file) {
                    worf.prompt.tip('您的手机不支持此上传');
                }
            });
        },
        /*ios上传12张图片*/
        iosCarlistFile: function(base64Big, base64Small, elementId) {
            //TODO ios12

            var that = apply;
            var parent = $("#" + elementId).parent();
            var cardIndex = $("#" + elementId).data("index");
            var failCall = function() {
                parent.css({
                    "background": null,
                    "background-size": null
                });
                parent.find("b.ok").addClass("hide");
                parent.find("b.sel").removeClass("hide");
                parent.find("input[type='file']").removeClass("hide").val("");
                parent.find(".form-value").val("");
                worf.prompt.closeMe();
            };

            that.ajax.upload({
                type: cardIndex,
                carPic: base64Big.split(",")[1]
            }, function(data) {
                parent.css({
                    "background": "url(" + base64Small + ") center center no-repeat;",
                    "background-size": "contain"
                });
                parent.find(".form-value").val(data);
                parent.find("b.ok").removeClass("hide");
                parent.find("input[type='file']").addClass("hide").val("");
                parent.find("b.sel").addClass("hide");
                worf.prompt.closeMe();
            }, function() {
                failCall();
            });

        },
        /*点击18张车图片弹出操作选择框*/
        carPicChoose: function(e) {
            var that = apply,
                me = e;
            var target = $(me.target);
            var file = target.find("input[type='file']");
            if (file.hasClass("hide")) {
                worf.ui.slideUpBox({
                    data: {
                        "review": "查看大图",
                        "reupload": "重新上传"
                    },
                    select: function(data) {
                        //console.log(data);
                        if (data.value == "review") {
                            var imgData = target.css("background-image").replace("url(", "").replace(")", "").replace(/"/ig, "");
                            //$("#reviewWrapper").removeClass("hide");
                            //$("#imgPicReview").attr("src", imgData);

                            ImagesZoom.init({
                                imgDataUrl: imgData,
                                opened: function() {
                                    worf.app.toogleTitle($("#pTitle").text(), {
                                        rightTitle: ""
                                    });
                                    $("#divVideoButtonWrap").hide();
                                },
                                closed: function() {
                                    worf.app.toogleTitle($("#pTitle").text(), {
                                        rightTitle: "流程"
                                    });
                                    $("#divVideoButtonWrap").show();
                                }
                            });
                        } else if (data.value == "reupload") {
                            target.css({
                                "background": null,
                                "background-size": null
                            });
                            target.find("b.ok").addClass("hide");
                            target.find("b.sel").removeClass("hide");
                            target.find(".form-value").val("");
                            file.removeClass("hide").val("");
                        }
                    }
                });
            }
        },
        /*初始化图片识别*/
        initOCR: function(e) {

            //TODO OCR

            var that = apply,
                me = e;
            var parent = $(me.target).parent();
            var cardType = $(me.target).data("type");


            /*userCanceled:用户主动取消*/
            var failCall = function(userCanceled) {
                var isPicked = $("#uploadFlag" + cardType).val() == "1";
                if (userCanceled && isPicked) {
                    worf.prompt.closeMe();
                    return;
                }

                parent.css({
                    "background": null,
                    "background-size": null
                });
                $("#uploadFlag" + cardType).val("");
                parent.find("input[type='file']").val("");
                parent.find("b").addClass("hide");
                parent.find("b.sel").removeClass("hide");
                worf.prompt.closeMe();
            };

            var successCall = function(cardType, base64, parsed) {
                parent.css({
                    "background": "url(" + base64 + ") center center no-repeat;",
                    "background-size": "contain"
                });
                $("#uploadFlag" + cardType).val(1);
                parent.find("input[type='file']").val("");
                parent.find("b").addClass("hide");
                parsed && parent.find("b.ok").removeClass("hide");
                !parsed && parent.find("b.fail").removeClass("hide");
                worf.prompt.closeMe();
            };

            //ajax调用失败
            var ajaxFallCall = function(cardType, base64, parsed) {
                parent.attr("style", "");
                $("#uploadFlag" + cardType).val(1);
                parent.find("input[type='file']").val("");
                parent.find("b").addClass("hide");
                worf.prompt.closeMe();
            };

            worf.prompt.tip("<p>正在解析照片中的数据</p><p>请稍等…</p>", {
                time: 60 * 1000
            });
            var quality = 1;
            if (e.target.files[0].size > 3000000) { //图片大小不能超过3M
                quality = 0.7;
            } else if (e.target.files[0].size > 5120000) { //图片大小不能超过5M
                quality = 0.5;
            }

            var base64Big = "";
            new html5ImgCompress(e.target.files[0], {
                maxWidth: 2000,
                maxHeight: 2000,
                quality: quality,
                done: function(file, base64) {
                    base64Big = base64;
                    new html5ImgCompress(file, {
                        maxWidth: 500,
                        maxHeight: 500,
                        quality: 0.4,
                        done: function(file2, base64Small) {
                            that.ajax.OCR({
                                cardType: cardType,
                                img: base64Big.split(",")[1]
                            }, function(data) {
                                successCall(cardType, base64Small, true);
                            }, function(json) {
                                successCall(cardType, base64Small, false);
                            }, function(json) {
                                ajaxFallCall(cardType, base64Small, false);
                            });
                            base64Big = ""; //立刻释放内存
                        }
                    });
                },
                fail: function(file) {
                    if (file && file.size == 0) {
                        failCall(true);
                    } else {
                        worf.prompt.tip('图片压缩失败');
                    }
                },
                notSupport: function(file) {
                    failCall();
                    worf.prompt.tip('您的手机不支持此上传');
                }
            });
        },
        /*ios分析OCR*/
        iosOCR: function(base64Big, base64Small, elementId) {
            var that = apply;
            var parent = $("#" + elementId).parent();
            var cardType = $("#" + elementId).data("type");


            /*userCanceled:用户主动取消*/
            var failCall = function(userCanceled) {
                var isPicked = $("#uploadFlag" + cardType).val() == "1";
                if (userCanceled && isPicked) {
                    worf.prompt.closeMe();
                    return;
                }

                parent.css({
                    "background": null,
                    "background-size": null
                });
                $("#uploadFlag" + cardType).val("");
                parent.find("input[type='file']").val("");
                parent.find("b").addClass("hide");
                parent.find("b.sel").removeClass("hide");
                worf.prompt.closeMe();
            };

            var successCall = function(cardType, base64, parsed) {
                parent.css({
                    "background": "url(" + base64 + ") center center no-repeat;",
                    "background-size": "contain"
                });
                $("#uploadFlag" + cardType).val(1);
                parent.find("input[type='file']").val("");
                parent.find("b").addClass("hide");
                parsed && parent.find("b.ok").removeClass("hide");
                !parsed && parent.find("b.fail").removeClass("hide");
                worf.prompt.closeMe();
            };

            //ajax调用失败
            var ajaxFallCall = function(cardType, base64, parsed) {
                parent.attr("style", "");
                $("#uploadFlag" + cardType).val(1);
                parent.find("input[type='file']").val("");
                parent.find("b").addClass("hide");
                worf.prompt.closeMe();
            };

            that.ajax.OCR({
                cardType: cardType,
                img: base64Big.split(",")[1]
            }, function(data) {
                successCall(cardType, base64Small, true);
            }, function(json) {
                successCall(cardType, base64Small, false);
            }, function(json) {
                ajaxFallCall(cardType, base64Small, false);
            });

        },
        /*检查年龄*/
        checkAge: function(data, callback) {
            //--去掉共借人-2017.1.3
            //填写共借人的条件：20≤年龄≤22  或   61≤年龄≤65
            //showPartner = data.age > 0 && ((data.age >= 20 && data.age <= 22) || (data.age >= 61 && data.age <= 65));
            return true;
        },
        /*打开编辑页*/
        openEidt: function() {
            var me = $(this);
            var name = me.find("label").text();
            var element = me.find(".form-value");
            var elementId = element.attr("id");
            var elementName = element.attr("name");
            var mode = me.data("mode");
            var rightText = me.data("title-righttext");
            var inputMode = me.data("input");
            var regex = me.data("regex");
            var helpTip = me.data("helptip");
            var regexMessage = me.data("regexms");
            var placeholder = me.data("placeholder");
            var maxlength = me.data("maxlength");
            var required = me.find(".form-value").data("val").toString().indexOf("required") > -1;
            var inputGroup, getResult, check, checkIsAsync, rangeUnit, multiSelectData, radioSelectData, controlScroll;
            var clearCall = apply.clear;
            /*选择地址*/
            if (mode == "address") {
                //是否控制滚动
                controlScroll = false,
                    inputGroup = $("#addressTemplate").html();
                getResult = function(wrapper) {
                    var selAddress = wrapper.find("#selAddress");
                    var text = selAddress.text();
                    var value = selAddress.attr("data-value") || "";
                    var detail = $.trim(wrapper.find("#selAddressDetail").val());
                    return {
                        text: [text + " " + detail],
                        value: [value.replace(/\,/ig, "#") + "#" + detail]
                    };
                };
                check = function(data) {
                    var values = (data.value || "").split("#");
                    if (values.length < 4) {
                        worf.prompt.tip("请选择所在地区");
                        return false;
                    } else if (values[3] == "") {
                        worf.prompt.tip("请输入详细地址");
                        return false;
                    } else if (values[3].length < 5) {
                        worf.prompt.tip("详细地址不能少于5个字");
                        return false;
                    } else if (values[3].length > maxlength) {
                        worf.prompt.tip("详细地址不能超过" + maxlength + "个字");
                        return false;
                    } else if (values.length > 4) {
                        worf.prompt.tip("详细地址中不能包含字符#");
                        return false;
                    }
                    return true;
                };
            } else if (elementName == "carSeries") {
                inputGroup = $("#brandTemplate").html();
            } else if (elementName == "carCardPlateNo") {
                inputGroup = $("#carNoTemplate").html();
                getResult = function(wrapper) {
                    var value = [];
                    var text = [];
                    var num = (wrapper.find(".carno-group").text() + wrapper.find("input").val()).replace(/\s/ig, "").toUpperCase();
                    value.push(num);
                    text.push(num);
                    apply.ajax.checkExistLoan(num);
                    return {
                        text: text,
                        value: value
                    };
                }
            } else if (elementName == "store") {
                inputGroup = '<div class="main_view" id="allStore"></div>';
            } else if (elementName == "loanPurposesType") {
                //借款用途
                var extraItemName = "其他";
                radioSelectData = {
                    data: $.map(itemConfig.loanPurposesEnum, function(index, item) {
                        return {
                            text: itemConfig.loanPurposesEnum[item],
                            value: item
                        };
                    }),
                    extraName: extraItemName,
                    extra: true
                };
                check = function(data) {
                    //如果是选择了【其他】必须输入说明
                    if (data.text == extraItemName) {
                        if (!data.singleSelectExtra) {
                            worf.prompt.tip("请输入文字说明");
                            return false;
                        } else if (data.singleSelectExtra.length > data.maxlength) {
                            worf.prompt.tip("文字说明不能超过" + data.maxlength + "字");
                            return false;
                        }
                    }
                    return true;
                };
            }

            worf.ui.editPage({
                el: me,
                mode: mode, //输入框的模式 input,textarea,range
                placeholder: placeholder, //提示信息
                maxlength: maxlength, //字数限制
                regex: regex, //检验正则
                notRequired: !required, //是否是选填项
                clearCall: clearCall, //清空方法
                regexMessage: regexMessage, //检验提示语
                rightText: rightText, //头部右侧的按钮文字
                text: element.text(), //当前文本
                inputMode: inputMode, //输入模式：比如 tel，number
                value: element.attr("data-value"), //当前值
                name: name,
                helpTip: helpTip, //输入框下面的提示语
                multiSelectData: multiSelectData, //多选项的数据
                radioSelectData: radioSelectData, //单选项的数据
                radioExtraText: element.attr("data-extra"), //单选项的填写数据
                getResult: getResult, //获取结果的方法
                check: check, //检查结果的方法
                checkIsAsync: checkIsAsync, //是否是异步检查结果
                inputGroup: inputGroup, //输入框的html
                success: function(data) {
                    var text = data.text;
                    var value = data.value;
                    var suffix = element.data("suffix") || "";
                    if (suffix) {
                        text = text.replace(suffix, "") + suffix;
                    }
                    element.data("value", value).text(text).removeClass("color-gray");
                    //缓存选择的数据
                    var name = element.attr("name");
                    apply.saveCache(null, name, value, text);
                    //借款用途-填写的内容
                    if (data.name == "借款用途") {
                        value = data.singleSelectExtra || "";
                        $("#spLoanPurposes").attr("data-value", value);
                        element.attr("data-extra", value);
                        //缓存选择的数据
                        name = $("#spLoanPurposes").attr("name");
                        apply.saveCache(null, name, value, value);
                    }
                },
                berforeOpening: function() {
                    if (elementId != "selAddress") {
                        apply.scroll.top();
                    }
                },
                opening: function(options) {
                    //改变当前显示的头部
                    worf.nav.changeHeader("#editFormHeader");
                    //设置添加标题
                    worf.app.toogleTitle($("#editTitle").text(), {
                        rightTitle: "保存"
                    });
                    if (mode == "textarea") {
                        if (options.notRequired && (options.value || "").length > 0) {
                            $("#btnTextAreaClear").removeClass("hide").off().click(function() {
                                options.clearCall(options.el.find(".form-value"));
                                worf.ui.editPage.hide();
                            });
                        } else {
                            $("#btnTextAreaClear").addClass("hide");
                        }
                    } else if (mode == "address") {
                        var value = element.data("value") || "";
                        var text = element.text() || "";
                        //选填项打开【清空所填内容】
                        if (value && options.notRequired) {
                            $("#btnAddressClear").removeClass("hide").off().click(function() {
                                options.clearCall(options.el.find(".form-value"));
                                worf.ui.editPage.hide();
                            });
                        } else {
                            $("#btnAddressClear").addClass("hide");
                        }

                        if (value) {
                            var values = value.split("#");
                            var texts = text.split(" ");
                            var addressValue = values.slice(0, 3).join("#");
                            var addressText = texts.slice(0, 3).join(" ");
                            $("#selAddress").attr("data-value", addressValue).text(addressText).removeClass("color-gray");
                            $("#selAddressDetail").val(values[3] || "");
                        }

                        $("#selAddressWrap").click(function() {
                            window.addressPicker.init("#selAddress", {
                                uuid: elementName,
                                controlScroll: controlScroll //是否控制滚动
                            });
                        });
                        //住宅地址：打开【同户籍地址】的选择块
                        if (elementName == "address" || elementName == "houseAddr") {
                            var cardAddr = $("#spCardAddr");
                            $("#divSameCardAddr").removeClass("hide").click(function() {
                                var value = cardAddr.attr("data-value");
                                var text = cardAddr.text();
                                if (value) {
                                    $(this).find(".addr-check").addClass("checked");
                                    element.attr("data-value", value).text(text).removeClass("color-gray");
                                    //记录缓存
                                    var name = element.attr("name");
                                    apply.saveCache(null, name, value, text);
                                    worf.ui.editPage.hide();
                                } else {
                                    worf.prompt.tip("您还未选择户籍地址");
                                }
                            });
                            var temp = element.attr("data-value");
                            if (temp && element.attr("data-value") == cardAddr.attr("data-value") && !$("#userGroup").hasClass("hide")) {
                                $("#divSameCardAddr").find(".addr-check").addClass("checked");
                            }
                        }
                    }
                    if (elementName == "carSeries") {
                        window.carSeriesPicker.init({
                            scrollWrapper: !worf.device.wap ? $("#editInput") : $(document.body),
                            selectSeries: function(data) {
                                var picker = window.carSeriesPicker;
                                var brandName = picker.localData.brandId;
                                var seriesName = data.text;
                                worf.ui.editPage.hide();
                                $("#txtCarBrand").data("value", brandName);
                                $("#txtCarSeries").data("value", seriesName).removeClass("color-gray").text(brandName + " " + seriesName);
                                $("#txtCarBrand2").data("value", brandName);
                                $("#txtCarSeries2").data("value", seriesName).removeClass("color-gray").text(brandName + " " + seriesName);
                                //缓存选择的数据
                                var name = $("#txtCarBrand").attr("name");
                                apply.saveCache(null, name, brandName, brandName);
                                name = $("#txtCarSeries").attr("name");
                                apply.saveCache(null, name, seriesName, brandName + " " + seriesName);
                            }
                        });
                    } else if (elementName == "store") {
                        apply.initStore();
                    } else if (elementName == "carCardPlateNo") {
                        worf.ui.carNumPicker.init({
                            value: element.attr("data-value")
                        });
                    }
                },
                closed: function() {
                    editFlag = false;
                    //改变当前显示的头部
                    worf.nav.changeHeader(0);
                    //设置添加标题
                    worf.app.toogleTitle("提交资料", {
                        rightTitle: "流程"
                    });
                    if (elementId != "selAddress") {
                        apply.scroll.original();
                    }
                }
            });
        },
        /*打开上传资料页*/
        openMaterial: function(e) {
            var me = $(this);
            var type = me.data("type");
            var required = me.find(".form-value").eq(0).data("val").toString().indexOf("required") > -1 ? 1 : 0;
            worf.localStorage.set("apply-material-type", type);
            worf.localStorage.set("apply-material-required", required);
            worf.localStorage.set("apply-material-el-id", $(this).parent().attr("id"));
            materialUpload.data.type = type;
            materialUpload.init({
                closeCall: function() {
                    apply.scroll.original();
                    worf.nav.changeHeader(0);
                    apply.loadMaterial();
                }
            });
            apply.scroll.top();
            //worf.nav.go("/view/loan/uploadMaterial.html?type=" + type);
        },
        /*初始化门店*/
        initStore: function() {
            var selectValue = $("#txtStore").attr("data-value");
            if ($("#allStore li").length > 0) {
                if (selectValue) {
                    $("#allStore li[data-id='" + selectValue + "']").addClass("select");
                }
                return;
            }
            var data = apply.ajax.localData.store;
            if (data && data.length > 0) {
                load(data);
            } else {
                apply.ajax.storeList(function(data) {
                    apply.ajax.localData.store = data;
                    load(data);
                });
            }

            function load(data) {
                var areas = {};
                var stores = {};
                $.each(data, function(index, item) {
                    areas[item.area] = 1;
                    stores[item.area] = stores[item.area] || [];
                    stores[item.area].push({
                        id: item.companayId,
                        name: item.company.replace("分公司", ""),
                        text: item.address
                    });
                });
                var html = [];
                for (var key in areas) {
                    html.push('<div class="area-title">' + key + '</div>');
                    html.push('<ul class="area-box clearfix">');
                    $.each(stores[key] || [], function(index, item) {
                        html.push('<li data-id="' + item.id + '" data-text="' + item.text + '">' + item.name + '</li>');
                    });
                    html.push("</ul>");
                }
                var height = worf.tools.getViewHeight() - $("#header").height();
                $("#allStore").html(html.join("")).height(height);

                if (selectValue) {
                    $("#allStore li[data-id='" + selectValue + "']").addClass("select");
                }
                $("#allStore li").click(function() {
                    var el = $(this);
                    el.addClass("select").siblings().removeClass("select");
                    setTimeout(function() {
                        var value = el.data("id");
                        var text = el.text();
                        $("#txtStore").attr("data-value", value).text(text).removeClass("color-gray");
                        $("#txtBranchCompany").attr("data-value", text);
                        /*$("#txtStoreAddress").removeClass("hide").text(el.data("text"));*/

                        //缓存选择的数据
                        var name = $("#txtStore").attr("name");
                        apply.saveCache(null, name, value, text);
                        name = $("#txtBranchCompany").attr("name");
                        apply.saveCache(null, name, value, text);
                        worf.ui.editPage.hide();
                    }, 200);
                });
            }
        },
        /*提交*/
        submit: function(passCheck) {
            if (apply.isSubmited || apply.isSubmiting) {
                return;
            }

            if (passCheck !== true && !apply.check("#step8", 8)) {
                apply.isSubmiting = false;
                return;
            }
            //身份证有效期计算
            submitData.cardExpireDate = submitData.cardExpireDateShow.replace(/\-/ig, "/");
            submitData.cardExpireDate = Math.floor((new Date(submitData.cardExpireDate) - new Date()) / (1000 * 60 * 60 * 24));
            apply.isSubmiting = true;
            apply.ajax.submit(submitData, function(data) {
                isSubmited = true;
                $("#submitSuccessBox").removeClass("hide");
                $("#btnsubmitOK").one("click", function() {
                    //删除上传的资料缓存
                    apply.clearPicCache();
                    worf.localStorage.del(dataCacheKey);
                    $("#submitWrap").addClass("hide");
                    if (worf.app.isReady && app.toRoot) {
                        app.toRoot();
                    } else {
                        worf.nav.back();
                    }
                });
                apply.isSubmiting = false;
            }, function(json) {
                apply.isSubmiting = false;
            });
        },
        setTitleName: function(el) {
            el = el.find(".form-title");
            var text = el.data("title") || el.text();
            pageTitle = text.replace(/\d+\./ig, "");
            //改变当前显示的头部
            worf.nav.changeHeader(0);
            $("#pTitle").text(pageTitle);
            worf.app.toogleTitle(pageTitle, {
                rightTitle: "流程"
            });
        },
        /*控制页面滚动*/
        scroll: {
            /*打开弹出页面时禁止滚动*/
            top: function() {
                window._scrollTop = document.body.scrollTop;
                setTimeout(function() {
                    document.body.scrollTop = 0;
                    $("body").addClass("noscroll");
                }, 150);
            },
            /*关闭弹出页面时还原位置*/
            original: function() {
                $("body").removeClass("noscroll");
                document.body.scrollTop = window._scrollTop || 0;
            }
        },
        /*控制第4步的显示条目*/
        tidyStep4: function() {
            var now = new Date();
            /*获取当前步骤，第4步特殊*/
            var getStep = function(index) {
                if (index == 4) {
                    return $("#step41,#step42,#step43").filter(".active");
                }
                return $("#step" + index);
            };
            var amount = worf.tools.val("#txtLoanMoney");
            var carDate = new Date(worf.tools.text("#spCarPurchaseDateStr").replace(/\-/ig, "/"));
            var carMonth = (now.getFullYear() * 12 + now.getMonth()) - (carDate.getFullYear() * 12 + carDate.getMonth());
            var type = getStep(4).attr("id");
            //央行征信报告：
            //  ①（当前时间-购车时间）不满6个月，必填项
            //  ②申请金额≥30万，必填项
            //   否则为选填项
            var id = type.replace("step", "");
            if (amount >= 30 || carMonth < 6) {
                $("#yhzxbgGroup" + id).removeClass("hide").find(".form-value").attr("data-val", "required").text("请上传照片");
            } else {
                $("#yhzxbgGroup" + id).removeClass("hide").find(".form-value").attr("data-val", "1").text("选填");
            }
            /*个人收入*/
            // 收入证明
            //  ①若“是否有本地商品房”选择是时，此模块隐藏
            //  ②若“是否有本地商品房”选择否时，此模块为必填项
            //  当收入证明为必填项时：
            //   ①两个输入框，需做先后填写顺序校验，即必须先填写“收入证明”再输入
            // “央行征信报告”
            //   ②若在“收入证明”模块中选择填写“央行征信报告”，此处的“央行征信报告”输入框切换为已完成状态，并不需要填写
            if (type == "step43") {
                if ($("#spHasHouse").text() == "是") {
                    $("#srzmGroup").addClass("hide").find(".form-value").attr("data-val", "1");
                } else {
                    $("#srzmGroup").removeClass("hide").find(".form-value").attr("data-val", "required");
                }
            }
        },
        /*翻页*/
        slider: function(e, target, passCheck) {
            var me = target || $(e.target),
                parent = $(me).parent(),
                action = me.data("btn"),
                index = parent.data("index"),
                currentIndex = 0, //改变后的索引
                /*获取当前步骤，第4步特殊*/
                getStep = function(index) {
                    if (index == 4) {
                        return $("#step41,#step42,#step43").filter(".active");
                    }
                    return $("#step" + index);
                };
            if (action == "pre") {
                currentIndex = index - 1;
                //控制跳过共借人
                if (!showPartner && index == 7) {
                    getStep(index).addClass("hide");
                    getStep(currentIndex).addClass("hide");
                    index--;
                    currentIndex = index - 1;
                }
                getStep(index).addClass("hide");
                getStep(currentIndex).removeClass("hide");
                document.body.scrollTop = 0;
                apply.setTitleName(getStep(currentIndex));
                $("#mapDialog").find(".here").addClass("hide");
                $("#mapStep" + currentIndex).find(".here").removeClass("hide");
            } else if (action == "next") {
                //passCheck的作用：第三步异步检验是否有贷款中回调之后来到这里就不用再验证了，直接走下一步的流程
                /*if(!passCheck) {
                	//没检验通过不能点击下一页
                	if(!apply.check(parent.parent(), index)) {
                		return;
                	}
                }*/

                //检查年龄--决定共借人模块是否显示
                var age = worf.tools.val("#txtAge");
                if (!apply.checkAge({
                        age: age
                    })) {
                    return;
                }

                //控制跳过共借人
                if (!showPartner && index == 5) {
                    getStep(index).addClass("hide");
                    index++;
                }
                currentIndex = index + 1;
                currentPage = getStep(currentIndex);
                apply.setTitleName(currentPage);
                if (index == 1) {
                    var tempName = worf.tools.val("#txtCardName");
                    var tempCard = worf.tools.val("#txtCardNo");
                    apply.ajax.getAuthCode({ name: tempName, cardNo: tempCard }, function(data) {
                        var tempUrl = worf.origin + "/view/user/info-auth.html?name=" + encodeURIComponent(tempName) + "&cardNo=" + tempCard + "&sign=" + data.sign;
                        $("#imgInfoAuthCode").empty();
                        new QRCode(document.getElementById("imgInfoAuthCode"), { text: tempUrl, correctLevel: QRCode.CorrectLevel.L });
                        $("#divInfoAuth").removeClass("hide");
                    });
                } else if (index == 2) {
                    //预加载车系数据
                    $("#mapDialog .step2,#mapDialog .step3").addClass("pass");
                    if (!window.isLoadStep2) {
                        carSeriesPicker.initData();
                        window.isLoadStep2 = true;
                    }
                } else if (index == 3) {
                    apply.tidyStep4();
                } else if (index == 6) {
                    if (!window.isLoadStep6) {
                        //预加载上传插件
                        window.pluploader.init();
                        //加载图片
                        $("#step7 .carlist-demo").each(function(index, item) {
                            var me = $(this);
                            var index = me.data("index");
                            me.append("<img src='../../img/loan/car-s/" + index + ".jpg'>").on("click", function() {
                                ImagesZoom.init({
                                    imgDataUrl: '../../img/loan/car/' + index + '.jpg',
                                    opened: function() {
                                        $("#divVideoButtonWrap").hide();
                                    },
                                    closed: function() {
                                        $("#divVideoButtonWrap").show();
                                    }
                                });
                            });
                        });
                        window.isLoadStep6 = true;
                    }
                } else if (index == 7) {
                    var cacheData = JSON.parse(worf.localStorage.get(dataCacheKey) || "{}");
                    apply.loadCache(cacheData, "#step8", true);
                    if (!window.isLoadStep7) {
                        //最后一页不再跳转
                        $("#btnSubmit").off().click(apply.submit);
                        window.isLoadStep7 = true;
                    }
                } else if (index == 8) {
                    return;
                }
                getStep(index).addClass("hide");
                currentPage.removeClass("hide");
                $("#mapStep" + currentIndex).addClass("pass");
                $("#mapDialog").find(".here").addClass("hide");
                $("#mapStep" + currentIndex).find(".here").removeClass("hide");
                document.body.scrollTop = 0;
            }
        },
        /* 初始化流程图*/
        initMap: function(e) {
            $("#btnToggleMap").click(function() {
                $("#mapDialog").toggleClass("open");
                if ($("#mapDialog").hasClass("open")) {
                    worf.app.toogleTitle("当前流程", {
                        rightTitle: ""
                    });
                    apply.scroll.top();
                } else {
                    worf.app.toogleTitle($("#pTitle").text(), {
                        rightTitle: "流程"
                    });
                    apply.scroll.original();
                }
            });
            setTimeout(function() {
                $("#mapDialog").removeClass("hide")
            }, 300);
            ////跳到某页
            //$("#mapDialog .step").click(slideToPage);
            //function slideToPage() {
            //    var me = $(this);
            //    var index = me.attr("id").replace("mapStep", ""),
            //       getStep = function (index) {
            //           if (index == 4) {
            //               return $("#step41,#step42,#step43").filter(".active").removeClass("hide");
            //           }
            //           return $("#step" + index);
            //       };

            //    //还没有激活的步骤不允许跳转
            //    if (index == 7 && !showPartner && !$("#mapStep5").hasClass("pass")) {
            //        worf.prompt.tip("请先完成前一步");
            //        return;
            //    } else if (!showPartner && index == 6) {
            //        //控制跳过共借人
            //        worf.prompt.tip("您不需要填写共借人信息");
            //        return;
            //    }
            //    else if (!me.hasClass("pass")) {
            //        worf.prompt.tip("请先完成前一步");
            //        return;
            //    }
            //    if (index == 4) {
            //        apply.tidyStep4();
            //    }

            //    apply.element.pages.addClass("hide");
            //    currentPage = getStep(index);
            //    currentPage.removeClass("hide");
            //    apply.setTitleName(currentPage);
            //    $("#mapDialog").find(".here").addClass("hide");
            //    $("#mapStep" + index).find(".here").removeClass("hide");
            //    $("#mapDialog").removeClass("open");
            //    apply.scroll.original();
            //}
        },
        /*每个步骤的验证*/
        check: function(el, page) {
            /** 
             * 身份证验证 
             * 验证方法： 
             * 1、将前面的身份证号码17位数分别乘以不同的系数。从第一位到第十七位的系数分别为：7－9－10－5－8－4－2－1－6－3－7－9－10－5－8－4－2 
             * 2、将这17位数字和系数相乘的结果相加 
             * 3、用加出来和除以11，看余数是多少？ 
             * 4、余数只可能有0－1－2－3－4－5－6－7－8－9－10这11个数字。其分别对应的最后一位身份证的号码为1－0－X －9－8－7－6－5－4－3－2 
             * 5、通过上面得知如果余数是3，就会在身份证的第18位数字上出现的是9。如果对应的数字是10，身份证的最后一位号码就是罗马数字x 
             * @param idCar 
             * @return 
             */
            function idCarValidate(idCar) {
                var numArr = new Array(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2); // 系数 
                var lastArr = new Array('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2'); // 最后一位身份证的号码 
                if (idCar == null || idCar.length != 18) {
                    return true;
                }
                var sum = 0;
                var strArr = idCar.toUpperCase().split("");
                for (var i = 0; i < strArr.length - 1; i++) {
                    sum += (strArr[i] - '0') * numArr[i];
                }
                return strArr[17] == lastArr[sum % 11];
            }

            if (page == 1) {
                var loanMoney = parseFloat(worf.tools.val("#txtLoanMoney") || 0, 10);
                if ($("#txtLoanMoney").val() == "") {
                    worf.prompt.tip("请输入申请金额");
                    return false;
                } else if (loanMoney < 3 || loanMoney > 60) {
                    worf.prompt.tip("申请金额不能超出范围:3~60万");
                    return false;
                }
            }
            var data = worf.validate(el, {
                filter: ".form-value"
            });
            if (!data) {
                return false;
            }
            if (page == 1) {
                //检查身份证信息
                var number = worf.tools.val("#txtCardNo");
                //var age = (function () {
                //    var date;
                //    if (number.length == 15) {
                //        date = number.substring(6, 12);
                //        date = "19" + date;
                //    } else if (number.length == 18) {
                //        date = number.substring(6, 14);
                //    } else {
                //        return 0;
                //    }
                //    var year = parseInt(date.substring(0, 4), 10);
                //    var month = parseInt(date.substring(4, 6), 10);
                //    var now = new Date();
                //    return Math.floor(((now.getFullYear() * 12 + now.getMonth() + 1) - (year * 12 + month)) / 12);
                //})();

                //身份证有效期
                var cardExpireDate = worf.tools.text("#spCardExpireDateShow");
                cardExpireDate = cardExpireDate.replace(/\-/ig, "/");
                var leftDays = Math.ceil((new Date(cardExpireDate) - new Date()) / (1000 * 60 * 60 * 24));
                // ①年龄＜20周岁，或，年龄＞65周岁，拒绝
                // ②非大陆居民，拒绝
                // ③身份证有效期＜15天
                var temp = true;
                var age = parseInt(worf.tools.val("#txtAge"), 10);
                if (age < 20 || age > 65) {
                    worf.prompt.tip("您的年龄不在可申请范围内，无法申请");
                    return false;
                } else if (!idCarValidate(number)) {
                    worf.prompt.tip("身份证号码格式不正确");
                    return false;
                }
                /*else if (!/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/ig.test(number)) {
                  temp = false;
                }*/
                /*else if (leftDays < 15) {
                  temp = false;
                }*/
                /*if (!temp) {
                  worf.prompt.tip("您的资质无法申请该产品!");
                  return false;
                }*/
            } else if (page == 3) {
                if (carExistLoan) {
                    worf.prompt.tip(carExistLoanMessage || "此车辆有一笔未结清的贷款，无法申请!");
                    return false;
                }
            } else if (page == 7) {
                submitData = $.extend(submitData, data);
                //获取员工信息
                apply.ajax.checkExistStaff(function(data) {
                    apply.saveCache(null, "recommenderNo", data.staffNum, data.staffNum);
                    apply.saveCache(null, "store", data.deptId, data.deptName);
                    apply.saveCache(null, "branchCompany", data.deptName, data.deptName);
                    apply.ImmediateSaveCache();
                    apply.slider(null, $("#btnNext7"), true);
                }, function(json) {
                    worf.prompt.tip(json.message || "系统错误");
                });
                return false;
            } else if (page == 8) {
                var loanMoney = parseFloat(worf.tools.val("#txtLoanMoney2") || 0, 10);
                if ($("#txtLoanMoney2").val() == "") {
                    worf.prompt.tip("请输入申请金额");
                    return false;
                } else if (loanMoney < 3 || loanMoney > 60) {
                    worf.prompt.tip("申请金额不能超出范围:3~60万");
                    return false;
                }
                //检查身份证信息
                var number = worf.tools.val("#txtCardNo2");
                if (!idCarValidate(number)) {
                    worf.prompt.tip("身份证号码格式不正确");
                    return false;
                }
                if (carExistLoan) {
                    worf.prompt.tip(carExistLoanMessage || "此车辆有一笔未结清的贷款，无法申请!");
                    return false;
                }
            }
            submitData = $.extend(submitData, data);
            return true;
        },
        /*删除图片缓存*/
        clearPicCache: function() {
            for (var key in materialUpload.config) {
                worf.localStorage.del("apply-material-data-" + key);
            }
            worf.localStorage.del("apply-material-index");
        },
        /*保存缓存*/
        saveCache: function(e, name, value, text) {
            //console.log("--saveCache---");
            if (!name) {
                var me = $(this);
                name = me.attr("name");
                text = me.text();
                if (me.is("input")) {
                    value = me.val();
                } else {
                    value = me.attr("data-value") || me.data("value");
                }
                if (value !== 0 && !value) {
                    value = "";
                }
                if (!isNaN(value)) {
                    value = value + "";
                }
            }
            if (text === "") {
                text = value;
            }
            localData.push({
                name: name,
                value: value,
                text: text
            });
        },
        /*保存缓存*/
        startSaveCache: function() {
            /*定时存储缓存*/
            //转换数组为对象
            function transfer(data) {
                var obj = {};
                $.each(data, function(index, item) {
                    obj[item.name] = {
                        value: item.value,
                        text: item.text
                    };
                });
                return obj;
            }
            //定时保存
            var time = 300;
            var cacheTimer;

            function save() {
                window.clearTimeout(cacheTimer);
                var length = localData.length;
                if (length > 0) {
                    var tempData = transfer(localData.splice(0, length));
                    var cacheData = JSON.parse(worf.localStorage.get(dataCacheKey) || "{}");
                    cacheData = $.extend({}, cacheData, tempData);
                    worf.localStorage.set(dataCacheKey, JSON.stringify(cacheData));
                    //console.log("---cache-saved---");
                }
                cacheTimer = setTimeout(save, time);
            }
            cacheTimer = setTimeout(save, time);
            apply.ImmediateSaveCache = save;
        },
        /*从缓存中加载数据*/
        startLoadCache: function() {
            //车辆初次登记时间=初审的首次上牌时间
            var firstRegDate = worf.localStorage.get("loan-firstTrial-date");
            $("#spCar1stRegDateStr").attr("data-value", firstRegDate).text(firstRegDate).removeClass("color-gray");

            //读取缓存数据
            var loadCache = function(data, selector, isStep8) {
                //删除上传的资料缓存
                apply.clearPicCache();
                $((selector || "") + " .form-value").each(function(index, item) {
                    var me = $(item);
                    var name = me.attr("name");
                    var itemData = data[name];
                    //确认信息也可以从原始信息处获取（fix缓存不准的导致加载不出数据）
                    if (isStep8 && (!itemData || !itemData.value)) {
                        //var submitValue=submitData[name]||"";
                        var itemId = "#txt" + (name.replace(/(\w)/, function(v) {
                            return v.toUpperCase()
                        }));
                        var itemElement = $(itemId);
                        itemData = {
                            value: itemElement.attr("data-value") || itemElement.val(),
                            text: itemElement.text()
                        };
                    }
                    if (itemData && itemData.value !== "") {
                        var value = itemData.value;
                        var text = itemData.text || "";
                        if (value == undefined || value == null) {
                            value = "";
                        }
                        if (text == undefined || text == null || text === "") {
                            text = me.data("default") || "";
                        }
                        if (me.is("input")) {
                            me.val(value);
                        } else {
                            me.data("value", value).text(text);
                            if (value !== "") {
                                me.removeClass("color-gray");
                            }
                        }
                    }
                });
                //借款用途-其他-填写的内容
                if (data.loanPurposes) {
                    $("#spLoanPurposesType").attr("data-extra", data.loanPurposes.value || "");
                }
                //“本人是否有本地商品房”若选择“是”时 打开房产资料
                if (data.hasHouse && data.hasHouse.value == 0) {
                    $("#fczlGroup").removeClass("hide").find(".form-value").attr("data-val", "required");
                    $("#divHouseStatus").addClass("bb-gray");
                    $("#houseAddrGroup,#houseStatusGroup").removeClass("hide");
                }
                //验证车牌号码
                if (data.carCardPlateNo) {
                    apply.ajax.checkExistLoan(data.carCardPlateNo.value);
                }

                //职业身份
                if (data.job) {
                    apply.changeJob(data.job.value || 0);
                }
            };
            apply.loadCache = loadCache;
            var cacheData = JSON.parse(worf.localStorage.get(dataCacheKey) || "{}");
            if (cacheData && !$.isEmptyObject(cacheData)) {
                loadCache(cacheData);
            }
            //开始记录缓存
            apply.startSaveCache();
        },
        /*从缓存中读取上传的资料*/
        loadMaterial: function() {
            var type = materialUpload.data.type;
            var element = $("#" + (worf.localStorage.get("apply-material-el-id") || "")).find(".form-value");
            var data = materialUpload.data.imgCache[type];
            if (type == "yhzxbg") {
                //同时更改3个征信报告
                element = $("#yhzxbgGroup41 .form-value,#yhzxbgGroup42 .form-value,#yhzxbgGroup43 .form-value");
            }
            if (data && data.images && data.images.length > 0) {
                element.attr("data-value", 1).text("已上传").removeClass("color-gray");
                //“收入证明”选择了类型为“征信报告”时申请页的征信报告不用填写，自动改为已上传状态
                if (type == "srzm" && data.subtype == 2) {
                    $("#yhzxbgGroup43 .form-value").attr("data-value", 1).text("已上传");
                    $("#yhzxbgGroup43 .form-control").off();
                } else {
                    $("#yhzxbgGroup43 .form-control").off().click(apply.openMaterial);
                }
            } else if (element) {
                element.each(function(index, item) {
                    item = $(item);
                    var text = item.attr("data-val").indexOf("required") > -1 ? "请上传照片" : "选填";
                    item.attr("data-value", "").text(text).addClass("color-gray");
                });
            }
        },
        /*
         * ios单选返回
         * imgUrlArr:图片路劲数组
         * elementId：点击file的id，
         * type：用于标识处理图片的类型，以判断获取base64后怎么处理后续操作
         */
        singlePickCallback: function(imgUrlArr, elementId, type) {
            //TODO ios单选返回
            if (type == "OCR") {
                worf.prompt.tip("<p>正在解析照片中的数据</p><p>请稍等…</p>", {
                    time: 60 * 1000
                });
            } else if (type = "carlistFile") {
                worf.prompt.tip("<p>上传中,请稍候… </p>", {
                    time: 60 * 1000
                });
            }
            imgUrlArr = imgUrlArr || [];
            var imgCount = imgUrlArr.length;
            if (imgCount > 0) {
                for (var i = 0; i < imgCount; i++) {
                    var img = new Image();
                    img.onload = function() {
                        apply.compress(this, elementId, type);
                    };
                    img.src = imgUrlArr[i];
                }
            } else {
                return;
            }
        },
        compress: function(img, fileId, actionType) {
            //用于压缩图片的canvas
            var canvas = document.createElement("canvas");
            var ctx = canvas.getContext('2d');
            //瓦片canvas
            var tCanvas = document.createElement("canvas");
            var tctx = tCanvas.getContext("2d");

            var initSize = 0;
            var width = img.width;
            var height = img.height;

            //如果图片大于四百万像素，计算压缩比并将大小压至400万以下
            var ratio;
            if ((ratio = width * height / 4000000) > 1) {
                ratio = Math.sqrt(ratio);
                width /= ratio;
                height /= ratio;
            } else {
                ratio = 1;
            }
            canvas.width = width;
            canvas.height = height;

            //铺底色
            ctx.fillStyle = "#fff";
            ctx.fillRect(0, 0, canvas.width, canvas.height);

            //如果图片像素大于100万则使用瓦片绘制
            var count;
            if ((count = width * height / 1000000) > 1) {
                count = ~~(Math.sqrt(count) + 1); //计算要分成多少块瓦片
                //计算每块瓦片的宽和高
                var nw = ~~(width / count);
                var nh = ~~(height / count);

                tCanvas.width = nw;
                tCanvas.height = nh;

                for (var i = 0; i < count; i++) {
                    for (var j = 0; j < count; j++) {
                        tctx.drawImage(img, i * nw * ratio, j * nh * ratio, nw * ratio, nh * ratio, 0, 0, nw, nh);

                        ctx.drawImage(tCanvas, i * nw, j * nh, nw, nh);
                    }
                }
            } else {
                ctx.drawImage(img, 0, 0, width, height);
            }

            //进行压缩
            var quality = 1;
            if (width * height > 3000000) { //图片大于3M，压缩质量改为0.7
                quality = 0.7;
            } else if (width * height > 5120000) { //图片大于5M，压缩质量改为0.5
                quality = 0.5;
            }

            if (actionType == "OCR") {
                apply.iosOCR(canvas.toDataURL('image/jpeg', quality), canvas.toDataURL('image/jpeg', 0.1), fileId);
            } else if (actionType == "carlistFile") {
                apply.iosCarlistFile(canvas.toDataURL('image/jpeg', quality), canvas.toDataURL('image/jpeg', 0.1), fileId);
            }
            tCanvas = null;
            canvas = null;
            img = null;
        },
        /*绑定事件*/
        bindEvent: function() {
            var that = this,
                top = $("#nav").height() + $("#header").height() + _FONT_SIZE * 0.15;
            $("[data-box]").click(that.slideUpBox);
            $("[data-box-scroll]").click(that.slideUpScrollBox);
            $("[data-edit]").click(that.openEidt);
            $("div[data-mode='material']").click(that.openMaterial);
            $("[data-sel-date]").click(that.datePick);
            $("#btnSubmit").click(that.submit);

            /*$('#selFile1,#selFile2,#selFile3').on('change', that.initOCR).on("click", function(event) {
            	event.stopPropagation();
            });
            $("#step7 .carlist-file").on('change', that.initUpload);*/

            if (worf.device.ios) {
                singleImagePickCallback = that.singlePickCallback;
                $('#selFile1,#selFile2,#selFile3').on('click', function(event) {
                    var p = {
                        "elementId": $(this).attr("id"),
                        "type": "OCR"
                    };
                    window.app && app.singleImagePick(JSON.stringify(p));
                    event.preventDefault();
                    event.stopPropagation();
                });
            } else {
                $('#selFile1,#selFile2,#selFile3').on('change', that.initOCR).on("click", function(event) {
                    event.stopPropagation();
                });
            }

            if (worf.device.ios) {
                singleImagePickCallback = that.singlePickCallback;
                $("#step7 .carlist-file").on('click', function(event) {
                    var p = {
                        "elementId": $(this).attr("id"),
                        "type": "carlistFile"
                    };
                    window.app && app.singleImagePick(JSON.stringify(p));
                    event.preventDefault();
                    event.stopPropagation();
                });
            } else {
                $("#step7 .carlist-file").on('change', that.initUpload);
            }

            $("#step7 .carlist-sel").click(that.carPicChoose);
            $(".page").css("min-height", worf.tools.getViewHeight() - top).click(that.slider);
            $("input[type='number'],input[type='tel'],input[type='text']").on((worf.device.wap ? "keyup change" : "input change"), apply.saveCache);
            $("#divShootNote").click(function() {
                apply.scroll.top();
                $("#shootNotePage").addClass("shoot-note-open");
                worf.app.changeTitle("拍摄要求", {
                    rightTitle: ""
                });
            });
            $("#btnViewDemo").click(function() {
                worf.nav.go("/view/loan/applyVideoDemo.html");
                //apply.scroll.top();
                //$("#videoDemoPage").addClass("video-demo-open");
                //worf.app.changeTitle("视频示例", { rightTitle: "" });

                //document.documentElement.requestFullScreen();
                //document.documentElement.webkitRequestFullscreen();
                //screen.orientation.lock("portrait-primary");
            });
        },
        goback: function() {
            var that = this;
            //提交中
            if (apply.isSubmiting) {
                worf.prompt.tip("数据提交中,请稍候...");
                return;
            }

            //关闭查看大图
            if ($("#imgZoomWrapper").height() > 0) {
                ImagesZoom.close();
                worf.app.toogleTitle($("#pTitle").text(), {
                    rightTitle: "流程"
                });
                return;
            }

            //关闭弹出框
            var dialogShow = false;
            ["#scrollBoxWrapper", "#datePickerWrapper", "#bbBox"].forEach(function(item) {
                var element = $(item);
                if (element.length > 0 && !element.hasClass("hide")) {
                    element.addClass("hide");
                    dialogShow = true;
                }
            });
            if (dialogShow) {
                return;
            }

            //关闭拍摄要求
            if ($("#shootNotePage").hasClass("shoot-note-open")) {
                apply.scroll.original();
                $("#shootNotePage").removeClass("shoot-note-open");
                worf.app.restoreTitle();
                return;
            }
            //关闭视频demo
            if ($("#videoDemoPage").hasClass("video-demo-open")) {
                apply.scroll.original();
                $("#videoDemoPage").removeClass("video-demo-open");
                worf.app.restoreTitle();
                return;
            }
            //关闭流程图
            if ($("#mapDialog").hasClass("open")) {
                apply.scroll.original();
                $("#mapDialog").removeClass("open");
                worf.app.toogleTitle($("#pTitle").text(), {
                    rightTitle: "流程"
                });
                return;
            }
            //已提交成功不让返回
            if (isSubmited) {
                return;
            }
            //缓存没保存就提示
            var cache = worf.localStorage.get(dataCacheKey);
            if (cache) {
                worf.prompt.confirm("您填写的资料还未提交,是否放弃？", function() {
                    worf.localStorage.del(dataCacheKey);
                    apply.clearPicCache();
                    worf.ajax({
                        url: worf.API_URL + "/v1/borrowerAudit/cancelEdit.json",
                        errorTip: function(json) {
                            worf.prompt.tip(json.message);
                        },
                        success: function(json) {
                            if (json.status == 1) {
                                worf.nav.back();
                            } else {
                                worf.prompt.tip(json.message);
                            }
                        }
                    });
                }, null, {
                    okText: "放弃"
                });
            } else {
                //删除上传的资料缓存
                apply.clearPicCache();
                worf.nav.back();
            }
        },
        init: function() {
            var that = this;
            that.bindEvent();
            that.initMap();
            that.getDefined();
            that.startLoadCache();
            addressPicker.preloadData();

            //初始化刚进页面的时间戳
            apply.ajax.getInitTimestamp(function(timestamp) {
                pageInitTimestamp = timestamp;
            });
        }
    };
    window.apply = apply;
})(Zepto);