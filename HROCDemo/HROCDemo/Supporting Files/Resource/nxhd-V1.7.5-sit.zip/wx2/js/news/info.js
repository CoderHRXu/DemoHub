$(function() {
    init();
});

(function() {
    var newsId = worf.tools.queryString("id") || 0;
    var shareUserId = worf.tools.queryString("ref") || 0;
    //用户子类型,0-未知 1-纳鑫达人 2-纳鑫战士 3-客户经理 4-团队经理
    var subUserTypeLabels = {
        "0": "纳鑫战士",
        "1": "纳鑫达人",
        "2": "纳鑫战士",
        "3": "客户经理",
        "4": "团队经理"
    };
    var defaultIcon = "../../img/user/default-photo.png";

    //资讯数据
    var newsDetailData = {};

    var ajax = {
        /*读取详情*/
        getNewsDetail: function(data, callback) {
            worf.ajax({
                data: data,
                animate: true,
                url: worf.API_URL + "/news/v1/newsDetails.json",
                success: function(json) {
                    if (json.status == 1) {
                        newsDetailData = json.data || { newsDetails: {}, businessCard: {} };
                        newsDetailData.businessCard = newsDetailData.businessCard || {};
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*点赞 */
        praise: function(data, callback) {
            if (worf.tools.requestLimit()) return;
            worf.ajax({
                animate: true,
                data: data,
                url: worf.API_URL + "/news/v1/shareThumbsUp.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*获取点赞数据*/
        getPraises: function(data, callback) {
            worf.ajax({
                data: data,
                animate: true,
                url: worf.API_URL + "/news/v1/praiseDetails.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
    };

    var detail = {
        renderNews: function(data) {
            data.identity = subUserTypeLabels[data.subUserType];
            for (var key in data) {
                $("#f-news-" + key).html(data[key]);
            }
        },
        /**
         *  获取资讯详情
         */
        getNewsDetail: function() {
            var self = this;
            ajax.getNewsDetail({ newsId: newsId, recommendId: shareUserId }, function(news) {
                var data = news.newsDetails;
                data.content = $("<div>" + data.content + "</div>").text();
                self.renderNews(data);
                //分享用的icon
                $("#imgShare").attr("src", data.smallPic || "");
                //分享标题
                document.title = data.title;
                // 渲染名片
                detail.renderCard(news.businessCard);
            });
        },
        /**
         *  点赞数据
         */
        getPraises: function() {
            var self = this;
            ajax.getPraises({ newsId: newsId }, function(data) {
                $("#f-news-praise").text(200 + parseInt(data.totalPraise || 0));
            });
        },
        /* 渲染名片 */
        renderCard: function(data) {
            if (!data) {
                return;
            }
            data.identity = subUserTypeLabels[data.subUserType];
            data.identity2 = subUserTypeLabels[data.subUserType];
            data.advantage = data.advantage || "专业车贷，门槛低、额度高、放款快，上门录单，欢迎垂询！";
            data.cardName2 = data.cardName;
            for (var key in data) {
                $("#f-card-" + key).html(data[key]);
            }
            $("#f-card-icon,#f-card-icon2").css({ "background-image": "url('" + (data.icon || '') + "')" });

            if (data.wechat) {
                $("#divWeixin").removeClass("hide");
            }
            if (data && data.userType == 2) {
                $("#staticCard").removeClass("hide");
            }
        },
        /**
         * 读取资讯数据
         */
        getDetail: function() {
            var self = this;
            detail.getNewsDetail();
        },
        /*点赞 */
        praise: function() {
            /* if ($("#btnPraise .icon-praise").hasClass("icon-praised")) {
                 worf.prompt.tip("已赞");
                 return;
             }*/
            ajax.praise({ newsId: newsId }, function() {
                var $txtPraise = $("#f-news-praise");
                $txtPraise.text(parseInt($txtPraise.text()) + 1);
                $("#btnPraise .icon-praise").addClass("icon-praised");
            });
        },
        event: {
            showCard: function() {
                $("#secCard").removeClass("hide");
            },
            showPhone: function() {
                var phone = worf.tools.phoneEncrypt(newsDetailData.businessCard.phone);
                worf.prompt.confirm("提示", function() {
                    setTimeout(function() {
                        worf.prompt.closeMe();
                    }, 1500);
                }, null, { okText: "拨打", message: "拨打 <span class='color-active'>" + phone + "</span> 吗?" });
                //改造弹出框
                $("#promptConfirmBox").find("#btnPromptOK").addClass("tel").append("<a href='tel:" + newsDetailData.businessCard.phone + "'>" + phone + "</a>");
            },
            bind: function() {
                var that = this;
                //点赞
                $("#btnPraise").click(function() {
                    detail.praise();
                });
                //关闭名片
                $("#secCard").find(".icon-error").off().click(function() {
                    $("#secCard").addClass("hide");
                });
                //我要贷款跳转
                $("#btnLoan").click(function() {
                    var url;
                    var userId = newsDetailData.businessCard.userId || "";
                    url = "http://172.16.88.167:8445/handleBusiness/carAssess.html?ref=" + userId;
                    window.location.href = url;
                });
                //名片区域动作
                $("#staticCard [data-action]").click(function() {
                    var action = $(this).data("action");
                    switch (action) {
                        case "weixin":
                        case "card":
                            that.showCard();
                            break;
                        case "phone":
                            that.showPhone();
                            break;
                    }
                });
            }
        }
    };

    /**
     * 初始化
     */
    window.init = function() {
        detail.getDetail();
        detail.getPraises();
        detail.event.bind();
    };
})();