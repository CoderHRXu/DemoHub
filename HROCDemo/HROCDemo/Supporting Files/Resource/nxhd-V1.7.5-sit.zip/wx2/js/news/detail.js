$(function() {
    init();
});

(function() {
    var newsId = worf.tools.queryString("id") || 0;
    var defaultIcon = "../../img/user/default-photo.png";
    var userSubType = 0; //用户子类型,0-未知 1-纳鑫达人 2-纳鑫战士 3-客户经理 4-团队经理
    var isReal = false; //是否实名

    //资讯数据
    var newsDetailData = {};

    //评论数据
    var commentsData = {
        scrollLock: false, //是否可以滚动
        page: 1, //页码
        size: 10, //页尺寸
        total: 0, //总数
        last: false, //已加载到最后一页
        list: [], //数据集合
        isLast: function() {
            return this.total == 0 || (this.total > 0 && (this.size * this.page > this.total))
        }
    };

    /*控制页面滚动*/
    var scroll = {
        //记录
        mark: function(lock) {
            window._scrollTop = document.body.scrollTop + 20;
            lock && $("body").addClass("noscroll");
        },
        //恢复
        recover: function(unlock) {
            document.body.scrollTop = window._scrollTop || 0;
            unlock && $("body").removeClass("noscroll");
        }
    };

    var ajax = {
        /*查询用户状态*/
        getUserStatus: function(callback) {
            worf.ajax({
                data: { key: new Date().getTime() },
                url: worf.API_URL + "/v1/user/getUserStatus.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*读取详情*/
        getNewsDetail: function(data, callback) {
            worf.ajax({
                data: data,
                animate: true,
                url: worf.API_URL + "/news/v1/newsDetails.json",
                success: function(json) {
                    if (json.status == 1) {
                        newsDetailData = json.data || { newsDetails: {}, businessCard: {} };
                        newsDetailData.businessCard = newsDetailData.businessCard || {};
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*获取点赞数据*/
        getPraises: function(data, callback) {
            worf.ajax({
                data: data,
                animate: true,
                url: worf.API_URL + "/news/v1/praiseDetails.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*获取评论数据*/
        getComments: function(data, callback, error) {
            worf.ajax({
                data: data,
                animate: true,
                url: worf.API_URL + "/news/v1/commentDetails.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                },
                error: function() {
                    error && error();
                }
            });
        },
        /*点赞 */
        praise: function(data, callback) {
            if (worf.tools.requestLimit()) return;
            worf.ajax({
                animate: true,
                data: data,
                url: worf.API_URL + "/news/v1/thumbsUp.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*评论 */
        comment: function(data, callback) {
            if (worf.tools.requestLimit()) return;
            worf.ajax({
                animate: true,
                data: data,
                url: worf.API_URL + "/news/v1/comment.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*保存微信号*/
        saveWechat: function(data, callback) {
            if (worf.tools.requestLimit()) return;
            worf.ajax({
                animate: true,
                data: data,
                url: worf.API_URL + "/v1/user/saveWechat.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        }
    };

    var share = {
        /*调用原生分享 */
        do: function() {
            var userId = newsDetailData.businessCard.userId || "";
            var url = worf.origin + "/view/news/info.html?id=" + newsId + "&ref=" + userId;
            console.log("share ing..." + url);

            window.app && app.goNewsShare && app.goNewsShare(JSON.stringify({
                title: newsDetailData.newsDetails.title,
                conent: (newsDetailData.newsDetails.content || "").replace(/<(?:.|\s)*?>/g, "").substr(0, 54),
                icon: newsDetailData.newsDetails.smallPic || worf.origin + "/img/shareIcon.png",
                link: url,
                newsId: newsId
            }));
        },
        //弹出微信号输入
        showWeixinNo: function() {
            var that = this;
            $("#webChatShareBox").removeClass("hide");
            $("#btnShareWechat").off("click").click(function() {
                that.saveWechat();
            });
            $("#webChatShareBox .icon-error").off("click").click(function() {
                $("#webChatShareBox").addClass("hide");
            });
        },
        hideWeixinNo: function() {
            setTimeout(function() {
                $("#webChatShareBox").addClass("hide");
            }, 500);
        },
        saveWechat: function() {
            var that = this;
            var wecat = worf.tools.val("#wechat");
            if (wecat) {
                if (!/^[a-zA-Z][0-9a-zA-Z\-_]{5,19}$/.test(wecat)) {
                    worf.prompt.tip("微信号格式不正确");
                    return false;
                }
                ajax.saveWechat({ key: wecat }, function() {
                    newsDetailData.businessCard.wechat = wecat;
                    that.do();
                    that.hideWeixinNo();
                });
            } else {
                that.do();
                that.hideWeixinNo();
            }
        },
        //弹出去登录
        showLogin: function() {
            var that = this;

            $("#loginShareBox").removeClass("hide");
            $("#btnLogin").off().click(function() {
                worf.user.goLogin();
                setTimeout(function() {
                    $("#loginShareBox").addClass("hide");
                }, 500);
            });
            $("#btnShareLogin").off("click").click(function() {
                that.do();
            });
            $("#loginShareBox .icon-error").off("click").click(function() {
                $("#loginShareBox").addClass("hide");
            });
        },
        show: function() {
            //非业务员就直接分享
            //用户子类型,0-未知 1-纳鑫达人 2-纳鑫战士 3-客户经理 4-团队经理
            if (userSubType < 2) {
                this.do();
                return;
            }

            //业务员先登录后分享 方便携带名片。
            if (userSubType > 1 && !worf.user.isLogin()) {
                this.showLogin();
            } else if (!newsDetailData.businessCard.wechat) {
                this.showWeixinNo();
            } else {
                this.do();
            }
        },
    };

    var detail = {
        renderField: function(data) {
            for (var key in data) {
                $("#f-news-" + key).html(data[key]);
            }
        },
        renderList: function(wrap, template, data) {
            var html = [];
            $(data).each(function(index, item) {
                html.push(worf.tools.tmpEngine(template, item));
            });
            $(wrap).html(html.join(""));
        },
        /**
         *  获取用户状态
         */
        getUserStatus: function() {
            if (!worf.user.isLogin()) {
                return;
            }
            ajax.getUserStatus(function(data) {
                userSubType = data.userSubType;
                isReal = (data.cardState == 1);
            });
        },
        /**
         *  获取资讯详情
         */
        getNewsDetail: function() {
            var self = this;
            ajax.getNewsDetail({ newsId: newsId }, function(news) {
                var data = (news || {}).newsDetails || {};
                if (data.content) {
                    data.content = $("<div>" + data.content + "</div>").text();
                    self.renderField(data);
                    self.allowComment = (data.allowComment == 1);
                    //开关点赞按钮
                    var cssClass = data.thumbsUp ? "praize praized" : "praize";
                    $("#btnPraise").removeClass("praized").addClass(cssClass);
                }
            });
        },

        /**
         *  点赞列表
         */
        getPraises: function() {
            var self = this;
            ajax.getPraises({ newsId: newsId }, function(data) {
                data.totalPraiseStr = "（" + data.totalPraise + "）";
                self.renderField(data);
                data.iconList.forEach(function(item, index) {
                    data.iconList[index] = item || defaultIcon;
                });
                self.renderList("#praiseWrap", "<li><span style='background-image:url(<%this%>)'></span></li>", data.iconList || []);
            });
        },

        /**
         *  评论列表
         */
        getComments: function(pageIndex) {
            var self = this;
            pageIndex = pageIndex || 1;
            commentsData.page = pageIndex;

            ajax.getComments({ newsId: newsId, pageNo: pageIndex, pageSize: commentsData.size }, function(data) {
                data = data || { totalComment: 0, commentList: [] };
                data.totalCommentStr = "（" + data.totalComment + "）";
                commentsData.total = data.totalComment;
                data.commentList.forEach(function(item, index) {
                    data.commentList[index].icon = item.icon || defaultIcon;
                    data.commentList[index].pageIndex = pageIndex;
                    if (item.anonymous == 1) {
                        data.commentList[index].icon = defaultIcon;
                        data.commentList[index].userName = "匿名用户";
                    }
                });
                if (pageIndex > 1) {
                    commentsData.list = commentsData.list.concat(data.commentList || []);
                } else {
                    commentsData.list = data.commentList || [];
                }

                self.renderField(data);
                self.renderList("#commentWrap", $("#tpl-comment").html(), commentsData.list);
                scroll.recover();

                //绑定赞事件
                $("#commentWrap .count").click(function() {
                    var $this = $(this);
                    if ($this.find("i").hasClass("icon-praised")) {
                        worf.prompt.tip("您已赞");
                        return;
                    }
                    self.event.praiseComment($this.data("id"));
                });
                //解锁活动
                commentsData.scrollLock = false;
                $("#divCommentLoading").addClass("hide");
            }, function() {
                //退回pageIndex
                if (commentsData.list.length > 0) {
                    commentsData.page = commentsData.list[commentsData.list.length - 1].pageIndex + 1;
                } else {
                    commentsData.page = 1;
                }
                //解锁活动
                commentsData.scrollLock = false;
                $("#divCommentLoading").addClass("hide");
            });
        },

        /**
         * 读取资讯数据
         */
        getDetail: function() {
            var self = this;
            self.getNewsDetail();
            setTimeout(function() { self.getPraises(); }, 100);
            setTimeout(function() { self.getComments(); }, 200);
            setTimeout(function() {
                self.getUserStatus();
            }, 300);
        },

        event: {
            /**
             * 赞资讯
             */
            praiseNews: function() {
                if (!worf.user.isLogin()) {
                    worf.user.goLogin();
                    return;
                }
                var self = this;
                if ($(self).hasClass("praized")) {
                    worf.prompt.tip("您已赞");
                    return;
                }
                ajax.praise({ newsId: newsId }, function(data) {
                    $(self).addClass("praized");
                    detail.getPraises();
                })
            },
            /**
             * 赞评论
             */
            praiseComment: function(id) {
                if (!worf.user.isLogin()) {
                    worf.user.goLogin();
                    return;
                }
                ajax.praise({ newsId: newsId, commentId: id }, function(data) {
                    detail.getComments();
                })
            },
            /**
             * 评论
             */
            comment: function() {
                var param = {
                    newsId: newsId,
                    anonymous: $("#ckAnonymous").hasClass("checked") ? 1 : 2, //是否匿名评论 1：是 2：否
                    content: $("#txtComment").val()
                };
                if (!param.content || param.content.length < 3) {
                    worf.prompt.tip("最少发表3个字，多少说些什么吧~");
                    return;
                }

                ajax.comment(param, function(data) {
                    worf.prompt.tip("评论成功", null, function() {
                        $("#txtComment").val("");
                        $("#asideComment").removeClass("expand").css("position", null);
                        detail.getComments();
                    });
                })
            },
            /* 上拉加载下一页评论 */
            nextCommentPage: function() {
                if (commentsData.scrollLock) {
                    return;
                }
                var wrap = worf.device.wap ? document.body : "#mainWrap";
                var topFixed = worf.device.wap ? 0.44 : 0;
                if (!commentsData.scrollLock && $(wrap).scrollTop() + (topFixed + 0.43) * _FONT_SIZE > $(wrap)[0].scrollHeight - screen.availHeight) {
                    scroll.mark();
                    //已经到底了
                    if (commentsData.isLast()) {
                        $("#divCommentLoading").text("已经到底啦...").removeClass("hide");
                        setTimeout(function() {
                            $("#divCommentLoading").text("").addClass("hide");
                        }, 500);
                        commentsData.scrollLock = false;
                        return;
                    } else {
                        $("#divCommentLoading").text("拼命加载中...").removeClass("hide");
                    }

                    commentsData.page++;
                    commentsData.scrollLock = true;
                    detail.getComments(commentsData.page);
                }
            },
            /*弹起评论框*/
            showTextArea: function(event) {
                if (!detail.allowComment) {
                    event.stopPropagation();
                    worf.prompt.tip("该文章未开启评论功能…");
                    return;
                }

                if (!worf.user.isLogin()) {
                    event.stopPropagation();
                    worf.user.goLogin();
                    return;
                }

                if (!isReal) {
                    event.stopPropagation();
                    worf.prompt.alert("您只能点赞，实名认证后才能发表评论", function() {
                        worf.prompt.closeMe();
                        window.app && window.app.goRealNameCert && window.app.goRealNameCert();
                    }, { okText: "去认证" });
                    return;
                }

                setTimeout(function() {
                    var aside = $("#asideComment");
                    var top = $(window).height() + document.body.scrollTop - (1.655 * _FONT_SIZE);
                    //aside.css("top", top + "px");
                    aside.css("position", "absolute");
                    if (!aside.hasClass("expand")) {
                        aside.addClass("expand");
                    }
                }, 500);

                scroll.mark(true);
            },
            closeTextArea: function() {
                scroll.recover(true);
                $("#asideComment").removeClass("expand").css("position", "fixed").find("textarea").val("");
            },
            /*节流函数 */
            throttle: function(fn, delay, mustRunDelay) {
                var timer = null;
                var t_start;
                return function() {
                    var context = this,
                        args = arguments,
                        t_curr = +new Date();
                    clearTimeout(timer);
                    if (!t_start) {
                        t_start = t_curr;
                    }
                    if (t_curr - t_start >= mustRunDelay) {
                        fn.apply(context, args);
                        t_start = t_curr;
                    } else {
                        timer = setTimeout(function() {
                            fn.apply(context, args);
                        }, delay);
                    }
                }
            },
            bind: function() {
                $("#btnPraise").click(detail.event.praiseNews);
                $("#ckAnonymous").click(function() {
                    $(this).toggleClass("checked");
                });
                $("#btnComment").click(detail.event.comment);
                $("#txtComment").on("touchstart", detail.event.showTextArea).on("blur", function() {
                    //detail.event.closeTextArea();
                    console.log("blur");
                }).on("input keyup", function() {
                    var $this = $(this),
                        $btn = $("#btnComment");
                    if (worf.tools.val($this)) {
                        $btn.addClass("active");
                    } else {
                        $btn.removeClass("active");
                    }
                });

                $("#mainWrap").on("touchstart", function() {
                    if ($("#asideComment").hasClass("expand")) {
                        detail.event.closeTextArea();
                    }
                }).on("touchmove", detail.event.throttle(detail.event.nextCommentPage, 300, 500))

                //返回到资讯列表
                $("#btnGoList").click(function() {
                    window.app && window.app.goNewsList && window.app.goNewsList();
                });

                //分享
                $("#btnShare").click(function() {
                    share.show();
                });
            }
        }
    };

    /**
     * 刷新数据（app回退到此页）
     */
    window.loadData = function() {
        detail.getUserStatus();
        detail.getUserInfo();
        detail.getNewsDetail();
    }

    /**
     * 初始化
     */
    window.init = function() {
        //设置添加标题
        worf.app.toogleTitle("资讯详情", { rightIcon: "list" });
        detail.getDetail();
        detail.event.bind();
        window.goback = function() {
            worf.nav.back();
        }
    };
})();