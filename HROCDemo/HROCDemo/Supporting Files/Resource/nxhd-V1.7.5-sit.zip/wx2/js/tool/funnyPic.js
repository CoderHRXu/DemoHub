//禁止ajax自动跳转登录
window.forbidAutoLogin = true;
/*
* 获取趣图系列
**/
function getSeriesList() {
    worf.ajax({
        url: worf.API_URL + "/v1/qutu/getSeries.json",
        success: function (json) {
            if (json.status == 1) {
                var $htmls = "";
                var data = json.data;
                for (var i = 0; i < data.length; i++) {
                    var item = data[i];
                    $htmls += '<li onclick="seriesClickCount(' + item.id + ');" data-action="108" data-actionArgs="{\'模板名称\':\'' + item.seriesName + '\'}">'
                     + '<div class="sp_mx_left"><span class="sp_mx"><img src=' + item.url + ' width="100%"  height="100%"  /></span></div>'
                     + '<div class="sp_mx_right">'
                     + '<p>' + item.seriesName + '</p><span class="pull-right"><em class="icon icon-next"></em></span><i class="' + (item.isnew ? "isShow" : "isHide") + '">new</i>'
                     + '</div>'
                     + '</li>';
                }
                $("#m_types").html($htmls);
            } else {
                worf.prompt.tip(json.message);
            }
        }
    });
};

/**
 * 获取系列下的模板
 */
function getTemplateList(seriesId) {
    worf.ajax({
        url: worf.API_URL+"/v1/qutu/getModels.json",
        data: {
            seriesId: seriesId,
            page:1
        },
        success: function (json) {
            if (json.status == 1) {
                var data = json.data;
                var i = 0;
                function setTimeImg() {
                    if (i < data.length)
                    setTimeout(function () { 
                        var cssClass = (i % 2) ? "m_tmpright" : "m_tmpleft";
                        var config =encodeURIComponent(JSON.stringify(data[i].paramConfig));
                        var htmls = ' <div class="' + cssClass + '"><img  data-action="110" data-actionArgs="{\'模板\':\'' + data[i].modelName + '\'}" onclick="worf.nav.go(\'/view/tool/funnyPicMake.html?tid=' + data[i].id+'&config='+ config+ '\');" src="' + data[i].smallUrl + '" alt="" width="100%"></div>';
                        $("#m_temlplate").append(htmls);
                        i++;
                        setTimeImg();
                    }, 200);
                };
                setTimeImg();
                setTimeout('$("#m_temlplate img").addClass("m_tmpImgborder");', 500);
            } else {
                worf.prompt.tip(json.message);
            }
        }
    });
};
/*
* 制作生成趣图
**/
function make(orgs) {
    if (window.isMaked) return false;
    window.isMaked = true;
    ////用户行为记录
    //worf.monitor.action("112", "/view/tool/funnyPicMake.html", { "姓名": orgs.name, "手机号码": orgs.phone, "业务介绍":orgs.desc||"" });
    //worf.monitor && worf.monitor.lastSend();

    worf.ajax({
        url: worf.API_URL+"/v1/qutu/makeQutu.json",
        data:orgs,
        success: function (json) {
            window.isMaked = false;
            if (json.status == 1) {
                var data = json.data;
                var html = '<h5 class="titles">长按图片保存</h5><div class="wximg"><img id="picResult" src="' + data.url + '" data-ids="' + data.id + '" /></div>';
                $("#m_wxcenter").html(html);
                window.bindLongTouch("#picResult", data.id);
                //initShare(orgs.id, data.url);//分享
            } else {
                worf.prompt.fail("制作失败", null, { message: json.message });
            }
        }
    });
};

/*
* 点击趣图系列计数
**/
function seriesClickCount(seriesId) {
    if (window.isClickCounted) return false;
    window.isClickCounted = true;
    worf.ajax({
        url: worf.API_URL+"/v1/qutu/seriesClick.json",
        data: {
            id: seriesId
        },
        success: function (json) {
            window.isClickCounted = false;
            if (json.status == 1) {
                worf.nav.go('/view/tool/funnyPicList.html?tid=' + seriesId + '');
            } else {
                worf.prompt.tip(json.message);
            }
        }
    });
};

/*
* 趣图保存系列计数
**/
function saveRecord(finishId,imgPath) {
    //worf.monitor.action("113", "/view/tool/funnyPicMake.html");
    //worf.monitor && worf.monitor.lastSend();
    worf.ajax({
        url: worf.API_URL+"/v1/qutu/saveRecord.json",
        animate: 1,//禁止弹出loading
        data: {
            id: finishId
        },
        success: function (json) {
            if (json.status != 1) {
                console.error(json.message);
            }
        }
    });
    if (worf.app.isReady) {
        window.app.saveImage(imgPath);
    }
};

/*
* 获取广告图
*/
function getBanner() {
    worf.ajax({
        url: worf.API_URL + "/v1/common/getBanner.json",
        data: {
            id: 107
        },
        success: function (json) {
            if (json.status == 1 && json.data.length>0) {
                var data = json.data[0];
                var action = "";
                if (data.url) {
                    action = "onclick=\"worf.nav.go('" + data.url + "')\"";
                }
                $("#m_advert").html("<img src='" + data.key + "'  " + action + " />");
            }
        }
    });
};

/*返回 */
window.goback = function () {
    if (worf.app.isReady && worf.app.toIndex) {
        worf.app.toIndex("/view/tool/carAssess.html", true);
    }
};