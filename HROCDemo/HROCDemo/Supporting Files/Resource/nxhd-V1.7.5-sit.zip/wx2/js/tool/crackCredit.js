(function () {
    var listStoreKey = "CrackCredit-list";
    var detialStoreKey = "CrackCredit-result";
    var jsonData = [];
    var pageLevel = 0;
    var ajax = {
        query: function(data,callback) {
            worf.ajax({
                animate:true,
                type:"GET",
                url: worf.API_URL+"/v1/userDishonest/query.json",
                data: data,
                errorTip: function(json) {
                    worf.prompt.tip("未查询到记录");
                    return true;
                },
                success: function (json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } 
                }
            });
        }
    };

    /**
    * 提交
    */
    function submit() {
        var realName =worf.tools.val("#txtName");
        var number = worf.tools.val("#txtNum");
        if (realName && !/^[\u4E00-\u9FA5]+$/ig.test(realName)) {
            worf.prompt.tip("姓名格式不正确");
            return false;
         }else if (number && !/(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/ig.test(number)) {
            worf.prompt.tip("身份证号码格式不正确");
            return false;
        } else if(!realName && !number) {
            worf.prompt.tip("至少输入一项才能查询");
            return false;
        }
        //左菊香
        //42092119651****2624
         realName = encodeURIComponent(realName);
         if (number.length == 18) {
             //42092119651****2624
             number = number.substr(0, 11) + "****" + number.substr(14, 4);
         } else if (number.length == 15) {
             //41052180****4003
             number = number.substr(0, 8) + "****" + number.substr(11, 4);
        }
        var data = "name=" + realName + "&no="+number;
        
        //添加诸葛io统计
        zhuge.track("失信人查询按钮-查询按钮"); 
        
        ajax.query(data, function (json) {
            worf.ajax.overlayHide();
            json = json || [];
            if (json.length > 0) {
                worf.localStorage.set(listStoreKey, JSON.stringify(json));
                worf.nav.go("/view/tool/crackCreditResult1.html");
            }
        });
        
        
        
    }

    /*加载列表*/
    function renderList() {
        jsonData = JSON.parse(worf.localStorage.get(listStoreKey));
        var el=$("#divResultList").empty();
        var max = jsonData.length;
        $.each(jsonData, function (index, item) {
            var cssClass = (index == max - 1) ? "" : "bb-gray";
            var name = item.iname;
            var cardNo = item.cardNum;
            var html = [
                  '<div class="main-item ' + cssClass + ' clearfix" onclick="openDetail(' + index + ');">',
                '<span class="name text-ellipsis">' + name + '</span>',
                '<span class="pull-right"><i class="icon icon-next"></i></span>',
                '<span class="pull-right form-value" >' + cardNo + '</span>',
                '</div>'
            ];
            el.append(html.join(""));
        });
    }
    /*打开详情*/
    window.openDetail = function (id) {
        var findData = {};
        $.each(jsonData, function (index, item) {
            if (index == id) {
                findData = item;
                return false;
            }
        });
        worf.localStorage.set(detialStoreKey, JSON.stringify(findData));
        worf.nav.go("/view/tool/crackCreditResult2.html");
    }

    /*加载详情*/
    function showDetail() {
        $("#btnShowDuty").click(function () {
            $(this).find(".icon").toggleClass("icon-down").toggleClass("icon-up");
            $("#sp_duty").toggleClass("hide");
        });
        var findData = JSON.parse(worf.localStorage.get(detialStoreKey));
        worf.localStorage.del(detialStoreKey);
        var el = $("#divDetailContent");
        for (var key in findData) {
            el.find("#sp_"+key).text(findData[key]||"");
        }
        var icon = $("#btnShowDuty .icon");
        if (findData.iname.indexOf("公司") > -1) {
            $("#divSexy,#divAge,#divCardNum").hide();
            if (icon.is(".icon-down")) {
                $("#btnShowDuty").click();
            }
        } else {
            $("#divSexy,#divAge,#divCardNum").show();
            if (icon.is(".icon-up")) {
                $("#btnShowDuty").click();
            }
        }
    }

    /**
    * 返回 
    */
    window.goback = function() {
        if (pageLevel == 1) {
            worf.animate.sliderRight("#divResult");
            //改变当前显示的头部
            worf.nav.changeHeader(0);
            //设置添加标题
            worf.app.toogleTitle($(".app-title").eq(0));
            pageLevel = 0;
            return;
        } else if (pageLevel == 2) {
            worf.animate.sliderRight("#divDetail");
            //改变当前显示的头部
            worf.nav.changeHeader(1);
            //设置添加标题
            worf.app.toogleTitle($(".app-title").eq(1));
            pageLevel = 1;
            return;
        }
        if (worf.app.isReady && worf.app.toIndex) {
            worf.app.toIndex("/view/tool/crackCredit.html", true);
        }
    };

    window.listInit = function () {
        renderList();
    }
    window.detailInit = function () {
        showDetail();
    }
    window.init = function () {
        worf.localStorage.del(listStoreKey);
        $("#submit").click(submit);
    };
})(window.Zepto);
