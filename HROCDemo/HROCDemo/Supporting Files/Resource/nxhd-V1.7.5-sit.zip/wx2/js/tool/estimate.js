$(function() {
    init();
});

(function() {
    var scrollWrapper, jRoll;
    var brand = {
        currentData: { brand: {}, series: {}, model: {} },
        localData: {
            brandId: 0, //品牌id
            seriesId: 0, //系列id
            modelId: 0, //模型id
            provinces: [], //所有城市数据
            brands: [], //所有品牌数据
            series: {}, //车系列数据
            model: {} //车型号数据
        },
        ajax: {
            /*获取车品牌*/
            getBrand: function(key, callback) {
                //检测网络
                var netStatus = worf.app.getNetStatus();
                if (netStatus.status == 0) {
                    worf.prompt.tip("请检查您的网络连接是否正常");
                    return;
                };
                //过滤
                var filter = function(key) {
                        var json = brand.localData.brands;
                        if (key) {
                            var data = [];
                            $.each(json, function(index, item) {
                                if (item.firstLetter == key || item.brand.indexOf(key) > -1) {
                                    data.push(item);
                                }
                            });
                            json = data;
                        }
                        return json;
                    }
                    //取缓存数据
                if (brand.localData.brands.length > 0) {
                    return callback && callback(filter(key));
                }

                worf.ajax({
                    url: worf.API_URL + "/v1/che300/get3rdCarBrand.json",
                    type: "GET",
                    animate: true,
                    success: function(json) {
                        if (json.status == 1) {
                            $(json.data).each(function(index, item) {
                                brand.localData.brands.push({ firstLetter: item.initial, id: item.brand_id, brand: item.brand_name });
                            });
                            callback && callback(filter(key));
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            },
            /*获取车系列*/
            getSeries: function(brandId, callback) {
                var data = brand.localData.series[brandId];
                if (data) {
                    return callback && callback(data);
                }
                //检测网络
                var netStatus = worf.app.getNetStatus();
                if (netStatus.status == 0) {
                    worf.prompt.tip("请检查您的网络连接是否正常");
                    return;
                };
                worf.ajax({
                    url: worf.API_URL + "/v1/che300/get3rdCarSeries.json?brandId=" + brandId,
                    type: "GET",
                    animate: true,
                    success: function(json) {
                        if (json.status == 1) {
                            brand.localData.series[brandId] = json.data;
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            },
            /*获取车型号*/
            getModel: function(seriesId, callback) {
                var data = brand.localData.model[seriesId];
                if (data) {
                    return callback && callback(data);
                }
                //检测网络
                var netStatus = worf.app.getNetStatus();
                if (netStatus.status == 0) {
                    worf.prompt.tip("请检查您的网络连接是否正常");
                    return;
                };
                worf.ajax({
                    url: worf.API_URL + "/v1/che300/get3rdCarModel.json?seriesId=" + seriesId + "&v=" + worf.tools.getTimestamp(),
                    type: "GET",
                    animate: true,
                    success: function(json) {
                        if (json.status == 1) {
                            brand.localData.model[seriesId] = data;
                            callback && callback(json.data);
                        } else {
                            worf.prompt.tip(json.message);
                        }
                    }
                });
            }
        },

        /**
         * 初始化数据
         */
        initData: function(callback) {
            brand.ajax.getBrand();
        },
        /**
         * 搜索品牌
         */
        searchBrand: function(key) {
            //检测网络
            var netStatus = worf.app.getNetStatus();
            if (netStatus.status == 0) {
                worf.prompt.tip("请检查您的网络连接是否正常");
                return;
            };
            key = key || '';
            brand.ajax.getBrand(key, function(data) {
                if (!key && data.length == 0) {
                    worf.ajax.overlayShow();
                    setTimeout(function() { carSeriesPicker.searchBrand(key); }, 100);
                    return;
                }
                worf.ajax.overlayHide();
                var showNum = "A";
                var html;
                if (!key) {
                    var letter = [];
                    html = '<div class="group-letter" id="letterA">A</div>';
                    for (var i = 0; i < data.length; i++) {
                        var item = data[i];
                        var cssClass = (data[i + 1] && data[i + 1].firstLetter != item.firstLetter) ? "last" : "";
                        if (item.firstLetter == showNum) {
                            html += '<div class="brand ' + cssClass + '" data-id="' + item.id + '" ><div class="bb-gray">' + item.brand + '</div></div>';
                        } else {
                            html += '<div class="group-letter" id="letter' + item.firstLetter + '">' + item.firstLetter + '</div>';
                            showNum = item.firstLetter;
                            html += '<div class="brand ' + cssClass + '"  data-id="' + item.id + '" ><div class="bb-gray">' + item.brand + '</div></div>';
                        }
                        if (item.firstLetter != letter[letter.length - 1]) {
                            letter.push(item.firstLetter);
                        }
                    }
                    $("#allBrand").html(html);
                } else {
                    html = '';
                    for (var i = 0; i < data.length; i++) {
                        var item = data[i];
                        html += '<div class="brand"  data-id="' + item.id + '" ><div class="bb-gray">' + item.brand + '</div></div>';
                    }
                    $("#allBrand").html(html);
                }
                if (!jRoll) {
                    jRoll = new JRoll("#brandScroll", {
                        scrollX: false, //x方向不允许滚动
                        bounce: false //不回弹
                    });
                } else {
                    jRoll.scrollTo(0, 0, 100).refresh();
                }
            });
        },

        /*搜索系列*/
        searchSeries: function(key) {
            brand.ajax.getSeries(key, function(data) {
                var showNum = data[0] && data[0].series_group_name;
                var html = "";
                if (showNum) {
                    html = '<div class="series-letter">' + showNum + '</div>';
                }
                for (var i = 0; i < data.length; i++) {
                    var item = data[i];
                    if (item.series_group_name == showNum) {
                        html += '<div class="series" data-id=' + item.series_id + ' ><div class="bb-gray">' + item.series_name + '</div></div>';
                    } else {
                        showNum = item.series_group_name;
                        html += '<div class="series-letter" >' + showNum + '</div>';
                        html += '<div class="series"  data-id=' + item.series_id + ' ><div class="bb-gray">' + item.series_name + '</div></div>';
                    }
                }
                $("#allSeries").empty().html(html);
                $("#brandSeriesBg").removeClass("hide");
                setTimeout(function() { $("#brandSeries").addClass("open"); }, 0);
            });
        },

        /*搜索型号*/
        searchModel: function(id, name) {
            brand.ajax.getModel(id, function(data) {
                var showNum = data[0] && data[0].model_year + "款";
                var html = "";
                if (showNum) {
                    html = '<div class="series-letter">' + showNum + '</div>';
                }
                for (var i = 0; i < data.length; i++) {
                    var item = data[i];
                    var year = item.model_year + "款";
                    var extendData = 'data-maxyear="' + item.max_reg_year + '" data-minyear="' + item.min_reg_year + '"';
                    var text = item.model_name.replace(year, "").replace(name, "");
                    if (text.trim() == "") {
                        text = item.model_name.replace(year, "");
                    }
                    if (year == showNum) {
                        html += '<div class="series" data-id="' + item.model_id + '"  ' + extendData + '><div class="bb-gray">' + text + '</div></div>';
                    } else {
                        showNum = year;
                        html += '<div class="series-letter" >' + showNum + '</div>';
                        html += '<div class="series"  data-id="' + item.model_id + '"  ' + extendData + '><div class="bb-gray">' + text + '</div></div>';
                    }
                }

                $("#allModel").empty().html(html);
                $("#brandModelBg").removeClass("hide");
                setTimeout(function() { $("#brandModel").addClass("open"); }, 0);
            });
        },

        selectBrand: function(data) {
            brand.localData.brandId = data.id;
            brand.localData.seriesId = 0;
            brand.localData.modelId = 0;
            brand.currentData.brand = data;
            brand.searchSeries(data.id);
        },
        selectSeries: function(data) {
            brand.localData.seriesId = data.id;
            brand.localData.modelId = 0;
            brand.currentData.series = data;
            brand.searchModel(data.id, data.text);
        },
        selectModel: function(data) {
            brand.localData.modelId = data.modelId;
            brand.currentData.model = data;
            brand.currentData.modelText = brand.currentData.series.text + " " + brand.currentData.modelText;
            console.log(data);
        },
        bindEvent: function() {
            //选择品牌
            $("#allBrand").on("click", function(e) {
                var me = $(e.target);
                if (me.is(".bb-gray")) me = me.parent();
                if (me.is(".brand")) {
                    brand.selectBrand({ id: me.data("id"), text: me.text() });
                    brand.cancelSearch();
                }
            });
            //选择系列
            $("#allSeries").on("click", function(event) {
                var me = $(event.target);
                if (me.is(".bb-gray")) me = me.parent();
                if (me.is(".series")) {
                    brand.selectSeries({ id: me.data("id"), text: me.text() });
                }
                event.stopPropagation();
            });
            //选择型号
            $("#allModel").on("click", function(event) {
                var me = $(event.target);
                if (me.is(".bb-gray")) me = me.parent();
                if (me.is(".series")) {
                    brand.selectModel({
                        brandId: brand.localData.brandId, //品牌id
                        seriesId: brand.localData.seriesId, //系列id
                        modelId: me.data("id"), //型号id
                        modelText: me.text(), //型号名称
                        maxYear: me.data("maxyear"), //最大上牌日期
                        minYear: me.data("minyear") //最小上牌日期
                    });
                }
                event.stopPropagation();
            });
            //切换搜索区域
            $("#brandSearchCenter").click(function() {
                $(this).addClass("hide");
                $("#brandSearch").removeClass("hide");
                setTimeout(function() { $("#txtBrandSearch").focus(); }, 200);
            });
            //输入框输入事件
            $("#txtBrandSearch").on("input", function() {
                var key = $.trim($(this).val() || "");
                brand.searchBrand(key);
            });
            //字母选中
            $("#brandLetter").click(function(e) {
                var me = $(e.target);
                if (me.is("span")) {
                    if ($("#txtBrandSearch").val() != "") return;
                    var letterSelector = "#letter" + me.text();
                    var y = 0,
                        isFind = false;
                    $("#allBrand").children().each(function(index, item) {
                        item = $(item);
                        var isStop = item.is(letterSelector);
                        if (!isStop) {
                            y += item.height();
                        } else {
                            isFind = true;
                            return false;
                        }
                    });
                    isFind && jRoll.scrollTo(0, 0 - y, 100).refresh();
                }
            });
            //关闭系列 
            $("#brandSeriesBg,#brandSeriesTitle").on("click", function() {
                $("#brandSeries").removeClass("open");
                setTimeout(function() { $("#brandSeriesBg").addClass("hide"); }, 400);
            });
            //关闭型号 touchstart
            $("#brandModelBg,#brandModelTitle").on("click", function() {
                $("#brandModel").removeClass("open");
                setTimeout(function() { $("#brandModelBg").addClass("hide"); }, 400);
            });
            //阻止父层滚动
            $("#allSeries,#allModel").on("scroll", function(event) {
                event.stopPropagation();
                return false;
            });
        },
        /*退回到搜索状态以前*/
        cancelSearch: function() {
            if ($("#brandSearchCenter").hasClass("hide")) {
                brand.searchBrand();
            }
            $("#txtBrandSearch").blur();
            $("#brandSearch").addClass("hide");
            $("#brandSearchCenter").removeClass("hide");
        },
        init: function(options) {
            jRoll = null; //重置
            options = options || {};
            scrollWrapper = options.scrollWrapper ? $(options.scrollWrapper) : document.body;
            if (options.selectModel) {
                brand.selectModel = options.selectModel;
            }
            brand.searchBrand();
            brand.bindEvent();
        }
    };
    window.carSeriesPicker = brand;
})(window.Zepto);


(function() {
    var pageLevel = 0;
    var cityPickerUUID = "city";
    worf.ui.slideUpScrollBox.localData["city"] = { data1: [], data2: {}, data3: {} };
    var userType = 0, //用户类型，0:无身份,1:借款人,2:贷款经理
        userSubType = 0; //用户子类型,0-未知 1-纳鑫达人 2-纳鑫战士 3-客户经理 4-团队经理
    var ajax = {
        localData: {
            province: [],
            city: []
        },
        /* 获取所有数据 */
        getAllData: function(callback) {
            //检测网络
            var netStatus = worf.app.getNetStatus();
            if (netStatus.status == 0) {
                worf.prompt.tip("请检查您的网络连接是否正常");
                return;
            };

            if (ajax.localData.province.length > 0) {
                return callback && callback();
            };
            $.get(worf.API_URL + "/v1/che300/get3rdCities.json", function(json) {
                if (json && json.data && json.data.length > 0) {
                    var cities = json.data;
                    var provinces = {};
                    $(cities).each(function(index, item) {
                        if (provinces[item.prov_id] == null) {
                            provinces[item.prov_id] = item.prov_name;
                        }
                    });
                    provinces = $.map(provinces, function(text, value) {
                        return { value: value, text: text };
                    });
                    ajax.localData.province = provinces;
                    ajax.localData.city = cities;
                    callback && callback();
                } else {
                    worf.prompt.tip("查询城市数据失败");
                }
            });
        },
        /*获取省份*/
        getProvince: function(callback) {
            if (ajax.localData.province.length == 0) {
                return ajax.getAllData(function() {
                    callback(ajax.localData.province);
                });
            } else {
                return callback(ajax.localData.province);
            }
        },
        /*获取城市*/
        getCity: function(provinceId, callback) {
            var data = $.map(ajax.localData.city, function(item, index) {
                if (item.prov_id == provinceId) {
                    return { value: item.city_id, text: item.city_name };
                }
            });
            callback && callback(data);
        },
        /*查询用户状态*/
        getUserStatus: function(callback) {
            worf.ajax({
                data: { key: new Date().getTime() },
                url: worf.API_URL + "/v1/user/getUserStatus.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /*预估*/
        estimate: function(data, callback) {

            //检测网络
            var netStatus = worf.app.getNetStatus();
            if (netStatus.status == 0) {
                worf.prompt.tip("请检查您的网络连接是否正常");
                return;
            };


            var url = worf.API_URL + '/v1/che300/get3rdEstimate.json?&cityId=' +
                data.city + '&modelId=' + data.model +
                '&regDate=' + data.month + '&mile=' + data.age +
                "&v=" + worf.tools.getTimestamp();

            worf.ajax({
                url: url,
                type: "GET",
                animate: true,
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.tip(json.message);
                    }
                }
            });
        },
        /* 检测提成方案是否设置*/
        queryLendingRateRange: function(callback) {
            worf.ajax({
                animate: true,
                url: worf.API_URL + "/partner/v1/queryLendingRateRange.json",
                success: function(json) {
                    if (json.status == 1) {
                        callback && callback(json.data);
                    } else {
                        worf.prompt.fail(json.message || "系统异常");
                    }
                }
            });
        }
    };
    /**
     * 提交
     */
    function submit() {
        var brandElement = $("#sp_brand"),
            citys = ($("#sp_city").data("value") || ",").split(","),
            province = citys[0],
            city = citys[1],
            brand = brandElement.data("brandId"),
            series = brandElement.data("seriesId"),
            model = brandElement.data("modelId"),
            month = $("#sp_month").data("value"),
            age = worf.tools.val("#sp_age");
        if (!city) {
            worf.prompt.tip("请选择所在城市");
            return false;
        } else if (!model) {
            worf.prompt.tip("请选择入车辆型号");
            return false;
        } else if (!month) {
            worf.prompt.tip("请选择入首次上牌年月");
            return false;
        } else if (!age) {
            worf.prompt.tip("请输入行驶里程");
            return false;
        } else if (!/^(([1-9]\d{0,1})|0)(\.\d{1,2})?$/ig.test(age)) {
            worf.prompt.tip("行驶里程格式不正确<br/>最多2位整数，2位小数");
            return false;
        }

        //添加诸葛io统计
        zhuge.track("额度预估按钮-预估额度按钮");

        var reqData = {
            province: province,
            city: city,
            brand: brand,
            series: series,
            model: model,
            month: month,
            age: age
        };
        ajax.estimate(reqData, function(data) {
            showResult(data, reqData);
        });
    }

    /**
     * 显示明细
     */
    function showResult(result, query) {
        $("#spResultAmount").text(result.min.toFixed(2) + "-" + result.max.toFixed(2));
        $("#spMax").text(result.max.toFixed(2) + "万元");
        worf.animate.sliderLeft("#divResult");
        //改变当前显示的头部
        worf.nav.changeHeader(1);
        //设置添加标题
        worf.app.toogleTitle($(".app-title").eq(1));
        pageLevel = 1;

        //团队经理和客户经理和战士3种角色才显示提单列表
        //userSubType：用户子类型,0-未知 1-纳鑫达人 2-纳鑫战士 3-客户经理 4-团队经理
        /*  if (['4', '3', '2'].indexOf(userSubType) == -1) {
             return;
         } */

        //计算上牌年份至今的月份数
        function monthDiff(month) {
            var dates = month.split("-"),
                now = new Date();
            var startYear = parseInt(dates[0], 10);
            var startMonth = parseInt(dates[1], 10);
            var endYear = now.getFullYear();
            var endMonth = now.getMonth() + 1;
            return (endYear * 12 + endMonth) - (startYear * 12 + startMonth);
        }

        /**************************
         * 判断是否显示产品
         * 鑫抵贷(201)：首次上牌时间≤ 10年，额度预估值≥4万 
         * 鑫信贷(203)：首次上牌时间≤ 8年，额度预估值≥3万
         ***************************/
        var maxMonth = monthDiff(query.month);
        var config = {
            201: {
                check: function() {
                    return maxMonth < 10 * 12 && result.max >= 4;
                }
            },
            203: {
                check: function() {
                    return maxMonth < 8 * 12 && result.max >= 3;
                }
            },
            99201: {
                check: function() {
                    return maxMonth < 10 * 12 && result.max >= 4;
                }
            },
        };
        var show = false;
        $("#proList li").each(function(index, item) {
            var $this = $(this),
                code = $this.data("code");
            if (config[code].check()) {
                $this.css("display", "block");
                show = true;
            } else {
                $this.css("display", "none");
            }
        });

        if (show) {
            $("#proList").removeClass("hide");
        } else {
            $("#proList").addClass("hide");
        }


    }

    /**
     * 底部弹出时间选择框
     */
    function datePick() {
        var me = $(this);
        var type = me.data("field");
        var input = me.find(".form-value");
        var value = input.data("value");
        var maxYear = input.data("maxYear");
        var minYear = input.data("minYear");
        var year = value && value.substr(0, 4);
        var month = value && parseInt(value.substr(5, 2), 10);
        var day = value && parseInt(value.substr(8, 2), 10);
        worf.ui.datePicker({
            el: me,
            year: year,
            month: month,
            day: day,
            mode: "month",
            max: { year: maxYear },
            min: { year: minYear },
            selected: function(year, month) {
                month = month < 10 ? "0" + month : month;
                var data = year + "-" + month;
                me.find("#sp_" + type).removeClass("color-gray").attr("data-value", data).html(data);
            }
        });
    }

    /**
     * 选择城市
     */
    function scrollCity() {
        var uuid = cityPickerUUID;
        var data = worf.ui.slideUpScrollBox.data[uuid];
        if (!data || data.length < 2) {
            //查询省份
            ajax.getProvince(function(json) {
                worf.ui.slideUpScrollBox.data[uuid][0] = json;
                //查询初始城市
                var firstProvince = json[0].value;
                ajax.getCity(firstProvince, function(json) {
                    worf.ui.slideUpScrollBox.data[uuid][1] = json;
                    scrollCity();
                });
            });
            return;
        }

        var me = $("#sp_city");
        worf.ui.slideUpScrollBox({
            el: me,
            level: 2,
            currentValue: (me.data("value") || "").split(","),
            data: data,
            getLevel2Data: function(data, callback) {
                ajax.getCity(data.value, callback);
            },
            selected: function(data) {
                var text = data[1].text;
                var value = data[0].value + "," + data[1].value;
                me.removeClass("color-gray").attr("data-value", value).html(text);
            }
        });
    }
    /**
     * 选择城市-初始化第一个省份的城市数据
     */
    function initCityData() {
        var uuid = cityPickerUUID;
        //缓存数据定义
        worf.ui.slideUpScrollBox.localData[uuid] = { data1: [], data2: {}, data3: {} };
        //当前数据定义
        worf.ui.slideUpScrollBox.data[uuid] = [];
        //查询省份
        ajax.getProvince(function(json) {
            worf.ui.slideUpScrollBox.data[uuid][0] = json;
            //查询初始城市
            var firstProvince = json[0].value;
            ajax.getCity(firstProvince, function(json) {
                worf.ui.slideUpScrollBox.data[uuid][1] = json;
            });
        });
    }

    /**
     * 选择车辆型号
     */
    var editFlag = true;

    function selectCarSeries() {
        var me = $(this);
        var name = me.find("label").text();
        var element = me.find(".form-value");
        var elementId = element.attr("id");
        var inputMode = me.data("input");
        var regex = me.data("regex");
        var rightText = "";
        var regexMessage = me.data("regexms");
        var inputGroup, getResult, check, rangeUnit, multiSelectData;
        if (elementId == "sp_brand") {
            inputGroup = $("#brandTemplate").html();
        }
        worf.ui.editPage({
            regex: regex, //检验正则
            regexMessage: regexMessage, //检验提示语
            text: element.text(), //当前文本
            name: name,
            rightText: rightText, //头部右侧的按钮文字
            inputMode: inputMode, //输入模式：比如 tel，number
            value: element.attr("data-value"), //当前值
            getResult: getResult, //获取结果的方法
            inputGroup: inputGroup, //输入框的html
            success: function(data) {
                var text = data.modelText;
                var value = data.modelId;
                element.data("brandId", data.brandId).data("seriesId", data.seriesId).data("modelId", data.modelId).data("maxYear", data.maxYear).data("minYear", data.minYear).data("value", value).removeClass("color-gray").text(text);
                $("#sp_month").data("maxYear", data.maxYear).data("minYear", data.minYear).addClass("color-gray").attr("data-value", "").html("请选择");
            },
            opening: function(options) {
                pageLevel = 2;
                //改变当前显示的头部
                worf.nav.changeHeader(1);
                //设置添加标题
                worf.app.toogleTitle($("#editTitle").text(), { rightTitle: "保存" });
                if (elementId == "sp_brand") {
                    window.carSeriesPicker.init({
                        scrollWrapper: !worf.device.wap ? $("#editInput") : $(document.body),
                        selectModel: function(data) {
                            worf.ui.editPage.hide();
                            data.modelText = carSeriesPicker.currentData.series.text + " " + data.modelText;
                            options.success(data);
                        }
                    });
                }
            },
            closed: function() {
                editFlag = false;
                //改变当前显示的头部
                worf.nav.changeHeader(0);
                //设置添加标题
                worf.app.toogleTitle($(".app-title").eq(0), { rightTitle: "" });
            }
        });
    }

    /**
     * 返回 
     */
    window.goback = function() {
        if (pageLevel == 1) {
            worf.animate.sliderRight("#divResult");
            //改变当前显示的头部
            worf.nav.changeHeader(0);
            //设置添加标题
            worf.app.toogleTitle($(".app-title").eq(0));
            pageLevel = 0;
            return;
        } else if (pageLevel == 2) {
            //改变当前显示的头部
            worf.nav.changeHeader(0);
            //设置添加标题
            worf.app.toogleTitle($(".app-title").eq(0));
            pageLevel = 0;
            $("#btnEditback").click();
            return;
        }
        if (worf.app.isReady && worf.app.toIndex) {
            worf.app.toIndex("/view/tool/estimate.html", true);
        }
    };


    /**
     *  检测用户实名
     */
    function checkReal() {
        if (!worf.user.isLogin()) {
            return;
        }
        ajax.getUserStatus(function(data) {
            userType = data.userType; //用户类型，0:无身份,1:借款人,2:贷款经理
            userSubType = data.subUserType; //用户子类型,0-未知 1-纳鑫达人 2-纳鑫战士 3-客户经理 4-团队经理
            if (data.cardState != 1) {
                worf.prompt.alert("请先实名认证", function() {
                    worf.prompt.closeMe();
                    window.app && window.app.goRealNameCert && window.app.goRealNameCert();
                    !window.app && worf.nav.go("/view/user/realName.html");
                }, { okText: "去认证" });
                return;
            }
        });
    }

    /**
     * 检测提成方案是否设置
     * @param {any} code 产品编号
     */
    function checkSetting(code) {
        ajax.queryLendingRateRange(function(data) {
            if (data && data.length > 0) {
                window.app && app.goToLoans(code);
                window.goToLoans && window.goToLoans(code);
            } else {
                showIdentityConfirm();
            }
        });
    }

    /**
     * 显示认证身份弹框
     */
    function showIdentityConfirm() {
        $("#identityConfirmBox").show();
        $("#identityConfirmClose").off().click(function() {
            $("#identityConfirmBox").hide();
        });
        $("#identityConfirmBox .sure").off().click(function() {
            $("#identityConfirmBox").hide();
            window.app && window.app.goOrganizationCert && window.app.goOrganizationCert();
            window.goOrganizationCert && window.goOrganizationCert();
        });
        $("#identityConfirmBox .cancle").off().click(function() {
            $("#identityConfirmBox").hide();
            window.app && window.app.goContactMyGuru && window.app.goContactMyGuru();
            window.goContactMyGuru && window.goContactMyGuru();
        });
    }

    window.init = function() {
        $("#divCity").click(scrollCity);
        $("#divCar").click(selectCarSeries);
        $("#divMonth").click(datePick);
        $("#btnSubmit").click(submit);
        $("#proList li").click(function() {
            var code = $(this).data("code");
            window.app && app.goToLoans(code);
            window.goToLoans && window.goToLoans(code);
            /*   //userSubType：用户子类型,0-未知 1-纳鑫达人 2-纳鑫战士 3-客户经理 4-团队经理
              if (['1', '2'].indexOf(userSubType) != -1) {
                  worf.prompt.tip("产品还未开放");
                  return;
              }

              //战士才需要判断是否设置提成方案
              if (userSubType == 2) {
                  checkSetting(code);
              } else {
                  window.app && app.goToLoans(code);
                  window.goToLoans && window.goToLoans(code);
              } */
        });
        /* checkReal(); */
        initCityData();
        window.carSeriesPicker.initData();
    };
})(window.Zepto);