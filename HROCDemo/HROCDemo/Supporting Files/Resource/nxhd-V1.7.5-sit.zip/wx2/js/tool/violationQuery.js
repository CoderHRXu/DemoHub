 var isiplimit = 0,
     carid;
 var ajax = {
     check: function(json, callback, showCaptcha) {
         if (typeof json.Data == "string") {
             json.Data = JSON.parse(json.Data);
         }

         //ip限制
         var ipLimit = {
             "-50": 0,
             "-54": 1,
             "-56": 1,
             "-50": 0,
         };
         isiplimit = ipLimit[json.Data && json.Data.returncode || "-50"] || 0;

         if (json.Data && json.Data.result && json.Data.result.citys[0].authimage) {
             carid = json.Data.result.carid;
             showCaptcha && showCaptcha(json.Data.result);
         } else if (json.Data && json.Data.returncode == 0) {
             callback && callback(json.Data);
         } else if (json.Data && json.Data.returncode == -56) {
             worf.prompt.tip("验证码错误");
             $("#txtauthcode").val("");
             $("#btnRetry").click();
         } else {
             worf.prompt.tip(json.Data.message || "发生异常");
         }
     },
     getTotal: function(data, callback, showCaptcha) {
         worf.ajax.overlayShow();
         $.ajax({
             url: worf.origin + "/spider/violate/violation/violation/GetViolationTotal",
             type: "POST",
             data: data,
             success: function(json) {
                 worf.ajax.overlayHide();
                 ajax.check(json, callback, showCaptcha);
             },
             complete: function() {
                 worf.ajax.overlayHide();
             },
             error: function() {
                 worf.ajax.overlayHide();
             }
         });
     },
     getListByCaptcha: function(data, callback, showCaptcha) {
         worf.ajax.overlayShow();
         $.ajax({
             url: worf.origin + "/spider/violate/Violation/Violation/GetViolationListByCarCode",
             type: "POST",
             data: data,
             success: function(json) {
                 worf.ajax.overlayHide();
                 ajax.check(json, callback, showCaptcha);
             },
             complete: function() {
                 worf.ajax.overlayHide();
             },
             error: function() {
                 worf.ajax.overlayHide();
             }
         });
     },
     getList: function(data, callback) {
         worf.ajax.overlayShow();
         $.ajax({
             url: worf.origin + "/spider/violate/Violation/Violation/GetViolationList",
             type: "POST",
             data: data,
             success: function(json) {
                 worf.ajax.overlayHide();
                 if (json.Data) {
                     json.Data = JSON.parse(json.Data);
                 }
                 if (json.Data && json.Data.returncode == 0) {
                     callback && callback(json.Data.result);
                 } else {
                     worf.prompt.tip(json.Data && json.Data.message || "发生异常");
                 }
             },
             complete: function() {
                 worf.ajax.overlayHide();
             },
             error: function() {
                 worf.ajax.overlayHide();
             }
         });
     },
 };
 var violation = {
     data: {
         query: {},
         total: {}
     },
     selectCity: function() {
         cityPicker.show($("#sp_city"));
     },
     /**
      * 显示验证码
      */
     showCaptcha: function(data) {
         var imgData = (data || {}).citys[0].authimage;
         $("#divCaptcha").css("background-image", "url('data:image/jpeg;base64," + imgData + "')");
         $("#captchaBox").removeClass("hide");
         $("#captchaBox .icon-error").off().click(function() {
             $("#captchaBox").addClass("hide");
         });
         $("#captchaBox #btnRetry").off().click(function() {
             violation.getTotal($("#btnSubmit"), 1);
         });
     },
     /**
      * 获取总数
      */
     getTotal: function($btn, authcodetype) {
         if ($btn.hasClass("ing")) {
             return;
         }
         $btn.addClass("ing");
         //收起结果部分
         $("#resultBox").addClass("hide");
         //表单检验
         var data = worf.validate("#form", {
             filter: ".form-value"
         });
         if (!data) {
             $btn.removeClass("ing");
             return false;
         }
         data.cityid = data.cityid.split(",")[1];
         data.authcode = $("#txtauthcode").val(); //验证码
         data.authcodetype = authcodetype || 0; //重新获取验证码时为1
         violation.data.query = data;
         ajax.getTotal(data, function(data) {
             violation.data.total = data;
             violation.getList();
         }, violation.showCaptcha);
         setTimeout(function() {
             $btn.removeClass("ing");
         }, 200);
     },
     /**
      * 输入验证码获取总数
      */
     getTotalByCaptcha: function() {
         var data = {
             cityid: violation.data.query.cityid,
             carid: carid,
             carcode: $("#txtauthcode").val()
         };
         ajax.getListByCaptcha(data, function(data) {
             violation.data.total = data;
             violation.getList();
         }, violation.showCaptcha);
     },
     /**
      * 查询违章记录
      */
     getList: function() {
         $("#captchaBox").addClass("hide");
         $("#resultBox").removeClass("hide");
         //显示总计
         var total = violation.data.total;
         $("#iTime").html(total.wzcount + "次");
         $("#iPay").html(total.wzpay + "元");
         $("#iScore").html(total.wzscore + "分");
         //显示明细
         ajax.getList(violation.data.query, function(data) {
             var html = [];
             var template = $("#tpl-result").html();
             $(data.citys || []).each(function(index, item) {
                 $(item.violationdata).each(function(index, item2) {
                     item2.cityname = item.cityname;
                     html.push(worf.tools.tmpEngine(template, item2));
                 });
             });
             $("#resultList").html(html.join(""));
         });
     },
     /*打开编辑页*/
     openEidt: function() {
         var me = $(this);
         var name = me.find("label").text();
         var element = me.find(".form-value");
         var elementId = element.attr("id");
         var elementName = element.attr("name");
         var mode = me.data("mode");
         var rightText = me.data("title-righttext");
         var inputMode = me.data("input");
         var regex = me.data("regex");
         var helpTip = me.data("helptip");
         var regexMessage = me.data("regexms");
         var placeholder = me.data("placeholder");
         var maxlength = me.data("maxlength");
         var required = me.find(".form-value").data("val").toString().indexOf("required") > -1;
         var inputGroup, getResult, check, checkIsAsync, rangeUnit, multiSelectData, radioSelectData, controlScroll;
         //var clearCall = apply.clear;
         if (elementName == "platenum") {
             inputGroup = $("#carNoTemplate").html();
             getResult = function(wrapper) {
                 var value = [];
                 var text = [];
                 var num = (wrapper.find(".carno-group").text() + wrapper.find("input").val()).replace(/\s/ig, "").toUpperCase();
                 value.push(num);
                 text.push(num);

                 return {
                     text: text,
                     value: value
                 };
             }
         }

         worf.ui.editPage({
             el: me,
             mode: mode, //输入框的模式 input,textarea,range
             placeholder: placeholder, //提示信息
             maxlength: maxlength, //字数限制
             regex: regex, //检验正则
             notRequired: !required, //是否是选填项
             clearCall: null, //清空方法
             regexMessage: regexMessage, //检验提示语
             rightText: rightText, //头部右侧的按钮文字
             text: element.text(), //当前文本
             inputMode: inputMode, //输入模式：比如 tel，number
             value: element.attr("data-value"), //当前值
             name: name,
             helpTip: helpTip, //输入框下面的提示语
             multiSelectData: multiSelectData, //多选项的数据
             radioSelectData: radioSelectData, //单选项的数据
             radioExtraText: element.attr("data-extra"), //单选项的填写数据
             getResult: getResult, //获取结果的方法
             check: check, //检查结果的方法
             checkIsAsync: checkIsAsync, //是否是异步检查结果
             inputGroup: inputGroup, //输入框的html
             success: function(data) {
                 var text = data.text;
                 var value = data.value;
                 var suffix = element.data("suffix") || "";
                 if (suffix) {
                     text = text.replace(suffix, "") + suffix;
                 }
                 element.data("value", value).text(text).removeClass("color-gray");
             },
             berforeOpening: function() {

             },
             opening: function(options) {
                 //改变当前显示的头部
                 worf.nav.changeHeader("#editFormHeader");
                 //设置添加标题
                 worf.app.toogleTitle($("#editTitle").text(), {
                     rightTitle: "保存"
                 });
                 if (elementName == "platenum") {
                     worf.ui.carNumPicker.init({
                         value: element.attr("data-value")
                     });
                 }
             },
             closed: function() {
                 editFlag = false;
                 //改变当前显示的头部
                 worf.nav.changeHeader(0);
                 //设置添加标题
                 worf.app.toogleTitle("违章查询", {
                     rightTitle: ""
                 });
             }
         });
     },
     init: function() {
         var that = this;
         cityPicker.init();
         $("[data-edit]").click(that.openEidt);
         //立即查询
         $("#btnSubmit").click(function() {
             $("#txtauthcode").val(""); //清空验证码
             that.getTotal($(this), 0);
         });

         //输入验证码后再次查询
         $("#btnQuery").click(function() {
             if (isiplimit == 0) {
                 that.getTotalByCaptcha();
             } else {
                 that.getTotal($(this), 0);
             }
         });

         $("[data-box-scroll]").click(that.selectCity);
     }
 }
 $(function() {
     violation.init();
 })

 /**
  * 返回 
  */
 window.goback = function() {
     if ($("#editForm").hasClass("slide_visible")) {
         //改变当前显示的头部
         worf.nav.changeHeader(0);
         //设置添加标题
         worf.app.toogleTitle("违章查询", {
             rightTitle: ""
         });
         pageLevel = 0;
         return;
     }

     if (worf.app.isReady && worf.app.toIndex) {
         worf.app.toIndex("/view/tool/violationQuery.html", true);
     }
 };