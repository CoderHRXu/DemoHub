$(function() {
    init();
});

(function() {
    var definedConfig = {
        term: { 1: "1期", 2: "2期", 3: "3期", 4: "4期", 5: "5期", 6: "6期", 12: "12期", 18: "18期", 24: "24期" }
    };
    /**
     * 提交
     */
    function submit() {
        var data = worf.validate("#form", { filter: ".form-value" });
        if (data) {
            calculator(data, function(result) {
                showDetail(result);
            });
        }
    }

    /**
     * 开始计算
     */
    function calculator(data, callback) {
        /**
         * 获取下个还款日
         */
        var getNextMonthDay = function(vyear, vmonth, vday) {
            var daysInMonth = new Array([0], [31], [28], [31], [30], [31], [30], [31], [31], [30], [31], [30], [31]);
            var strYear = parseInt(vyear);
            var strMonth = parseInt(vmonth) + 1;
            var strDay = parseInt(vday);
            if (strYear % 4 == 0 && strYear % 100 != 0) {
                daysInMonth[2] = 29;
            }
            if (strMonth + 1 == 13) {
                strYear += 1;
                strMonth = 1;
            } else {
                strMonth += 1;
            }
            strDay = daysInMonth[strMonth] >= strDay ? strDay : daysInMonth[strMonth];
            if (strMonth < 10) {
                strMonth = "0" + strMonth;
            }
            if (strDay < 10) {
                strDay = "0" + strDay;
            }
            datastr = strYear + "-" + strMonth + "-" + strDay;
            return datastr;
        };
        //数据类型转换
        for (var key in data) {
            data[key] = parseFloat(data[key], 10);
        }
        var loanMoney = data.loanMoney, //贷款金额
            term = data.term, //贷款期限
            yearRate = data.yearRate, //贷款年利率
            guaranteeRate = data.guaranteeRate, //担保费率
            loanRate = data.loanRate, //放款手续费率
            prepaymentRate = data.prepaymentRate; //提前还款手续费率
        var result = {};

        result.term =term;
        //每期还款本金
        result.perRepay = loanMoney / term;
        //放款手续费
        result.repayFee = loanMoney * loanRate / 100;
        //每期利息
        result.preinterest = loanMoney * yearRate/12/100;
        //担保费
        result.guaranteeFee = loanMoney * guaranteeRate / 100;
        //提前还款手续费
        result.prepaymentFee = loanMoney * prepaymentRate / 100;
        //每期还款总额
        result.perTotal = result.perRepay + result.guaranteeFee + result.preinterest;
        //还款总额
        result.total = result.perTotal * term;

        var now = new Date();
        var startDate, endDate, betweenDate, year, month, day, formatMonth, feePer, feePer1;
        year = now.getFullYear();
        month = now.getMonth();
        day = now.getDate();
        feePer1 = Math.round(result.perTotal); //每期应还
        var arr;
        result.refundList = [];
        for (var i = 1; i <= term; ++i) {
            endDate = getNextMonthDay(year, month, day);
            month++;
            if (month < 10) {
                month = "0" + month;
            }
            if (day < 10) {
                day = "0" + day;
            }

            startDate = year + "-" + month + "-" + day;
            betweenDate = startDate + "——" + endDate;
            arr = endDate.split("-");
            year = parseInt(arr[0]);
            if (arr[1].indexOf("0") == 0) {
                arr[1] = arr[1].substring(1, 2);
            }
            month = parseInt(arr[1]) - 1;
            if (arr[2].indexOf("0") == 0) {
                arr[2] = arr[2].substring(1, 2);
            }
            day = parseInt(arr[2]);

            /*if(term == 6){//如果是6期每期还款额就是10%本金+费用，最后一期为50%本金+费用
                if(i < term){
                    feePer1 = Math.round(parseFloat($("#txtLoanMoney").val()*10/100) + parseFloat($("#txtGuaranteeFee").val())+ parseFloat($("#txtLx").val()));
                }else{
                    feePer1 = Math.round(parseFloat($("#txtLoanMoney").val()*50/100) + parseFloat($("#txtGuaranteeFee").val())+ parseFloat($("#txtLx").val()));
                }
            }else{*/
            //if(i < term){
            //feePer1 = Math.round(parseFloat($("#txtLoanMoney").val()/term) + parseFloat($("#txtGuaranteeFee").val())+ parseFloat($("#txtLx").val()));
            //}else{
            //  feePer1 = Math.round(parseFloat($("#txtLoanMoney").val()/term) + parseFloat($("#txtGuaranteeFee").val())+ parseFloat($("#txtLx").val()) + parseFloat($("#txtTqhksxf").val()));
            //}
            //}

            var leaveFee = feePer1 * (term - i + 1);
            feePer = loanMoney - ((loanMoney / term) * (i - 1)) + result.guaranteeFee + result.preinterest;
            if (i < term) {
                feePer += result.prepaymentFee;
            }
            feePer = Math.min(leaveFee, feePer);
            result.refundList.push({ term: i, date: betweenDate, perRepay: feePer1, prepayment: feePer });
        }

        callback && callback(result);
    }

    /**
     * 显示明细
     */
    window.showDetail = function(result) {
        var resultWrapper = $("#divResultList");
        var refundWrapper = $("#divRefundList");
        $("#spTotalInterest").text(formatNumber(result.preinterest*result.term));
        $("#spTotalRefund").text(formatNumber(result.total));
        resultWrapper.removeClass("hide");
        for (var key in result) {
            var value = result[key] || "0";
            if (!isNaN(value)) {
                var element = resultWrapper.find("#sp_" + key);
                var suffix = element.data("suffix");
                element.text(value.toFixed(2) + suffix);
            }
        }
        //显示还款列表
        refundWrapper.empty().removeClass("hide");
        var listHtml = [];
        listHtml.push([
            '<div class="refund-item bb-gray clearfix">',
            '<span class="pull-left flex">期数</span>',
            '<span class="pull-left flex">每期应还/元</span>',
            '<span class="pull-right flex" id="sp_amount">提前还款/元</span>',
            '</div>'
        ].join(""));
        $.each(result.refundList, function(index, item) {
            var html = [
                '<div class="refund-item bb-gray clearfix">',
                '<span class="pull-left flex">' + item.term + '</span>',
                '<span class="pull-left flex">' + item.perRepay.toFixed(2) + '</span>',
                '<span class="pull-right flex" id="sp_amount">' + item.prepayment.toFixed(2) + '</span>',
                '</div>'
            ];
            listHtml.push(html.join(""));
        });
        refundWrapper.append(listHtml.join(""));

        worf.animate.sliderLeft("#divResult");
        //改变当前显示的头部
        worf.nav.changeHeader(1);
        //设置添加标题
        worf.app.toogleTitle($(".app-title").eq(1));
        pageLevel = 1;

        /*格式化数字*/
        function formatNumber(num) {
            var numStr = num.toFixed(2);
            var numbers = numStr.split(".");
            var letters = numbers[0].split("").reverse();
            for (var i = 0; i < letters.length; i++) {
                if ((i + 1) % 3 == 0) {
                    letters.slice(i + 1, 0, ",");
                }
            }
            return letters.reverse().join("") + (numbers[1] ? ("." + numbers[1]) : "");
        }
    }

    /**
     * 底部弹出选择框
     */
    window.scrollUpBox = function(obj) {
        var me = $(obj);
        worf.ui.slideUpScrollBox({
            data: definedConfig.term,
            currentValue: [1],
            selected: function(data) {
                var value = data[0].value;
                var text = data[0].text;
                me.find(".form-value").removeClass("color-gray").addClass("color-black").attr("data-value", value).text(text);
            }
        });
    }

    /**
     * 返回 
     */
    window.goback = function() {
        if (pageLevel == 1) {
            worf.animate.sliderRight("#divResult");
            //改变当前显示的头部
            worf.nav.changeHeader(0);
            //设置添加标题
            worf.app.toogleTitle($(".app-title").eq(0));
            pageLevel = 0;
            return;
        }
        if (worf.app.isReady && worf.app.toIndex) {
            worf.app.toIndex("/view/tool/calculator.html", true);
        }
    };

    function reset() {
        $("#form").find("input").val("");
        $("#txtTerm").data("value", "").text("请选择").addClass("color-gray");
    }

    window.init = function() {
        $("#btnSubmit").click(submit);
        $("#btnReset").click(reset);
    };
})(window.Zepto);
