$(function () {
    init();
});

(function () {
    var json;
    var pageLevel = 0;
    var definedConfig = {
        refundType:{1:"等额本息",2:"等额本金",3:"先息后本" }
    };
    /**
    * 提交
    */
    function submit() {
        var amount = worf.tools.val("#txtAmount");
        var yearRate = worf.tools.val("#txtRate");
        var term = worf.tools.val("#txtTerm");
        var refundType = $("#txtRefundType").data("value");
        if (!amount) {
            worf.prompt.tip("请输入贷款金额");
            return false;
        } else if (!/^([1-9]\d{0,3}|0)(\.\d{1})?$/ig.test(amount)) {
            worf.prompt.tip("贷款金额格式不正确<br/>最多4位整数，1位小数");
            return false;
        } else if (!yearRate) {
            worf.prompt.tip("请输入贷款年利率");
            return false;
        } else if (!/^([1-9]\d{0,1}|0)(\.\d{0,1})?$/ig.test(yearRate)) {
            worf.prompt.tip("贷款年利率格式不正确<br/>最多2位整数，1位小数");
            return false;
        } else if (!term) {
            worf.prompt.tip("请输入贷款期限");
            return false;
        } else if (!/^[1-9]\d?$/ig.test(term)) {
            worf.prompt.tip("贷款期限格式不正确<br/>最多2位整数");
            return false;
        } else if (!refundType) {
            worf.prompt.tip("请输入还款方式");
            return false;
        }
        
        //添加诸葛统计
        zhuge.track("还款计算器按钮-立即计算按钮");
        
        var data = {
            amount: amount,
            yearRate: yearRate,
            term: term,
            refundType: refundType
        };
        calculator(data, function (result) {
            showDetail(result);
        });
    }

    /**
    * 开始计算
    */
    function calculator(data, callback) {
        data.amount = data.amount * 10000;
        data.rate = data.yearRate / 12 / 100;//月利率=年利率/12
        var refundType = data.refundType;
        var result = data;
        result.yearRate = data.yearRate;
        if (refundType == 1) {
            //等额本息
            //设贷款额为a，月利率为i，年利率为I，还款月数为n，每月还款额为b，还款利息总和为Y 
            //1：I＝12×i 
            //2：Y＝n×b－a 
            //3：第一月还款利息为：a×i 
            //第二月还款利息为：〔a－（b－a×i）〕×i＝（a×i－b）×（1＋i）^1＋b 
            //第三月还款利息为：｛a－（b－a×i）－〔b－（a×i－b）×（1＋i）^1－b〕｝×i＝（a×i－b）×（1＋i）^2＋b 
            //第四月还款利息为：＝（a×i－b）×（1＋i）^3＋b 
            //.....
            //第n月还款利息为：＝（a×i－b）×（1＋i）^（n－1）＋b 
            //求以上和为：Y＝（a×i－b）×〔（1＋i）^n－1〕÷i＋n×b 
            //4：以上两项Y值相等求得 
            //月均还款:b＝a×i×（1＋i）^n÷〔（1＋i）^n－1〕 
            //支付利息:Y＝n×a×i×（1＋i）^n÷〔（1＋i）^n－1〕－a 
            //还款总额:n×a×i×（1＋i）^n÷〔（1＋i）^n－1〕 
            //注:a^b表示a的b次方。
            result.monthRefund = data.amount*data.rate*Math.pow((1+data.rate), data.term)/(Math.pow((1+data.rate),data.term)-1);//月均还款
            result.totalRefund = data.term * result.monthRefund; //还款总额
            result.totalInterest = result.totalRefund-data.amount; //支付利息总和
        } else if (refundType == 2) {
            // 等额本金
            // ==========================
            // 设贷款额为a，月利率为i，年利率为I，还款月数为n，an第n个月贷款剩余本金a1=a,a2=a-a/n,a3=a-2*a/n...以次类推
            // 还款利息总和为Y
            // 每月应还本金：a/n
            // 每月应还利息：an*i
            // 每期还款a/n +an*i
            // 支付利息Y=（n+1）*a*i/2
            // 还款总额=（n+1）*a*i/2+a
            // ==========================
            //result.totalInterest = (data.term + 1) * data.amount * data.rate / 2; //支付利息总和
            //result.totalRefund = esult.totalInterest + data.amount; //还款总额
            var totalRefund = 0;
            var refundList = [];
            for (var k = 1; k <= data.term; k++) {
                var an = (data.amount - data.amount * (k - 1) / data.term) ;
                //var an = data.amount - (k+1) * data.amount / data.term;
                var termRefund = data.amount / data.term + an * data.rate;
                totalRefund += termRefund;
                refundList.push({ term: k, refund: termRefund });
            }
            result.totalInterest = totalRefund - data.amount;
            result.totalRefund = totalRefund;// result.totalInterest + data.amount; //还款总额
            result.refundList = refundList;
        } else {
            //先息后本
            //每期应还款 = 本金 * 月利率
            //总利息 = 本金 * 月利率 * 还款期数
            //本息合计 = 总利息 + 本金
            result.monthRefund = data.amount*data.rate;
            result.totalInterest = result.monthRefund*data.term; //支付利息总和
            result.totalRefund = result.totalInterest + data.amount; //还款总额
        }
        callback && callback(result);
    }

    /**
    * 显示明细
    */
    window.showDetail = function (result) {
        var resultWrapper = $("#divResultList");
        var refundWrapper = $("#divRefundList");
        $("#spTotalInterest").text(formatNumber(result.totalInterest));
        $("#spTotalRefund").text(formatNumber(result.totalRefund));
        if (result.refundList) {
            resultWrapper.addClass("hide");
            refundWrapper.empty().removeClass("hide");
            $.each(result.refundList, function(index, item) {
                var html = [
                    '<div class="main-item bb-gray clearfix">',
                    '<span class="pull-left">第'+item.term+'期还款</span>',
                    '<span class="pull-right form-value" id="sp_amount">'+item.refund.toFixed(2)+'元</span>',
                    '</div>'
                ];
                refundWrapper.append(html.join(""));
            });
        } else {
            resultWrapper.removeClass("hide");
            refundWrapper.addClass("hide");
            result.amountText = (result.amount / 10000).toFixed(2) + "万";
            result.rateText = result.yearRate + "%";
            result.termText = result.term + "个月";
            result.refundTypeText = definedConfig.refundType[result.refundType];
            result.monthRefundText = result.monthRefund.toFixed(2) + "元";
            for (var key in result) {
                var value = result[key + "Text"] || result[key] || "";
                resultWrapper.find("#sp_" + key).text(value);
            }
        }
        
        worf.animate.sliderLeft("#divResult");
        //改变当前显示的头部
        worf.nav.changeHeader(1);
        //设置添加标题
        worf.app.toogleTitle($(".app-title").eq(1));
        pageLevel = 1;

        /*格式化数字*/
        function formatNumber(num) {
            var numStr = num.toFixed(2);
            var numbers = numStr.split(".");
            var letters = numbers[0].split("").reverse();
            for (var i = 0; i < letters.length; i++) {
                if (i + 1 % 3 == 0) {
                    letters.slice(i + 1, 0, ",");
                }
            }
            return letters.reverse().join("") + (numbers[1] ? ("." + numbers[1]) : "");
        }
    }

    /**
    * 底部弹出选择框
    */
    window.slideUpBox = function (obj) {
        var me = $(obj);
        worf.ui.slideUpBox({
            data: definedConfig.refundType,
            select: function (data) {
                me.find(".form-value").removeClass("color-gray").addClass("color-black").attr("data-value", data.value).text(data.text);
            }
        });
    }

    /**
    * 返回 
    */
    window.goback = function () {
        if (pageLevel == 1) {
            worf.animate.sliderRight("#divResult");
            //改变当前显示的头部
            worf.nav.changeHeader(0);
            //设置添加标题
            worf.app.toogleTitle($(".app-title").eq(0));
            pageLevel = 0;
            return;
        }
        if (worf.app.isReady && worf.app.toIndex) {
            worf.app.toIndex("/view/tool/calculator.html", true);
        }
    };

    function reset() {
        $("#form").find("input").val("");
        $("#txtRefundType").data("value", "").text("请选择");
    }

    window.init = function () {
        $("#btnSubmit").click(submit);
        $("#btnReset").click(reset);
    };
})(window.Zepto);
