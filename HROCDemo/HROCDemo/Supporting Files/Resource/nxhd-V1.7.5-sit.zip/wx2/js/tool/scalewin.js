(function() {
    var document = window.document,
        support = {
            transform3d: ("WebKitCSSMatrix" in window && "m11" in new WebKitCSSMatrix()),
            touch: ("ontouchstart" in window)
        };

    function getPage(event, page) {
        return support.touch ? event.changedTouches[0][page] : event[page];
    }

    var scaleWin = function() {};

    scaleWin.prototype = {
        // 给初始化数据
        init: function(param) {
            var self = this,
                params = param || {};

            self.params = params;
            self.buffMoveX = 12; //缓冲系数
            self.buffMoveY = 32; //缓冲系数
            self.buffScale = 60; //放大系数
            self.finger = false; //触摸手指的状态 false：单手指 true：多手指
            self._destroy();

            // 禁止页面滚动
            document.addEventListener("touchmove", self.eventStop, false);

            self.element = document.body;
            self.winWidth = window.screen.availWidth;
            self.winHeight = document.documentElement.clientHeight;
            console.log(self.winWidth);
            console.log(self.winHeight);
            self.transX = 0; //transform x
            self.transY = 0; //transform y
            self.scale = 1;

            self.addEventStart();

            params.opened && params.opened();
        },
        getTranslate: function(x, y, ratio) {
            var self = this;
            if (x) {
                self.transX += x; //transform x
                self.transY += y; //transform y
            }
            if (ratio) {
                var prevScale = self.scale + 0;
                self.prevScale = self.prevScale || 1;
                self.scale += ratio > 1 ? ratio / self.buffScale : 0 - ratio / self.buffScale;

                if (self.scale < 0.25) {
                    self.scale = 0.25;
                } else if (self.scale > 2) {
                    self.scale = 2;
                }

                self.transX = self.transX * prevScale / self.scale;
                self.transX = self.transY * prevScale / self.scale;
                self.prevScale = prevScale;
            }

            if (self.transX < 50 - self.winWidth) {
                self.transX = 50 - self.winWidth;
            } else if (self.transX > self.winWidth - 50) {
                self.transX = self.winWidth * self.scale - 50;
            }
            if (self.transY < 100 - self.winHeight * self.scale) {
                self.transY = 100 - self.winHeight * self.scale;
            } else if (self.transY > self.winHeight - 100) {
                self.transY = self.winHeight * self.scale - 100;
            }

            return support.transform3d ? "translate3d(" + self.transX + "px, " + self.transY + "px, 0) scale(" + self.scale + ")" : "translate(" + self.transX + "px, " + self.transY + "px) scale(" + self.scale + ")";
        },
        addEventStart: function() {
            var self = this;
            document.addEventListener("touchstart", function(e) {
                self._touchstart(e);
            }, false);
            document.addEventListener("touchmove", function(e) {
                self._touchmove(e);
            }, false);
            document.addEventListener("touchend", function(e) {
                self._touchend(e);
            }, false);
        },
        // 重置坐标数据
        _destroy: function() {
            this.distX = 0;
            this.distY = 0;
            this.newX = 0;
            this.newY = 0;
            this.transX = 0; //transform x
            this.transY = 0; //transform y
            this.scale = 1;
            self.prevRatio = 0;
        },
        // 更新地图信息
        _changeData: function() {

        },
        _touchstart: function(e) {
            var self = this;

            e.preventDefault();

            var touchTarget = e.targetTouches.length; //获得触控点数

            self._changeData(); //重新初始化图片、可视区域数据，由于放大会产生新的计算

            if (touchTarget == 1) {
                // 获取开始坐标
                self.basePageX = getPage(e, "pageX");
                self.basePageY = getPage(e, "pageY");

                self.finger = false;
            } else {
                self.finger = true;

                self.startFingerDist = self.getTouchDist(e).dist;
                self.startFingerX = self.getTouchDist(e).x;
                self.startFingerY = self.getTouchDist(e).y;
            }
        },
        _touchmove: function(e) {
            var self = this;

            e.preventDefault();
            e.stopPropagation();

            var touchTarget = e.targetTouches.length; //获得触控点数

            if (touchTarget == 1 && !self.finger) {
                self._move(e);
            }

            if (touchTarget >= 2) {
                self._zoom(e);
            }
        },
        _touchend: function(e) {
            var self = this;
            self.reset();
        },
        _move: function(e) {
            var self = this,
                pageX = getPage(e, "pageX"), //获取移动坐标
                pageY = getPage(e, "pageY");

            // 禁止默认事件
            // e.preventDefault();
            // e.stopPropagation();

            // 获得移动距离
            self.distX = (pageX - self.basePageX) / self.buffMoveX;
            self.distY = (pageY - self.basePageY) / self.buffMoveY;
            clearTimeout(self.moveTimer);
            self.moveTimer = setTimeout(function() {
                self.refresh(self.distX, self.distY);
            }, 10);
            self.finger = false;
        },
        // 图片缩放
        _zoom: function(e) {
            var self = this;
            // e.preventDefault();
            // e.stopPropagation();

            var nowFingerDist = self.getTouchDist(e).dist, //获得当前长度
                ratio = nowFingerDist / self.startFingerDist; //计算缩放比
            console.log(ratio);
            clearTimeout(self.scaleTimer);
            self.scaleTimer = setTimeout(function() {
                self.refresh(0, 0, ratio);
            }, 10);

            self.finger = true;
        },
        //关闭
        close: function() {
            var self = this;
            self._destroy();
            document.removeEventListener("touchmove", self.eventStop, false);
            self.params.closed && self.params.closed();
        },
        // 重置数据
        reset: function() {

        },
        // 执行图片移动
        refresh: function(x, y, ratio) {
            console.log(this.getTranslate(x, y, ratio));
            document.body.style.cssText = "-webkit-transform:" + this.getTranslate(x, y, ratio);
        },
        // 获取多点触控
        getTouchDist: function(e) {
            var x1 = 0,
                y1 = 0,
                x2 = 0,
                y2 = 0,
                x3 = 0,
                y3 = 0,
                result = {};

            x1 = e.touches[0].pageX;
            x2 = e.touches[1].pageX;
            y1 = e.touches[0].pageY - document.body.scrollTop;
            y2 = e.touches[1].pageY - document.body.scrollTop;

            if (!x1 || !x2) return;

            if (x1 <= x2) {
                x3 = (x2 - x1) / 2 + x1;
            } else {
                x3 = (x1 - x2) / 2 + x2;
            }
            if (y1 <= y2) {
                y3 = (y2 - y1) / 2 + y1;
            } else {
                y3 = (y1 - y2) / 2 + y2;
            }

            result = {
                dist: Math.round(Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2))),
                x: Math.round(x3),
                y: Math.round(y3)
            };
            return result;
        },
        eventStop: function(e) {
            e.preventDefault();
            e.stopPropagation();
        }
    };
    window.scaleWin = new scaleWin();
})();

/**
 * 
 */
scaleWin.init({
    opened: function() {},
    closed: function() {}
});
scaleWin.refresh(0, 0, 0.25);